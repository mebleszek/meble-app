(function(){
  'use strict';
  const root = typeof window !== 'undefined' ? window : globalThis;
  root.FC = root.FC || {};
  const dom = root.FC.dataSettingsDom || {};
  const icons = root.FC.appIcons || {};
  const h = dom.h;

  const INFO = {
    backup:'Kopie danych służą do zabezpieczenia aktualnego stanu programu oraz przenoszenia danych między urządzeniami. Raport pamięci jest w narzędziach testów.',
    defaults:'Globalne domyślne materiały i marki okuć są fallbackiem programu. Preferencje konkretnego pomieszczenia mają pierwszeństwo.',
    company:'Dane firmy, adres startowy transportu, telefon, e-mail i klucz OpenRouteService do darmowego przeliczania trasy.',
    businessCosts:'Koszty firmy to lista kosztów stałych i pomocniczych: lokal, media, księgowa, ochrona, samochód, programy i inne.',
    tests:'Testy aplikacji prowadzą do dwóch obszarów: narzędzi pamięci oraz testów regresyjnych dokładanych w trakcie rozwoju programu.',
    workSources:'Źródła danych do czynności to centralny słownik nazw: techniczna nazwa, ludzka nazwa i opis, skąd program bierze wartość. To nie jest drugi zapis danych w szafkach.',
  };

  function addTileActivation(tile, onClick){
    if(typeof onClick !== 'function') return;
    tile.setAttribute('role', 'button');
    tile.setAttribute('tabindex', '0');
    tile.addEventListener('click', onClick);
    tile.addEventListener('keydown', (event)=>{
      const key = event && (event.key || event.code);
      if(key === 'Enter' || key === ' ' || key === 'Spacebar'){
        event.preventDefault();
        onClick(event);
      }
    });
  }

  function buildIcon(name){
    const wrap = h('span', { class:'data-settings-menu-tile__icon' });
    if(icons && typeof icons.create === 'function') wrap.appendChild(icons.create(name, 'app-ui-icon data-settings-menu-tile__svg'));
    else wrap.textContent = name === 'backup' ? 'B' : (name === 'tests' ? 'T' : (name === 'settings' ? 'U' : 'D'));
    return wrap;
  }

  function buildTitle(title, infoKey){
    const row = h('span', { class:'data-settings-menu-tile__title-row' }, [
      h('span', { class:'data-settings-menu-tile__title', text:title }),
    ]);
    const message = INFO[infoKey];
    if(message){
      if(FC.helpRegistry && typeof FC.helpRegistry.createTrigger === 'function') row.appendChild(FC.helpRegistry.createTrigger({ key:'dataSettings.menu.' + (FC.helpRegistry.safeKey ? FC.helpRegistry.safeKey(title) : title), title:title, message:message, scope:'dataSettings', className:'info-trigger data-settings-menu-tile__info', stop:true }));
      else {
        const infoBtn = h('button', { type:'button', class:'info-trigger data-settings-menu-tile__info', 'aria-label':`Pokaż informację: ${title}` });
        infoBtn.addEventListener('click', (event)=>{
          try{ event.preventDefault(); event.stopPropagation(); }catch(_){ }
          if(dom && typeof dom.info === 'function') dom.info(title, message);
        });
        row.appendChild(infoBtn);
      }
    }
    return row;
  }

  function buildTile(opts){
    const tile = h('div', { class:'data-settings-menu-tile' + (opts.disabled ? ' data-settings-menu-tile--disabled' : ''), 'data-settings-section':opts.section || '' }, [
      buildIcon(opts.icon),
      buildTitle(opts.title, opts.infoKey),
      h('span', { class:'data-settings-menu-tile__sub', text:opts.sub }),
    ]);
    if(opts.disabled) tile.setAttribute('aria-disabled', 'true');
    else addTileActivation(tile, opts.onClick);
    return tile;
  }

  function render(scroll, setView){
    if(!(scroll && h)) return;
    scroll.innerHTML = '';
    const card = h('section', { class:'data-settings-card data-settings-menu-card' });
    card.appendChild(h('h3', { text:'Ustawienia' }));
    card.appendChild(h('p', { class:'muted', text:'Wybierz obszar ustawień. Backup jest głębiej, żeby ekran startowy ustawień nie był przeładowany.' }));

    const grid = h('div', { class:'data-settings-menu-grid' });
    grid.appendChild(buildTile({
      icon:'backup',
      title:'Backup i dane',
      sub:'Kopie danych, eksport i import danych programu.',
      section:'backup',
      infoKey:'backup',
      onClick:()=> setView('backup'),
    }));
    grid.appendChild(buildTile({
      icon:'settings',
      title:'Domyślne materiały i okucia',
      sub:'Globalny korpus, front, plecy oraz marki okuć używane jako fallback programu.',
      section:'defaults',
      infoKey:'defaults',
      onClick:()=> setView('defaults'),
    }));
    grid.appendChild(buildTile({
      icon:'settings',
      title:'Dane do czynności i wyceny',
      sub:'Nazwa techniczna, nazwa przyjazna i opis, jak program ma czytać dane z szafek.',
      section:'workSources',
      infoKey:'workSources',
      onClick:()=> setView('workSources'),
    }));
    grid.appendChild(buildTile({
      icon:'settings',
      title:'Dane firmy i transport',
      sub:'Adres firmy, telefon, e-mail, OpenRouteService i zasady kilometrów.',
      section:'company',
      infoKey:'company',
      onClick:()=> setView('company'),
    }));
    grid.appendChild(buildTile({
      icon:'settings',
      title:'Koszty firmy',
      sub:'Czynsz, media, księgowa, ochrona, transport, narzędzia i pozostałe koszty stałe.',
      section:'businessCosts',
      infoKey:'businessCosts',
      onClick:()=> setView('businessCosts'),
    }));
    grid.appendChild(buildTile({
      icon:'tests',
      title:'Testy aplikacji',
      sub:'Narzędzia pamięci, smoke testy i sprawdzanie regresji.',
      section:'tests',
      infoKey:'tests',
      onClick:()=> { root.location.href = 'dev_tests.html'; },
    }));
    card.appendChild(grid);
    scroll.appendChild(card);
  }

  root.FC.dataSettingsMenuView = { render };
})();
