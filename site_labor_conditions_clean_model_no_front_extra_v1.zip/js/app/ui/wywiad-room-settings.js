(function(){
  'use strict';
  const ns = (window.FC = window.FC || {});

  const FIELD_DEFS = [
    { key:'roomHeight', label:'Wys. pomieszczenia (cm)', step:'0.1' },
    { key:'bottomHeight', label:'Wys. dołu z nogami (cm)', step:'0.1' },
    { key:'legHeight', label:'Wys. nóżek (cm)', step:'0.1' },
    { key:'counterThickness', label:'Gr. blatu (cm)', step:'0.1' },
    { key:'gapHeight', label:'Odstęp / gap (cm)', step:'0.1' },
    { key:'ceilingBlende', label:'Blenda góra (cm)', step:'0.1' }
  ];

  function getSharedUiState(){
    try{ if(typeof uiState !== 'undefined' && uiState && typeof uiState === 'object') return uiState; }catch(_){ }
    try{ if(window.uiState && typeof window.uiState === 'object') return window.uiState; }catch(_){ }
    return null;
  }

  function getSharedProjectData(){
    try{ if(typeof projectData !== 'undefined' && projectData && typeof projectData === 'object') return projectData; }catch(_){ }
    try{ if(window.projectData && typeof window.projectData === 'object') return window.projectData; }catch(_){ }
    return null;
  }

  function syncSharedProjectData(nextProject){
    try{ if(typeof projectData !== 'undefined') projectData = nextProject; }catch(_){ }
    try{ window.projectData = nextProject; }catch(_){ }
    return nextProject;
  }

  function getCurrentRoom(){
    try{
      const state = getSharedUiState();
      return String((state && state.roomType) || '').trim();
    }catch(_){ return ''; }
  }

  function getRoomSettings(room){
    const key = String(room || '').trim();
    if(!key) return null;
    try{
      const project = getSharedProjectData();
      const data = project && project[key];
      if(data && typeof data === 'object') return data.settings || null;
    }catch(_){ }
    return null;
  }

  function getRoomLabel(room){
    const key = String(room || '').trim();
    if(!key) return 'Pomieszczenie';
    try{
      const registry = window.FC && window.FC.roomRegistry;
      if(registry && typeof registry.getRoomLabel === 'function') return registry.getRoomLabel(key);
    }catch(_){ }
    return key.charAt(0).toUpperCase() + key.slice(1);
  }

  function formatNumber(value){
    const n = Number(value);
    if(!Number.isFinite(n)) return '0';
    const rounded = Math.round(n * 10) / 10;
    if(Math.abs(rounded - Math.round(rounded)) < 0.0001) return String(Math.round(rounded));
    return String(rounded).replace('.', ',');
  }

  function getAutoTopHeight(room, override){
    const source = override || getRoomSettings(room) || {};
    const h = (Number(source.roomHeight) || 0)
      - (Number(source.bottomHeight) || 0)
      - (Number(source.counterThickness) || 0)
      - (Number(source.gapHeight) || 0)
      - (Number(source.ceilingBlende) || 0);
    return h > 0 ? Math.round(h * 10) / 10 : 0;
  }

  function makeCompactSummary(settings){
    const line = document.createElement('div');
    line.className = 'wywiad-room-shell__stats-line';
    line.innerHTML = '<strong>Parametry:</strong> '
      + 'wys. ' + formatNumber(settings.roomHeight) + ' cm'
      + ' • dół ' + formatNumber(settings.bottomHeight) + ' cm'
      + ' • nóżki ' + formatNumber(settings.legHeight) + ' cm'
      + ' • blat ' + formatNumber(settings.counterThickness) + ' cm'
      + ' • gap ' + formatNumber(settings.gapHeight) + ' cm'
      + ' • blenda ' + formatNumber(settings.ceilingBlende) + ' cm';
    return line;
  }


  function createSaveFooter(sectionTitle, onSave){
    const api = ns.wywiadRoomAccordionActions;
    if(api && typeof api.createSaveFooter === 'function'){
      return api.createSaveFooter({ sectionTitle, buttonText:'Zapisz zmiany', onSave }).footer;
    }
    const footer = document.createElement('div');
    footer.className = 'wywiad-room-inline-form__footer';
    const saveBtn = document.createElement('button');
    saveBtn.type = 'button';
    saveBtn.className = 'btn btn-success wywiad-room-inline-form__save';
    saveBtn.textContent = 'Zapisz zmiany';
    saveBtn.setAttribute('aria-label', 'Zapisz zmiany — ' + sectionTitle);
    saveBtn.addEventListener('click', onSave);
    footer.appendChild(saveBtn);
    return footer;
  }

  function bindTriggerButtons(root){
    // Etap room_accordion_inline_v1: parametry są edytowane bezpośrednio w akordeonie.
    // Funkcja zostaje jako zgodny kontrakt dla starszych testów i akcji.
    const scope = root && root.querySelector ? root : document;
    const btn = scope.getElementById ? scope.getElementById('openRoomSettingsBtn') : document.getElementById('openRoomSettingsBtn');
    if(!btn || btn.__wywiadRoomSettingsBound) return;
    btn.__wywiadRoomSettingsBound = true;
    btn.addEventListener('click', (event)=>{
      try{ event.preventDefault(); event.stopPropagation(); }catch(_){ }
      open();
    });
  }

  function buildInlineControls(room, settings){
    const box = document.createElement('div');
    box.className = 'wywiad-room-inline-form wywiad-room-inline-form--settings';

    const summary = makeCompactSummary(settings);
    summary.classList.add('wywiad-room-inline-form__summary');
    box.appendChild(summary);

    const topStat = document.createElement('div');
    topStat.className = 'wywiad-room-inline-form__auto muted xs';
    box.appendChild(topStat);

    const grid = document.createElement('div');
    grid.className = 'grid-2 wywiad-room-settings-modal__grid wywiad-room-inline-form__grid';
    box.appendChild(grid);

    const inputs = {};
    function refreshPreview(){
      const preview = buildPreviewSettings(inputs);
      topStat.innerHTML = 'Auto-wysokość góry: <strong>' + formatNumber(getAutoTopHeight(room, preview)) + ' cm</strong>';
    }

    FIELD_DEFS.forEach((field)=>{
      const fieldEl = document.createElement('div');
      fieldEl.className = 'wywiad-room-settings-modal__field wywiad-room-inline-form__field';

      const label = document.createElement('label');
      label.className = 'wywiad-room-settings-modal__label';
      label.setAttribute('for', 'roomSettingInline_' + field.key);
      label.textContent = field.label;

      const input = document.createElement('input');
      input.type = 'number';
      input.id = 'roomSettingInline_' + field.key;
      input.className = 'investor-form-input wywiad-room-settings-modal__input wywiad-room-inline-form__input';
      input.step = field.step || '0.1';
      input.inputMode = 'decimal';
      input.value = formatNumber(settings[field.key]).replace(',', '.');
      input.addEventListener('input', refreshPreview);
      input.addEventListener('change', refreshPreview);

      inputs[field.key] = input;
      fieldEl.appendChild(label);
      fieldEl.appendChild(input);
      grid.appendChild(fieldEl);
    });

    box.appendChild(createSaveFooter('Parametry pomieszczenia', ()=>{
      applySettingsValues(room, buildPreviewSettings(inputs));
      renderSummary(room);
    }));

    refreshPreview();
    return box;
  }

  function renderSummary(roomArg){
    const room = String(roomArg || getCurrentRoom() || '').trim();
    const wrap = document.getElementById('roomSettingsSummary');
    if(!wrap) return;
    wrap.innerHTML = '';
    const settings = getRoomSettings(room);
    if(!settings) return;
    wrap.appendChild(buildInlineControls(room, settings));
    bindTriggerButtons(document);
  }

  function buildPreviewSettings(inputs){
    const preview = {};
    FIELD_DEFS.forEach((field)=>{
      const input = inputs[field.key];
      preview[field.key] = input ? input.value : 0;
    });
    return preview;
  }

  function parseSettingValue(value){
    const raw = String(value == null ? '' : value).replace(',', '.').trim();
    if(raw === '') return 0;
    const parsed = parseFloat(raw);
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function applySettingsValues(roomArg, values){
    try{
      const room = String(roomArg || getCurrentRoom() || '').trim();
      const project = getSharedProjectData();
      if(!room || !project || !project[room] || !project[room].settings) return;
      FIELD_DEFS.forEach((field)=>{
        project[room].settings[field.key] = parseSettingValue(values && values[field.key]);
      });
      if(window.FC && window.FC.project && typeof window.FC.project.save === 'function'){
        syncSharedProjectData(window.FC.project.save(project));
      } else {
        syncSharedProjectData(project);
      }
      try{ typeof window.renderTopHeight === 'function' && window.renderTopHeight(room); }catch(_){ }
      try{ typeof window.renderCabinets === 'function' && window.renderCabinets(); }catch(_){ }
    }catch(_){ }
  }

  function applySetting(field, value){
    try{
      if(typeof window.handleSettingChange === 'function'){
        window.handleSettingChange(field, value);
        return;
      }
    }catch(_){ }
    try{
      const room = getCurrentRoom();
      const project = getSharedProjectData();
      if(!room || !project || !project[room] || !project[room].settings) return;
      project[room].settings[field] = value === '' ? 0 : parseFloat(value);
      if(window.FC && window.FC.project && typeof window.FC.project.save === 'function'){
        syncSharedProjectData(window.FC.project.save(project));
      } else {
        syncSharedProjectData(project);
      }
      try{ typeof window.renderTopHeight === 'function' && window.renderTopHeight(); }catch(_){ }
      try{ typeof window.renderCabinets === 'function' && window.renderCabinets(); }catch(_){ }
    }catch(_){ }
  }

  function open(){
    const room = getCurrentRoom();
    const settings = getRoomSettings(room);
    if(!room || !settings) return false;
    if(!(ns.panelBox && typeof ns.panelBox.open === 'function')) return false;

    const form = document.createElement('div');
    form.className = 'panel-box-form rozrys-panel-form rozrys-panel-form--stock wywiad-room-settings-modal investor-card-sync';

    const scroll = document.createElement('div');
    scroll.className = 'panel-box-form__scroll wywiad-room-settings-modal__scroll';
    form.appendChild(scroll);

    const intro = document.createElement('div');
    intro.className = 'wywiad-room-settings-modal__intro';

    const roomBadge = document.createElement('div');
    roomBadge.className = 'wywiad-room-settings-modal__room';
    roomBadge.textContent = getRoomLabel(room);

    const topStat = document.createElement('div');
    topStat.className = 'wywiad-room-settings-modal__auto';
    topStat.innerHTML = 'Auto-wysokość góry: <strong>' + formatNumber(getAutoTopHeight(room, settings)) + ' cm</strong>';

    intro.appendChild(roomBadge);
    intro.appendChild(topStat);
    scroll.appendChild(intro);

    const grid = document.createElement('div');
    grid.className = 'grid-2 wywiad-room-settings-modal__grid';
    scroll.appendChild(grid);

    const inputs = {};

    function refreshPreview(){
      const preview = buildPreviewSettings(inputs);
      topStat.innerHTML = 'Auto-wysokość góry: <strong>' + formatNumber(getAutoTopHeight(room, preview)) + ' cm</strong>';
    }

    FIELD_DEFS.forEach((field)=>{
      const fieldEl = document.createElement('div');
      fieldEl.className = 'wywiad-room-settings-modal__field';

      const label = document.createElement('label');
      label.className = 'wywiad-room-settings-modal__label';
      label.setAttribute('for', 'roomSettingModal_' + field.key);
      label.textContent = field.label;

      const input = document.createElement('input');
      input.type = 'number';
      input.id = 'roomSettingModal_' + field.key;
      input.className = 'investor-form-input wywiad-room-settings-modal__input';
      input.step = field.step || '0.1';
      input.inputMode = 'decimal';
      input.value = formatNumber(settings[field.key]).replace(',', '.');
      input.addEventListener('input', refreshPreview);
      input.addEventListener('change', ()=>{
        applySetting(field.key, input.value);
        renderSummary(room);
        refreshPreview();
      });

      inputs[field.key] = input;
      fieldEl.appendChild(label);
      fieldEl.appendChild(input);
      grid.appendChild(fieldEl);
    });

    const footer = document.createElement('div');
    footer.className = 'panel-box-form__footer rozrys-picker-footer rozrys-picker-footer--material wywiad-room-settings-modal__footer';
    const exitBtn = document.createElement('button');
    exitBtn.type = 'button';
    exitBtn.className = 'btn';
    exitBtn.textContent = 'Wyjdź';
    exitBtn.addEventListener('click', ()=> close());
    footer.appendChild(exitBtn);
    form.appendChild(footer);

    ns.panelBox.open({
      title:'Parametry pomieszczenia',
      contentNode: form,
      width:'700px',
      boxClass:'panel-box--rozrys wywiad-room-settings-box',
      dismissOnOverlay:true,
      dismissOnEsc:true
    });

    requestAnimationFrame(()=>{
      try{ inputs.roomHeight && inputs.roomHeight.focus(); }catch(_){ }
    });
    return true;
  }

  function close(){
    try{ if(ns.panelBox && typeof ns.panelBox.close === 'function') ns.panelBox.close(); }catch(_){ }
    return true;
  }

  function init(){
    if(typeof document === 'undefined' || !document) return;
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ()=> bindTriggerButtons(document), { once:true });
    else bindTriggerButtons(document);
  }

  init();

  ns.wywiadRoomSettings = Object.assign({}, ns.wywiadRoomSettings || {}, {
    open,
    close,
    renderSummary,
    getAutoTopHeight,
    bindTriggerButtons,
  });
})();
