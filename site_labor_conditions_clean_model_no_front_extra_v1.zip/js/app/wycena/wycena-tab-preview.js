(function(){
  'use strict';
  window.FC = window.FC || {};
  const FC = window.FC;


  function diagRender(label, value){
    try{ if(FC.wycenaDiagnostics && typeof FC.wycenaDiagnostics.recordRenderEvent === 'function') FC.wycenaDiagnostics.recordRenderEvent(label, value); }catch(_){ }
  }
  function summarizeQuote(snapshot, deps){
    const snap = snapshot && typeof snapshot === 'object' ? snapshot : {};
    let id = '';
    try{ id = deps && typeof deps.getSnapshotId === 'function' ? deps.getSnapshotId(snap) : String(snap.id || snap.snapshotId || ''); }catch(_){ id = String(snap.id || snap.snapshotId || ''); }
    return {
      id:String(id || ''),
      projectId:String(snap.project && snap.project.id || snap.projectId || ''),
      investorId:String(snap.investor && snap.investor.id || snap.investorId || snap.project && snap.project.investorId || ''),
      versionName:String(snap.commercial && snap.commercial.versionName || snap.meta && snap.meta.versionName || ''),
      generatedAt:snap.generatedAt || snap.generatedDate || null,
      grand:snap.totals && snap.totals.grand,
      error:String(snap.error || ''),
      selectedRooms:Array.isArray(snap.scope && snap.scope.selectedRooms) ? snap.scope.selectedRooms : (Array.isArray(snap.selectedRooms) ? snap.selectedRooms : []),
    };
  }

  // Odpowiedzialność modułu: render podglądu aktywnej/historycznej oferty WYCENY.
  // Nie trzyma stanu zakładki i nie zapisuje danych — dostaje wyłącznie zależności z tabs/wycena.js.

  function normalizeDeps(deps){
    return deps && typeof deps === 'object' ? deps : {};
  }

  function renderEmpty(card, deps){
    const d = normalizeDeps(deps);
    card.appendChild(d.h('p', { class:'muted', text:'Wycena pobiera materiały z działu Materiał, uruchamia rozkrój w tle na logice ROZRYS dla pomieszczeń i zakresu wybranych bezpośrednio tutaj oraz dolicza pozycje AGD z dodanych szafek. Dodaj także stawki wyceny i pola handlowe, aby wygenerować ofertę dla klienta.' }));
  }

  function renderSection(card, title, rows, emptyText, deps){
    const d = normalizeDeps(deps);
    const h = d.h;
    const wrap = h('section', { class:'card quote-section', style:'margin-top:12px;padding:14px;' });
    wrap.appendChild(h('h4', { text:title, style:'margin:0 0 10px' }));
    if(!rows || !rows.length){
      wrap.appendChild(h('div', { class:'muted', text:emptyText || 'Brak pozycji.' }));
      card.appendChild(wrap);
      return;
    }

    const list = h('div', { class:'quote-list' });
    const head = h('div', { class:'quote-list__head' });
    ['Pozycja','Ilość','Cena','Wartość'].forEach((label)=> head.appendChild(h('div', { class:'quote-list__cell quote-list__cell--head', text:label })));
    list.appendChild(head);

    rows.forEach((row)=>{
      const item = h('article', { class:'quote-list__item' });
      const main = h('div', { class:'quote-list__row' });
      main.appendChild(h('div', { class:'quote-list__cell quote-list__cell--name', text:row.name || 'Pozycja' }));
      main.appendChild(h('div', { class:'quote-list__cell quote-list__cell--qty', text:String(row.qty || 0) + (row.unit ? ` ${row.unit}` : '') }));
      main.appendChild(h('div', { class:'quote-list__cell quote-list__cell--price', text:d.money(row.unitPrice) }));
      main.appendChild(h('div', { class:'quote-list__cell quote-list__cell--total', text:d.money(row.total) }));
      item.appendChild(main);
      const metaText = d.buildRowMeta(row);
      if(metaText) item.appendChild(h('div', { class:'quote-list__meta', text:metaText }));
      list.appendChild(item);
    });

    wrap.appendChild(list);
    card.appendChild(wrap);
  }


  function renderLaborSection(card, rows, deps){
    const d = normalizeDeps(deps);
    const h = d.h;
    const wrap = h('section', { class:'card quote-section quote-labor-section', style:'margin-top:12px;padding:14px;' });
    wrap.appendChild(h('h4', { text:'Robocizna — szafki', style:'margin:0 0 10px' }));
    if(!Array.isArray(rows) || !rows.length){
      wrap.appendChild(h('div', { class:'muted', text:'Brak wyliczonej robocizny szafek.' }));
      card.appendChild(wrap);
      return;
    }
    const total = rows.reduce((sum, row)=> sum + (Number(row && row.total) || 0), 0);
    const hours = rows.reduce((sum, row)=> sum + (Number(row && row.hours) || 0), 0);
    wrap.appendChild(h('div', { class:'quote-labor-summary', text:`Suma robocizny szafek: ${d.money(total)} • normoczas: ${hours.toFixed(2)} h` }));
    const list = h('div', { class:'quote-labor-list' });
    rows.forEach((row)=>{
      const details = h('details', { class:'quote-labor-cabinet' });
      const summary = h('summary', { class:'quote-labor-cabinet__summary' });
      const title = h('div', { class:'quote-labor-cabinet__title' });
      title.appendChild(h('div', { class:'quote-labor-cabinet__name', text:row.name || `Szafka #${row.cabinetNumber || ''}` }));
      const meta = [];
      if(row.dimensions) meta.push(row.dimensions);
      if(Number(row.volumeM3) > 0) meta.push(`${Number(row.volumeM3).toFixed(3)} m³`);
      if(row.note) meta.push(row.note);
      title.appendChild(h('div', { class:'quote-labor-cabinet__meta', text:meta.join(' • ') || '—' }));
      const amount = h('div', { class:'quote-labor-cabinet__amount', text:d.money(row.total) });
      summary.appendChild(title);
      summary.appendChild(amount);
      details.appendChild(summary);
      const body = h('div', { class:'quote-labor-cabinet__body' });
      (Array.isArray(row.details) ? row.details : []).forEach((part)=>{
        const item = h('div', { class:'quote-labor-detail' });
        const partMeta = [];
        if(Number(part.hours) > 0) partMeta.push(`${Number(part.hours).toFixed(2)} h`);
        if(Number(part.hourlyRate) > 0) partMeta.push(`${Number(part.hourlyRate).toFixed(2)} PLN/h`);
        if(Number(part.volumeM3) > 0 && Number(part.volumePrice) > 0) partMeta.push(`gabaryt ${Number(part.volumeM3).toFixed(3)} m³`);
        if(Number(part.volumeHours) > 0) partMeta.push(`gabarytoczas ${Number(part.volumeHours).toFixed(2)} h`);
        if(Number(part.multiplier) && Number(part.multiplier) !== 1) partMeta.push(`mnożnik ×${Number(part.multiplier).toFixed(2)}`);
        if(part.note) partMeta.push(part.note);
        item.appendChild(h('div', { class:'quote-labor-detail__main', text:part.name || 'Czynność' }));
        item.appendChild(h('div', { class:'quote-labor-detail__meta', text:partMeta.join(' • ') || '—' }));
        item.appendChild(h('div', { class:'quote-labor-detail__total', text:d.money(part.total) }));
        body.appendChild(item);
      });
      if(!body.childNodes.length) body.appendChild(h('div', { class:'muted', text:'Brak szczegółów dla tej szafki.' }));
      details.appendChild(body);
      list.appendChild(details);
    });
    wrap.appendChild(list);
    card.appendChild(wrap);
  }

  function renderCommercialSection(card, snapshot, ctx, deps){
    const d = normalizeDeps(deps);
    const h = d.h;
    const commercial = snapshot && snapshot.commercial || {};
    const totals = snapshot && snapshot.totals || {};
    const section = h('section', { class:'card quote-section', style:'margin-top:12px;padding:14px;' });
    section.appendChild(h('h4', { text:'Warunki oferty', style:'margin:0 0 10px' }));
    const list = h('div', { class:'quote-commercial-list' });
    const addRow = (label, value, strong)=>{
      const text = String(value || '').trim();
      if(!text) return;
      const row = h('div', { class:'quote-commercial-list__row' });
      row.appendChild(h('div', { class:'quote-commercial-list__label', text:label }));
      row.appendChild(h('div', { class:`quote-commercial-list__value${strong ? ' is-strong' : ''}`, text }));
      list.appendChild(row);
    };
    addRow('Wersja oferty', commercial.versionName);
    addRow('Typ oferty', commercial.preliminary ? 'Wstępna wycena (bez pomiaru)' : 'Wycena');
    addRow('Zakres elementów', d.getMaterialScopeLabel(snapshot));
    if(Number(commercial.discountPercent) > 0) addRow('Rabat', `${Number(commercial.discountPercent).toFixed(2)}%`, true);
    else if(Number(commercial.discountAmount) > 0) addRow('Rabat', d.money(commercial.discountAmount), true);
    addRow('Ważność oferty', commercial.offerValidity);
    addRow('Termin realizacji', commercial.leadTime);
    addRow('Warunki montażu / transportu', commercial.deliveryTerms);
    addRow('Notatka dla klienta', commercial.customerNote);
    if(!list.childNodes.length) list.appendChild(h('div', { class:'muted', text:'Brak dodatkowych pól handlowych dla tej wersji oferty.' }));
    section.appendChild(list);
    const totalsCard = h('div', { class:'card quote-totals', style:'margin-top:12px;padding:14px;' });
    totalsCard.appendChild(h('h4', { text:'Podsumowanie', style:'margin:0 0 8px' }));
    [
      ['Materiały', totals.materials, 'materials'],
      ['Akcesoria', totals.accessories, 'accessories'],
      ['Robocizna szafek', totals.labor, 'labor'],
      ['Robocizna / stawki wyceny', totals.quoteRates, 'quoteRates'],
      ['Montaż AGD', totals.services, 'services'],
      ['Suma przed rabatem', totals.subtotal, 'total'],
      ['Rabat', totals.discount, 'discount'],
      ['Razem', totals.grand, 'total'],
    ].forEach(([label, value, detailSection], index, arr)=>{
      const row = h('div', { class:`quote-totals__row${index === arr.length - 1 ? ' quote-totals__row--grand' : ''}`, 'data-quote-detail-section':detailSection, role:'button', tabindex:'0' });
      row.appendChild(h('span', { text:label }));
      row.appendChild(h('span', { text:d.money(value) }));
      row.addEventListener('click', ()=>{
        try{ if(FC.wycenaSummaryDetailsModal && typeof FC.wycenaSummaryDetailsModal.open === 'function') FC.wycenaSummaryDetailsModal.open(snapshot, detailSection); }catch(_){ }
      });
      row.addEventListener('keydown', (event)=>{
        if(event.key !== 'Enter' && event.key !== ' ') return;
        event.preventDefault();
        try{ if(FC.wycenaSummaryDetailsModal && typeof FC.wycenaSummaryDetailsModal.open === 'function') FC.wycenaSummaryDetailsModal.open(snapshot, detailSection); }catch(_){ }
      });
      totalsCard.appendChild(row);
    });
    if(d.canAcceptSnapshot(snapshot)){
      const previewActions = h('div', { class:'quote-preview-actions' });
      const acceptBtn = h('button', { class:'btn-success', type:'button', text:'Zaakceptuj ofertę' });
      acceptBtn.addEventListener('click', ()=> {
        void d.acceptSnapshot(snapshot, ctx, { rememberScroll:true, anchorId:'quotePreviewStart', fallbackAnchorId:'quoteActivePreview' });
      });
      previewActions.appendChild(acceptBtn);
      totalsCard.appendChild(previewActions);
    }
    card.appendChild(section);
    card.appendChild(totalsCard);
  }

  function getScopeRoomLabels(currentQuote){
    try{
      if(FC.quoteSnapshotStore && typeof FC.quoteSnapshotStore.getScopeRoomLabels === 'function') return FC.quoteSnapshotStore.getScopeRoomLabels(currentQuote);
    }catch(_){ }
    return Array.isArray(currentQuote && currentQuote.roomLabels) ? currentQuote.roomLabels : (currentQuote && currentQuote.scope && Array.isArray(currentQuote.scope.roomLabels) ? currentQuote.scope.roomLabels : []);
  }

  function renderPreview(card, currentQuote, ctx, deps){
    const d = normalizeDeps(deps);
    const h = d.h;
    if(!currentQuote){
      diagRender('preview:render-empty', { reason:'no-current-quote' });
      renderEmpty(card, d);
      return;
    }
    if(currentQuote.error){
      diagRender('preview:render-error', summarizeQuote(currentQuote, d));
      card.appendChild(h('div', { class:'muted', text:currentQuote.error, style:'margin-top:10px;color:#b42318' }));
      return;
    }

    diagRender('preview:render-input', summarizeQuote(currentQuote, d));
    const roomLabels = getScopeRoomLabels(currentQuote);
    const lines = currentQuote.lines || {};
    const generatedAt = currentQuote.generatedAt || currentQuote.generatedDate || null;
    if(generatedAt){
      card.appendChild(h('div', { id:'quotePreviewStart' }));
      const isLatest = d.getSnapshotId(currentQuote) === d.getSnapshotId(d.getSnapshotHistory()[0]);
      const previewMeta = h('div', { class:'quote-preview-meta' });
      previewMeta.appendChild(h('span', { class:`quote-preview-badge${isLatest ? ' is-latest' : ''}`, text:isLatest ? 'Aktualna wersja oferty' : 'Wersja oferty z historii' }));
      if(d.isPreliminarySnapshot(currentQuote)) previewMeta.appendChild(h('span', { class:'quote-preview-badge quote-preview-badge--preliminary', text:'Wstępna wycena' }));
      if(d.isSelectedSnapshot(currentQuote)) previewMeta.appendChild(h('span', { class:'quote-preview-badge quote-preview-badge--selected', text:'Zaakceptowana' }));
      if(d.getVersionName(currentQuote)) previewMeta.appendChild(h('span', { class:'quote-preview-badge quote-preview-badge--version', text:d.getVersionName(currentQuote) }));
      previewMeta.appendChild(h('p', { class:'muted quote-scope', text:`Wersja oferty: ${d.formatDateTime(generatedAt)}` }));
      card.appendChild(previewMeta);
    }
    if(Array.isArray(roomLabels) && roomLabels.length){
      card.appendChild(h('p', { class:'muted quote-scope', text:`Pomieszczenia: ${roomLabels.join(', ')}`, style:'margin-top:6px' }));
    }
    card.appendChild(h('p', { class:'muted quote-scope', text:`Zakres elementów: ${d.getMaterialScopeLabel(currentQuote)}`, style:'margin-top:6px' }));
    // Główny widok WYCENY ma pozostać skrótem dla klienta/użytkownika: tylko metadane, podsumowanie i historia.
    // Szczegóły materiałów, akcesoriów i robocizny są dostępne wyłącznie przez klikalne linie podsumowania i modal audytu.
    renderCommercialSection(card, currentQuote, ctx, d);
    diagRender('preview:render-end', { quote:summarizeQuote(currentQuote, d), materialLines:0, accessoryLines:0, roomLabels, detailsHidden:true });
  }

  FC.wycenaTabPreview = {
    renderPreview,
    renderEmpty,
    renderSection,
    renderLaborSection,
    renderCommercialSection,
  };
})();
