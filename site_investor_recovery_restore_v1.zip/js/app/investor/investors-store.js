// js/app/investor/investors-store.js
// Lokalna baza inwestorów (localStorage). Przygotowane pod przyszły sync.
(() => {
  'use strict';
  window.FC = window.FC || {};
  const FC = window.FC;

  const KEY_INVESTORS = 'fc_investors_v1';
  const KEY_CURRENT = 'fc_current_investor_v1';
  const DEFAULT_PROJECT_STATUS = 'nowy';
  const recovery = FC.investorStoreRecovery || null;

  function now(){ return Date.now(); }
  function uid(){ return 'inv_' + Math.random().toString(36).slice(2,10) + '_' + now().toString(36); }

  function todayInput(){
    try{ return new Date().toISOString().slice(0, 10); }catch(_){ return ''; }
  }

  function toDateInput(value, fallback){
    const text = String(value == null ? '' : value).trim();
    if(/^\d{4}-\d{2}-\d{2}$/.test(text)) return text;
    if(Number.isFinite(Number(text)) && Number(text) > 0){
      try{ return new Date(Number(text)).toISOString().slice(0, 10); }catch(_){ }
    }
    const fb = String(fallback == null ? '' : fallback).trim();
    if(/^\d{4}-\d{2}-\d{2}$/.test(fb)) return fb;
    if(Number.isFinite(Number(fb)) && Number(fb) > 0){
      try{ return new Date(Number(fb)).toISOString().slice(0, 10); }catch(_){ }
    }
    return todayInput();
  }

  function prettifyTechnicalRoomText(text, fallbackBaseType){
    const raw = String(text || '').trim();
    if(!raw) return '';
    const match = raw.match(/^room_([^_]+)_(.+)_([a-z0-9]{4,})$/i);
    if(!match) return raw;
    const baseType = String(match[1] || fallbackBaseType || '').trim();
    let middle = String(match[2] || '').trim();
    if(baseType && middle.toLowerCase().startsWith(baseType.toLowerCase() + '_')) middle = middle.slice(baseType.length + 1);
    return middle.replace(/_/g, ' ').trim() || raw;
  }

  function normalizeRoom(room){
    const src = room && typeof room === 'object' ? room : {};
    const baseType = String(src.baseType || src.kind || src.type || '');
    const name = prettifyTechnicalRoomText(src.name || src.label || '', baseType);
    const label = prettifyTechnicalRoomText(src.label || src.name || '', baseType);
    return {
      id: String(src.id || ''),
      baseType,
      name: String(name || ''),
      label: String(label || name || ''),
      projectStatus: String(src.projectStatus || src.status || DEFAULT_PROJECT_STATUS),
    };
  }


  function normalizeMeta(meta){
    const src = meta && typeof meta === 'object' ? meta : {};
    return {
      testData: !!src.testData,
      testOwner: String(src.testOwner || ''),
      testRunId: String(src.testRunId || ''),
      createdBy: String(src.createdBy || ''),
      source: String(src.source || ''),
    };
  }

  function normalizeInvestor(inv){
    const src = inv && typeof inv === 'object' ? inv : {};
    const createdAt = Number(src.createdAt) > 0 ? Number(src.createdAt) : now();
    const updatedAt = Number(src.updatedAt) > 0 ? Number(src.updatedAt) : createdAt;
    const kind = src.kind === 'company' ? 'company' : 'person';
    return {
      id: String(src.id || uid()),
      kind,
      name: String(src.name || ''),
      companyName: String(src.companyName || ''),
      ownerName: String(src.ownerName || src.companyOwner || ''),
      phone: String(src.phone || ''),
      email: String(src.email || ''),
      city: String(src.city || ''),
      address: String(src.address || ''),
      source: String(src.source || ''),
      nip: String(src.nip || ''),
      notes: String(src.notes || ''),
      rooms: Array.isArray(src.rooms) ? src.rooms.map(normalizeRoom) : [],
      addedDate: toDateInput(src.addedDate || src.createdDate, createdAt),
      createdAt,
      updatedAt,
      meta: normalizeMeta(src.meta),
    };
  }

  function writeAllRaw(list){
    const normalized = Array.isArray(list) ? list.map(normalizeInvestor) : [];
    try{ localStorage.setItem(KEY_INVESTORS, JSON.stringify(normalized)); }catch(_){ }
    try{ if(recovery && typeof recovery.backupInvestors === 'function') recovery.backupInvestors(normalized); }catch(_){ }
    return normalized;
  }

  function readAll(){
    try{
      const raw = localStorage.getItem(KEY_INVESTORS);
      const parsed = recovery && typeof recovery.parseInvestorListRaw === 'function'
        ? recovery.parseInvestorListRaw(raw)
        : (()=> { try{ const arr = raw ? JSON.parse(raw) : []; return Array.isArray(arr) ? arr : []; }catch(_){ return []; } })();
      let list = Array.isArray(parsed) ? parsed.map(normalizeInvestor) : [];
      if(recovery && typeof recovery.recoverList === 'function'){
        const backupRaw = (()=> { try{ return localStorage.getItem(recovery.KEY_BACKUP || 'fc_investors_backup_v1'); }catch(_){ return null; } })();
        const result = recovery.recoverList({
          primaryRaw: raw,
          backupRaw,
          primaryList: list,
          currentInvestorId: getCurrentId(),
          normalizeInvestor,
          projectStore: FC.projectStore || null,
          quoteSnapshotStore: FC.quoteSnapshotStore || null,
          quoteOfferStore: FC.quoteOfferStore || null,
        });
        if(result && Array.isArray(result.list)){
          list = result.list.map(normalizeInvestor);
          try{ FC.investorsLastRecovery = result.stats || null; }catch(_){ }
          if(result.repaired) writeAllRaw(list);
        }
      }
      return list;
    }catch(_){ return []; }
  }

  function writeAll(list){
    return writeAllRaw(list);
  }

  function getCurrentId(){
    try{ return localStorage.getItem(KEY_CURRENT) || null; }catch(_){ return null; }
  }

  function setCurrentId(id){
    try{
      if(!id) localStorage.removeItem(KEY_CURRENT);
      else localStorage.setItem(KEY_CURRENT, String(id));
    }catch(_){ }
  }

  function getById(id){
    if(!id) return null;
    const list = readAll();
    return list.find(x => x && x.id === id) || null;
  }

  function upsert(inv){
    if(!inv || !inv.id) return null;
    const normalized = normalizeInvestor(inv);
    const list = readAll();
    const idx = list.findIndex(x => x && x.id === normalized.id);
    if(idx >= 0) list[idx] = normalized;
    else list.unshift(normalized);
    writeAll(list);
    return normalized;
  }

  function create(initial){
    const ts = now();
    const inv = normalizeInvestor({
      id: uid(),
      kind: (initial && initial.kind) || 'person',
      name: (initial && initial.name) || '',
      companyName: (initial && initial.companyName) || '',
      ownerName: (initial && (initial.ownerName || initial.companyOwner)) || '',
      phone: (initial && initial.phone) || '',
      email: (initial && initial.email) || '',
      city: (initial && initial.city) || '',
      address: (initial && initial.address) || '',
      source: (initial && initial.source) || '',
      nip: (initial && initial.nip) || '',
      notes: (initial && Object.prototype.hasOwnProperty.call(initial, 'notes')) ? (initial.notes || '') : 'BRAK',
      rooms: Array.isArray(initial && initial.rooms) ? initial.rooms : [],
      addedDate: (initial && (initial.addedDate || initial.createdDate)) || toDateInput(ts, ts),
      createdAt: ts,
      updatedAt: ts,
      meta: initial && initial.meta,
    });
    const list = readAll();
    list.unshift(inv);
    writeAll(list);
    setCurrentId(inv.id);
    return inv;
  }

  function update(id, patch){
    const inv = getById(id);
    if(!inv) return null;
    const next = normalizeInvestor(Object.assign({}, inv, patch || {}, { updatedAt: now() }));
    return upsert(next);
  }

  function remove(id){
    const list = readAll().filter(x => x && x.id !== id);
    writeAll(list);
    const cur = getCurrentId();
    if(cur === id) setCurrentId(null);
  }

  function search(q){
    const query = String(q || '').trim().toLowerCase();
    const list = readAll();
    if(!query) return list;
    return list.filter(inv => {
      if(!inv) return false;
      const hay = [
        inv.name, inv.companyName, inv.ownerName, inv.phone, inv.email, inv.city, inv.address, inv.nip, inv.notes, inv.addedDate
      ].join(' ').toLowerCase();
      return hay.includes(query);
    });
  }

  // Placeholder pod przyszły sync (na razie no-op)
  async function sync(){
    return { ok: true, mode: 'local-only' };
  }

  FC.investors = {
    readAll,
    writeAll,
    search,
    getById,
    create,
    update,
    remove,
    getCurrentId,
    setCurrentId,
    sync,
    normalizeInvestor,
    normalizeRoom,
    DEFAULT_PROJECT_STATUS,
    KEY_INVESTORS,
    KEY_CURRENT,
    getRecoveryState(){ return FC.investorsLastRecovery || null; },
  };
})();
