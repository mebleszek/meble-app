// js/app/material/price-modal-item-form.js
// Stan formularza i wewnętrzny modal dodawania/edycji pozycji katalogu.
(function(){
  'use strict';
  window.FC = window.FC || {};
  const FC = window.FC;
  const ctx = FC.priceModalContext || {};

  function filterMaterialWrapper(){ return ctx.byId('formMaterialTypeLaunch') && ctx.byId('formMaterialTypeLaunch').parentElement; }
  function filterManufacturerWrapper(){ return ctx.byId('formManufacturerLaunch') && ctx.byId('formManufacturerLaunch').parentElement; }
  function formCategoryWrapper(){ return ctx.byId('formCategoryLaunch') && ctx.byId('formCategoryLaunch').parentElement; }
  function formServiceNameWrapper(){ return ctx.byId('formServiceName') && ctx.byId('formServiceName').parentElement; }
  function formPriceWrapper(){ return ctx.byId('formPrice') && ctx.byId('formPrice').parentElement; }
  function formMaterialPriceUnitWrapper(){ return ctx.byId('formMaterialPriceUnitLaunch') && ctx.byId('formMaterialPriceUnitLaunch').parentElement; }
  function formHasGrainRow(){ return ctx.byId('formHasGrain') && ctx.byId('formHasGrain').parentElement; }
  function hardwareSeriesTopWrap(){ return ctx.byId('hardwareSeriesTopWrap'); }
  function laborFields(){ return ctx.byId('laborFormFields'); }
  function hardwareFields(){ return ctx.byId('hardwareFormFields'); }

  function setFormNameLabel(label){
    const node = ctx.byId('formNameLabel');
    if(!node) return;
    const target = node.querySelector ? (node.querySelector('.label-help__text') || node) : node;
    target.textContent = String(label || 'Nazwa');
  }
  function toggleHardwareTechnicalNamePreview(show){
    const wrap = ctx.byId('hardwareTechnicalNamePreviewWrap');
    if(wrap) wrap.style.display = show ? '' : 'none';
  }


  const LABOR_CHOICE_FIELDS = [
    { id:'laborAutoRole', title:'Wybierz automat robocizny', placeholder:'Automat robocizny' },
    { id:'laborRateType', title:'Wybierz stawkę godzinową', placeholder:'Stawka godzinowa' },
    { id:'laborTimeBlockHours', title:'Wybierz czas bazowy', placeholder:'Czas bazowy' },
    { id:'laborQuantityMode', title:'Wybierz tryb ilości', placeholder:'Tryb ilości' },
    { id:'laborStartHours', title:'Wybierz czas startowy', placeholder:'Start h' },
    { id:'laborStepHours', title:'Wybierz czas kolejnego kroku', placeholder:'Dodaj h' },
    { id:'laborVolumeTimeMode', title:'Wybierz gabarytoczas', placeholder:'Gabarytoczas' },
  ];


  function ensureLaborChoiceMount(selectEl){
    if(!(selectEl && selectEl.parentNode)) return null;
    const mountId = String(selectEl.id || '') + 'Launch';
    let mount = ctx.byId(mountId);
    if(!mount){
      mount = document.createElement('div');
      mount.id = mountId;
      mount.className = 'price-labor-choice-slot';
      selectEl.insertAdjacentElement('afterend', mount);
    }
    try{ selectEl.hidden = true; selectEl.setAttribute('aria-hidden', 'true'); }catch(_){ }
    return mount;
  }


  function hideLaborUsageField(){
    const el = ctx.byId('laborUsage');
    if(!el) return;
    try{ el.value = 'universal'; }catch(_){ }
    const wrap = el.closest ? el.closest('div') : el.parentElement;
    if(wrap) wrap.style.display = 'none';
  }

  function mountLaborChoiceLaunchers(){
    LABOR_CHOICE_FIELDS.forEach((field)=>{
      const selectEl = ctx.byId(field.id);
      const mount = ensureLaborChoiceMount(selectEl);
      if(!(selectEl && mount)) return;
      ctx.mountChoice({
        selectEl,
        mountId:mount.id,
        title:field.title,
        buttonClass:'investor-choice-launch price-labor-choice-launch',
        placeholder:field.placeholder,
        onChange:()=>{ if(field.id === 'laborAutoRole') syncLaborAutomatUi(); if(field.id === 'laborRateType') syncLaborRateProfileUi(); updateItemActionState(); },
      });
    });
  }


  function defaultMaterialPriceUnit(materialType){
    const type = String(materialType || '').trim().toLowerCase();
    if(type === 'akryl' || type === 'lakier' || type === 'hdf') return 'm2';
    if(type === 'obrzeże' || type === 'obrzeze') return 'mb';
    if(type === 'blat') return 'piece';
    return 'sheet';
  }
  function defaultMaterialDraft(){
    const type = ctx.firstNonEmptyValue(ctx.buildMaterialTypeOptions('laminat')) || 'laminat';
    const manufacturer = ctx.firstNonEmptyValue(ctx.buildManufacturerOptions('materials', type, '', { includeAll:false }));
    return { materialType:type, manufacturer, symbol:'', name:'', price:'', priceUnit:defaultMaterialPriceUnit(type), hasGrain:false };
  }
  function defaultServiceDraft(kind){
    const isQuoteRates = kind === 'quoteRates';
    return {
      category:ctx.firstNonEmptyValue(ctx.buildCategoryOptions(kind, isQuoteRates ? 'Korpusy' : 'Cięcie', { includeAll:false })) || (isQuoteRates ? 'Korpusy' : 'Cięcie'),
      name:'',
      price:'',
      usage:isQuoteRates ? 'universal' : '',
      autoRole:'none',
      workAutomatCode:isQuoteRates ? 'manual_fixed' : '',
      automatCode:isQuoteRates ? 'manual_fixed' : '',
      laborAutomatCode:isQuoteRates ? 'manual_fixed' : '',
      isHourlyRate:false,
      rateKey:'',
      rateCode:'',
      rateType:'workshop',
      timeBlockHours:0,
      defaultMultiplier:1,
      quantityMode:'none',
      quantityTiers:[],
      startHours:0,
      startQty:1,
      stepEveryQty:1,
      stepHours:0,
      volumePricePerM3:0,
      volumeTimeMode:'none',
      volumeTimePerM3:0,
      volumeTimeTiers:[],
      heightMinMm:0,
      heightMaxMm:0,
      active:true,
      internalOnly:true,
    };
  }

  function currentEditedItem(){
    const editingId = ctx.appUiState() && ctx.appUiState().editingId;
    if(!editingId) return null;
    return ctx.currentList().find((item)=> item && item.id === editingId) || null;
  }
  function normalizePriceValue(value){ const raw = String(value == null ? '' : value).trim(); if(!raw) return ''; const parsed = Number(raw.replace(',', '.')); return Number.isFinite(parsed) ? parsed : raw; }
  function readNumber(id){ return normalizePriceValue(ctx.byId(id) && ctx.byId(id).value); }
  function readString(id){ return String((ctx.byId(id) && ctx.byId(id).value) || '').trim(); }
  function readBool(id){ return !!(ctx.byId(id) && ctx.byId(id).checked); }
  function setValue(id, value){ const el = ctx.byId(id); if(el) el.value = value == null ? '' : String(value); }
  function setChecked(id, value){ const el = ctx.byId(id); if(el) el.checked = !!value; }

  function store(){ return ctx.catalogStore && ctx.catalogStore(); }
  function getLaborAutomats(){
    const s = store();
    try{
      if(s && typeof s.getLaborAutomats === 'function') return s.getLaborAutomats();
    }catch(_){ }
    try{
      return FC.laborCatalog && typeof FC.laborCatalog.ensureDefaultWorkAutomats === 'function'
        ? FC.laborCatalog.ensureDefaultWorkAutomats([])
        : [];
    }catch(_){ return []; }
  }
  function saveLaborAutomats(list){
    const s = store();
    try{ if(s && typeof s.saveLaborAutomats === 'function') return s.saveLaborAutomats(list); }catch(_){ }
    return list || [];
  }
  function selectedLaborAutomatCode(){
    const labor = FC.laborCatalog || {};
    const raw = readString('laborAutoRole');
    return labor.normalizeWorkAutomatCode ? labor.normalizeWorkAutomatCode(raw) : raw;
  }
  function buildLaborAutomatOptions(selectedCode){
    const labor = FC.laborCatalog || {};
    if(labor.workAutomatOptions) return labor.workAutomatOptions(getLaborAutomats(), selectedCode);
    return [{ value:'', label:'Brak automatu' }].concat(getLaborAutomats().map((row)=> ({ value:row.code, label:row.label || row.code })));
  }

  function isHourlyRateItem(item){
    const labor = FC.laborCatalog || {};
    try{ return labor.isHourlyRateDefinition ? labor.isHourlyRateDefinition(item || {}) : String(item && item.autoRole || '') === 'hourlyRate'; }
    catch(_){ return String(item && item.autoRole || '') === 'hourlyRate'; }
  }
  function selectedLaborRateCode(){
    const labor = FC.laborCatalog || {};
    const raw = readString('laborRateType');
    return labor.normalizeRateCode ? labor.normalizeRateCode(raw) : raw;
  }
  function getLaborRateProfiles(selectedCode){
    const labor = FC.laborCatalog || {};
    const rows = ctx.currentList ? ctx.currentList() : [];
    try{ return labor.buildRateProfiles ? labor.buildRateProfiles(rows, selectedCode) : []; }
    catch(_){ return []; }
  }
  function buildLaborRateProfileOptions(selectedCode){
    const labor = FC.laborCatalog || {};
    const rows = ctx.currentList ? ctx.currentList() : [];
    try{
      if(labor.rateProfileOptions) return labor.rateProfileOptions(rows, selectedCode);
    }catch(_){ }
    return [
      { value:'workshop', label:'Warsztatowa' },
      { value:'assembly', label:'Montażowa' },
      { value:'specialist', label:'Specjalistyczna' },
      { value:'helper', label:'Pomocnika' },
    ];
  }
  function refreshLaborRateTypeSelect(selectedCode){
    const code = selectedCode || selectedLaborRateCode() || 'workshop';
    ctx.setSelectOptions(ctx.byId('laborRateType'), buildLaborRateProfileOptions(code), code, code);
    setValue('laborRateType', code);
    try{ mountLaborChoiceLaunchers(); }catch(_){ }
  }
  function isHourlyRateMode(){ return !!(ctx.byId('laborIsHourlyRate') && ctx.byId('laborIsHourlyRate').checked); }
  function findRateProfile(code){
    const labor = FC.laborCatalog || {};
    try{ return labor.findRateProfile ? labor.findRateProfile(ctx.currentList ? ctx.currentList() : [], code) : null; }
    catch(_){ return null; }
  }
  function setServicePriceLabel(label){
    const wrap = formPriceWrapper();
    if(!wrap) return;
    const lab = wrap.querySelector ? wrap.querySelector(':scope > label, :scope > .label-help') : null;
    const target = lab && lab.querySelector ? (lab.querySelector('.label-help__text') || lab) : lab;
    if(target) target.textContent = String(label || 'Kwota stała / cena prosta (PLN)');
  }
  function syncLaborRateProfileUi(){
    if(ctx.currentListKind && ctx.currentListKind() !== 'quoteRates') return;
    const hourly = isHourlyRateMode();
    const rule = ctx.byId('laborRuleFields');
    const rateFields = ctx.byId('laborRateProfileFields');
    const title = ctx.byId('laborFormSectionTitle');
    const internalWrap = ctx.byId('laborInternalOnlyWrap');
    const categoryWrap = formCategoryWrapper();
    const codeInput = ctx.byId('laborRateCode');
    const preview = ctx.byId('laborRateProfilePreview');
    const item = currentEditedItem();
    const isEdit = !!(ctx.appUiState() && ctx.appUiState().editingId);
    if(rule) rule.style.display = hourly ? 'none' : '';
    if(rateFields) rateFields.style.display = hourly ? '' : 'none';
    if(title) title.textContent = hourly ? 'Stawka godzinowa' : 'Reguła robocizny';
    if(internalWrap) internalWrap.style.display = hourly ? 'none' : '';
    if(categoryWrap) categoryWrap.style.display = hourly ? 'none' : '';
    if(hourly){
      try{ ctx.setSelectOptions(ctx.byId('formCategory'), ctx.buildCategoryOptions('quoteRates', 'Stawki godzinowe'), 'Stawki godzinowe', 'Stawki godzinowe'); }catch(_){ }
    }
    if(hourly && ctx.byId('laborInternalOnly')) ctx.byId('laborInternalOnly').checked = false;
    setServicePriceLabel(hourly ? 'Kwota stawki godzinowej (PLN/h)' : 'Kwota stała / cena prosta (PLN)');
    setFormNameLabel(hourly ? 'Nazwa przyjazna stawki' : 'Nazwa przyjazna / nazwa pozycji');
    if(codeInput){
      const currentCode = String(codeInput.value || '').trim();
      codeInput.readOnly = hourly && isEdit;
      if(hourly && isEdit) codeInput.setAttribute('aria-readonly', 'true');
      else codeInput.removeAttribute('aria-readonly');
      if(hourly && !currentCode && item){
        const labor = FC.laborCatalog || {};
        const code = labor.normalizeRateCode ? labor.normalizeRateCode(item.rateKey || item.rateCode || item.rateType) : String(item.rateKey || item.rateCode || item.rateType || '');
        codeInput.value = code;
      }
    }
    const code = codeInput ? String(codeInput.value || '').trim() : '';
    const profile = findRateProfile(code);
    if(preview){
      const price = Number(ctx.byId('formServicePrice') && ctx.byId('formServicePrice').value || 0) || (profile ? Number(profile.price) || 0 : 0);
      preview.value = hourly && code ? `${code}${price > 0 ? ' • ' + price.toFixed(2) + ' zł/h' : ''}` : '';
    }
  }

  function syncLaborAutomatUi(){
    if(ctx.currentListKind && ctx.currentListKind() !== 'quoteRates') return;
    const code = selectedLaborAutomatCode();
    const labor = FC.laborCatalog || {};
    const item = labor.findWorkAutomat ? labor.findWorkAutomat(getLaborAutomats(), code) : null;
    const preview = ctx.byId('laborAutomatCodePreview');
    if(preview) preview.value = code || '';
    const editBtn = ctx.byId('laborAutomatEditBtn');
    if(editBtn){
      editBtn.disabled = !code || !item;
      editBtn.setAttribute('aria-disabled', editBtn.disabled ? 'true' : 'false');
    }
  }
  function refreshLaborAutomatSelect(selectedCode){
    const code = selectedCode || selectedLaborAutomatCode();
    ctx.setSelectOptions(ctx.byId('laborAutoRole'), buildLaborAutomatOptions(code), code, code);
    setValue('laborAutoRole', code);
    try{ mountLaborChoiceLaunchers(); }catch(_){ }
    syncLaborAutomatUi();
  }
  function makeModalField(label, input){
    const wrap = document.createElement('div');
    wrap.style.marginTop = '10px';
    const lab = document.createElement('label');
    lab.textContent = label;
    wrap.appendChild(lab);
    wrap.appendChild(input);
    return wrap;
  }
  function openLaborAutomatModal(mode){
    if(!(FC.panelBox && typeof FC.panelBox.open === 'function')) return;
    const labor = FC.laborCatalog || {};
    const list = getLaborAutomats();
    const isEdit = mode === 'edit';
    const currentCode = isEdit ? selectedLaborAutomatCode() : '';
    const current = isEdit && labor.findWorkAutomat ? labor.findWorkAutomat(list, currentCode) : null;
    if(isEdit && !current) return;
    const body = document.createElement('div');
    body.className = 'panel-box-form';
    const nameInput = document.createElement('input');
    nameInput.className = 'investor-form-input';
    nameInput.type = 'text';
    nameInput.id = 'laborAutomatModalLabel';
    nameInput.value = current ? String(current.label || current.name || '') : '';
    const codeInput = document.createElement('input');
    codeInput.className = 'investor-form-input';
    codeInput.type = 'text';
    codeInput.id = 'laborAutomatModalCode';
    codeInput.value = current ? String(current.code || '') : '';
    if(isEdit){ codeInput.readOnly = true; codeInput.setAttribute('aria-readonly', 'true'); }
    const activeLabel = document.createElement('label');
    activeLabel.className = 'check-row';
    activeLabel.style.marginTop = '10px';
    const activeInput = document.createElement('input');
    activeInput.type = 'checkbox';
    activeInput.checked = current ? current.active !== false : true;
    activeLabel.appendChild(activeInput);
    activeLabel.appendChild(document.createTextNode(' Aktywny'));
    body.appendChild(makeModalField('Nazwa przyjazna', nameInput));
    body.appendChild(makeModalField('Kod techniczny automatu', codeInput));
    body.appendChild(activeLabel);
    const footer = document.createElement('div');
    footer.className = 'modal-actions';
    footer.style.marginTop = '16px';
    const exit = document.createElement('button');
    exit.type = 'button';
    exit.className = 'btn';
    exit.textContent = 'Wyjdź';
    exit.addEventListener('click', ()=>{ try{ FC.panelBox.close(); }catch(_){ } });
    const save = document.createElement('button');
    save.type = 'button';
    save.className = 'btn primary';
    save.textContent = 'Zapisz';
    save.addEventListener('click', ()=>{
      const payload = {
        code:String(codeInput.value || '').trim(),
        label:String(nameInput.value || '').trim(),
        name:String(nameInput.value || '').trim(),
        description:current ? current.description : '',
        system:current ? current.system === true : false,
        isSystem:current ? current.isSystem === true : false,
        active:activeInput.checked,
        createdAt:current ? current.createdAt : undefined,
      };
      let result = null;
      try{ result = labor.upsertWorkAutomat ? labor.upsertWorkAutomat(list, payload, isEdit ? { oldCode:currentCode } : {}) : null; }
      catch(err){ result = { ok:false, error:err && err.message ? err.message : 'Nie udało się zapisać automatu robocizny.' }; }
      if(!result || !result.ok){
        ctx.info('Nie można zapisać automatu', String((result && result.error) || 'Sprawdź nazwę i kod techniczny.'));
        return;
      }
      saveLaborAutomats(result.list || list);
      refreshLaborAutomatSelect(result.item && result.item.code ? result.item.code : payload.code);
      try{ FC.panelBox.close(); }catch(_){ }
      updateItemActionState();
    });
    footer.appendChild(exit);
    footer.appendChild(save);
    body.appendChild(footer);
    FC.panelBox.open({ title:isEdit ? 'Edytuj automat robocizny' : 'Nowy automat robocizny', contentNode:body, width:'620px', boxClass:'panel-box--rozrys', dismissOnOverlay:false, dismissOnEsc:true });
  }
  function wireLaborAutomatButtons(){
    const createBtn = ctx.byId('laborAutomatCreateBtn');
    const editBtn = ctx.byId('laborAutomatEditBtn');
    if(createBtn) createBtn.onclick = ()=> openLaborAutomatModal('create');
    if(editBtn) editBtn.onclick = ()=> openLaborAutomatModal('edit');
  }

  function syncLaborGabarytMode(){
    if(ctx.currentListKind && ctx.currentListKind() !== 'quoteRates') return;
    const modeEl = ctx.byId('laborVolumeTimeMode');
    const priceEl = ctx.byId('laborVolumePricePerM3');
    if(!(modeEl && priceEl)) return;
    const activeVolumeTime = String(modeEl.value || 'none') !== 'none';
    if(activeVolumeTime){
      if(String(priceEl.value || '') !== '0') priceEl.value = '0';
      priceEl.disabled = true;
      priceEl.setAttribute('aria-disabled', 'true');
      priceEl.title = 'Wyłączone, bo gabaryt jest liczony jako czas. Żeby użyć dopłaty PLN/m³, ustaw Gabarytoczas na Wyłączony.';
    }else{
      priceEl.disabled = false;
      priceEl.removeAttribute('aria-disabled');
      priceEl.removeAttribute('title');
    }
  }

  function getCurrentMaterialDraft(){
    const materialType = String((ctx.byId('formMaterialType') && ctx.byId('formMaterialType').value) || '');
    const priceUnit = String((ctx.byId('formMaterialPriceUnit') && ctx.byId('formMaterialPriceUnit').value) || defaultMaterialPriceUnit(materialType));
    return {
      materialType,
      manufacturer:String((ctx.byId('formManufacturer') && ctx.byId('formManufacturer').value) || '').trim(),
      symbol:String((ctx.byId('formSymbol') && ctx.byId('formSymbol').value) || '').trim(),
      name:String((ctx.byId('formName') && ctx.byId('formName').value) || '').trim(),
      price:normalizePriceValue(ctx.byId('formPrice') && ctx.byId('formPrice').value),
      priceUnit,
      hasGrain:!!(ctx.byId('formHasGrain') && ctx.byId('formHasGrain').checked)
    };
  }
  function getCurrentAccessoryDraft(opts){ return ctx.priceModalHardwareForm && typeof ctx.priceModalHardwareForm.getCurrentAccessoryDraft === 'function' ? ctx.priceModalHardwareForm.getCurrentAccessoryDraft(opts || {}) : {}; }
  function getCurrentLaborDraft(base){
    if(ctx.currentListKind() !== 'quoteRates') return {};
    const labor = FC.laborCatalog || {};
    if(isHourlyRateMode()){
      const code = labor.normalizeRateCode ? labor.normalizeRateCode(readString('laborRateCode')) : readString('laborRateCode');
      return {
        category:'Stawki godzinowe',
        usage:'universal',
        autoRole:'hourlyRate',
        workAutomatCode:'manual_hourly',
        automatCode:'manual_hourly',
        laborAutomatCode:'manual_hourly',
        rateKey:code,
        rateCode:code,
        rateType:code || 'workshop',
        timeBlockHours:0,
        defaultMultiplier:1,
        quantityMode:'none',
        quantityTiers:[],
        startHours:0,
        startQty:1,
        stepEveryQty:1,
        stepHours:0,
        volumePricePerM3:0,
        volumeTimeMode:'none',
        volumeTimePerM3:0,
        volumeTimeTiers:[],
        heightMinMm:0,
        heightMaxMm:0,
        active:readBool('laborActive'),
        internalOnly:false,
        systemRate:false,
        nonDeletable:true,
      };
    }
    const tierText = readString('laborTierText');
    const volumeTierText = readString('laborVolumeTimeTierText');
    const volumeTimeMode = readString('laborVolumeTimeMode') || 'none';
    const selectedCode = selectedLaborAutomatCode();
    const autoRole = labor.workAutomatCodeToAutoRole ? labor.workAutomatCodeToAutoRole(selectedCode, 'none') : 'none';
    const rateType = labor.normalizeRateCode ? labor.normalizeRateCode(readString('laborRateType')) : (readString('laborRateType') || 'workshop');
    return {
      usage:'universal',
      autoRole,
      workAutomatCode:selectedCode,
      automatCode:selectedCode,
      laborAutomatCode:selectedCode,
      rateType:rateType || 'workshop',
      rateKey:autoRole === 'hourlyRate' ? (rateType || 'workshop') : '',
      timeBlockHours:Number(readNumber('laborTimeBlockHours')) || 0,
      defaultMultiplier:Number(readNumber('laborDefaultMultiplier')) || 1,
      quantityMode:readString('laborQuantityMode') || 'none',
      quantityTiers:labor.parseTierText ? labor.parseTierText(tierText) : [],
      startHours:Number(readNumber('laborStartHours')) || 0,
      startQty:Number(readNumber('laborStartQty')) || 1,
      stepEveryQty:Number(readNumber('laborStepEveryQty')) || 1,
      stepHours:Number(readNumber('laborStepHours')) || 0,
      volumePricePerM3:volumeTimeMode === 'none' ? (Number(readNumber('laborVolumePricePerM3')) || 0) : 0,
      volumeTimeMode,
      volumeTimePerM3:Number(readNumber('laborVolumeTimePerM3')) || 0,
      volumeTimeTiers:labor.parseVolumeTierText ? labor.parseVolumeTierText(volumeTierText) : [],
      heightMinMm:Number(readNumber('laborHeightMinMm')) || 0,
      heightMaxMm:Number(readNumber('laborHeightMaxMm')) || 0,
      active:readBool('laborActive'),
      internalOnly:readBool('laborInternalOnly'),
    };
  }
  function getCurrentServiceDraft(){
    const base = { category:String((ctx.byId('formCategory') && ctx.byId('formCategory').value) || '').trim(), name:String((ctx.byId('formServiceName') && ctx.byId('formServiceName').value) || '').trim(), price:normalizePriceValue(ctx.byId('formServicePrice') && ctx.byId('formServicePrice').value) };
    return Object.assign(base, getCurrentLaborDraft(base));
  }
  function currentItemSignature(){ const kind = ctx.currentConfig().formKind; const data = kind === 'material' ? getCurrentMaterialDraft() : (kind === 'accessory' ? getCurrentAccessoryDraft({ passive:true }) : getCurrentServiceDraft()); return JSON.stringify(data); }
  function isItemDirty(){ return ctx.runtimeState.itemModalOpen && currentItemSignature() !== String(ctx.runtimeState.itemInitialSignature || ''); }

  function updateItemActionState(){
    syncLaborGabarytMode();
    syncLaborAutomatUi();
    syncLaborRateProfileUi();
    try{ if(ctx.currentListKind && ctx.currentListKind() === 'accessories' && ctx.priceModalHardwareForm && typeof ctx.priceModalHardwareForm.syncHardwarePricing === 'function') ctx.priceModalHardwareForm.syncHardwarePricing(); }catch(_){ }
    const dirty = isItemDirty();
    const isEdit = !!(ctx.appUiState() && ctx.appUiState().editingId);
    const deleteBtn = ctx.byId('deletePriceItemBtn');
    const exitBtn = ctx.byId('priceItemExitBtn');
    const cancelBtn = ctx.byId('priceItemCancelBtn');
    const saveBtn = ctx.byId('priceItemSaveBtn');
    const footer = ctx.byId('priceItemFooter');
    if(footer) footer.style.display = ctx.runtimeState.itemModalOpen ? 'flex' : 'none';
    const editedItem = currentEditedItem();
    const hourlyRateRow = ctx.currentListKind && ctx.currentListKind() === 'quoteRates' && isHourlyRateItem(editedItem);
    if(deleteBtn) deleteBtn.style.display = (isEdit && !hourlyRateRow) ? '' : 'none';
    if(exitBtn) exitBtn.style.display = dirty ? 'none' : '';
    if(cancelBtn) cancelBtn.style.display = dirty ? '' : 'none';
    if(saveBtn){ saveBtn.style.display = dirty ? '' : 'none'; saveBtn.textContent = isEdit ? 'Zapisz' : ctx.currentConfig().addLabel.replace(/^Dodaj\s+/i, 'Dodaj '); }
    try{
      if(ctx.priceModalHardwareReplacements && typeof ctx.priceModalHardwareReplacements.updateActionState === 'function')
        ctx.priceModalHardwareReplacements.updateActionState({ dirty, isEdit, formKind:ctx.currentConfig().formKind, item:currentEditedItem() });
    }catch(_){ }
  }

  function wireItemDirtyEvents(){
    [
      'formSymbol','formName','formPrice','formMaterialPriceUnit','formServiceName','formServicePrice','formHasGrain','formMaterialType','formManufacturer','formCategory',
      'laborIsHourlyRate','laborRateCode','laborAutoRole','laborRateType','laborTimeBlockHours','laborDefaultMultiplier','laborQuantityMode','laborTierText',
      'laborStartHours','laborStartQty','laborStepEveryQty','laborStepHours','laborVolumePricePerM3','laborVolumeTimeMode','laborVolumeTimePerM3',
      'laborVolumeTimeTierText','laborHeightMinMm','laborHeightMaxMm','laborActive','laborInternalOnly'
    ].concat((ctx.priceModalHardwareForm && Array.isArray(ctx.priceModalHardwareForm.FIELD_IDS)) ? ctx.priceModalHardwareForm.FIELD_IDS : []).forEach((id)=>{
      const el = ctx.byId(id);
      if(!el) return;
      el.oninput = function(event){
        try{ if(ctx.currentListKind && ctx.currentListKind() === 'accessories' && ctx.priceModalHardwareForm && typeof ctx.priceModalHardwareForm.handleHardwareFieldInput === 'function') ctx.priceModalHardwareForm.handleHardwareFieldInput(event); }catch(_){ }
        updateItemActionState();
      };
      el.onchange = function(event){
        try{ if(ctx.currentListKind && ctx.currentListKind() === 'accessories' && ctx.priceModalHardwareForm && typeof ctx.priceModalHardwareForm.handleHardwareFieldInput === 'function') ctx.priceModalHardwareForm.handleHardwareFieldInput(event); }catch(_){ }
        updateItemActionState();
      };
    });
  }

  function applyMaterialFormState(item){
    const materialType = String(item && item.materialType || 'laminat');
    ctx.setSelectOptions(ctx.byId('formMaterialType'), ctx.buildMaterialTypeOptions(materialType), materialType, materialType);
    ctx.setSelectOptions(ctx.byId('formManufacturer'), ctx.buildManufacturerOptions('materials', materialType, item && item.manufacturer), String(item && item.manufacturer || ''), String(item && item.manufacturer || ''));
    if(ctx.byId('formSymbol')) ctx.byId('formSymbol').value = String(item && item.symbol || '');
    if(ctx.byId('formName')) ctx.byId('formName').value = String(item && item.name || '');
    if(ctx.byId('formPrice')) ctx.byId('formPrice').value = item && item.price != null ? item.price : '';
    const unit = String(item && item.priceUnit || defaultMaterialPriceUnit(materialType));
    if(ctx.byId('formMaterialPriceUnit')) ctx.setSelectOptions(ctx.byId('formMaterialPriceUnit'), ctx.buildMaterialPriceUnitOptions ? ctx.buildMaterialPriceUnitOptions(unit) : [{ value:'sheet', label:'Arkusz' }, { value:'m2', label:'m²' }, { value:'mb', label:'mb' }, { value:'piece', label:'szt.' }], unit, unit);
    if(ctx.byId('formHasGrain')) ctx.byId('formHasGrain').checked = !!(item && item.hasGrain);
  }
  function applyAccessoryFormState(item){
    if(ctx.priceModalHardwareForm && typeof ctx.priceModalHardwareForm.applyAccessoryFormState === 'function') ctx.priceModalHardwareForm.applyAccessoryFormState(item);
  }
  function applyLaborFormState(item){
    const labor = FC.laborCatalog || {};
    const def = labor.normalizeDefinition ? labor.normalizeDefinition(item || defaultServiceDraft('quoteRates')) : (item || {});
    const hourly = isHourlyRateItem(item || def);
    setChecked('laborIsHourlyRate', hourly);
    setValue('laborRateCode', hourly ? (def.rateKey || def.rateCode || def.rateType || '') : '');
    setValue('laborUsage', 'universal');
    const selectedAutomat = def.workAutomatCode || (labor.inferWorkAutomatCode ? labor.inferWorkAutomatCode(def, def.autoRole) : '') || '';
    ctx.setSelectOptions(ctx.byId('laborAutoRole'), buildLaborAutomatOptions(selectedAutomat), selectedAutomat, selectedAutomat);
    setValue('laborAutoRole', selectedAutomat);
    refreshLaborRateTypeSelect(def.rateType || def.rateKey || 'workshop');
    setValue('laborTimeBlockHours', Number(def.timeBlockHours) || 0);
    setValue('laborDefaultMultiplier', Number(def.defaultMultiplier) || 1);
    setValue('laborQuantityMode', def.quantityMode || 'none');
    setValue('laborTierText', labor.tiersToText ? labor.tiersToText(def.quantityTiers || []) : '');
    setValue('laborStartHours', Number(def.startHours) || 0);
    setValue('laborStartQty', Number(def.startQty) || 1);
    setValue('laborStepEveryQty', Number(def.stepEveryQty) || 1);
    setValue('laborStepHours', Number(def.stepHours) || 0);
    setValue('laborVolumePricePerM3', Number(def.volumePricePerM3) || 0);
    setValue('laborVolumeTimeMode', def.volumeTimeMode || 'none');
    setValue('laborVolumeTimePerM3', Number(def.volumeTimePerM3) || 0);
    setValue('laborVolumeTimeTierText', labor.volumeTiersToText ? labor.volumeTiersToText(def.volumeTimeTiers || []) : '');
    setValue('laborHeightMinMm', Number(def.heightMinMm) || 0);
    setValue('laborHeightMaxMm', Number(def.heightMaxMm) || 0);
    setChecked('laborActive', def.active !== false);
    setChecked('laborInternalOnly', hourly ? false : def.internalOnly !== false);
    syncLaborGabarytMode();
    syncLaborAutomatUi();
    syncLaborRateProfileUi();
    try{ if(ctx.currentListKind && ctx.currentListKind() === 'accessories' && ctx.priceModalHardwareForm && typeof ctx.priceModalHardwareForm.syncHardwarePricing === 'function') ctx.priceModalHardwareForm.syncHardwarePricing(); }catch(_){ }
  }
  function applyServiceFormState(item){
    const kind = ctx.currentListKind();
    const category = String(item && item.category || (kind === 'workshopServices' ? 'Cięcie' : 'Korpusy'));
    ctx.setSelectOptions(ctx.byId('formCategory'), ctx.buildCategoryOptions(kind, category), category, category);
    if(ctx.byId('formServiceName')) ctx.byId('formServiceName').value = String(item && item.name || '');
    if(ctx.byId('formServicePrice')) ctx.byId('formServicePrice').value = item && item.price != null ? item.price : '';
    if(kind === 'quoteRates') applyLaborFormState(item || defaultServiceDraft(kind));
  }

  function renderItemModal(){
    const kind = ctx.currentListKind();
    const cfg = ctx.currentConfig();
    const isEdit = !!(ctx.appUiState() && ctx.appUiState().editingId);
    const item = currentEditedItem();
    if(ctx.byId('editingIndicator')) ctx.byId('editingIndicator').style.display = isEdit ? '' : 'none';
    if(ctx.byId('priceItemModalTitle')) ctx.byId('priceItemModalTitle').textContent = isEdit ? 'Edytuj pozycję' : cfg.addLabel;
    if(ctx.byId('priceItemModalSubtitle')) ctx.byId('priceItemModalSubtitle').textContent = cfg.subtitle;
    if(ctx.byId('priceItemModalIcon')) ctx.byId('priceItemModalIcon').textContent = cfg.icon;
    if(ctx.byId('priceFormTitle')) ctx.byId('priceFormTitle').textContent = isEdit ? 'Edytuj pozycję' : cfg.addLabel;
    if(ctx.byId('materialFormFields')) ctx.byId('materialFormFields').style.display = (cfg.formKind === 'material' || cfg.formKind === 'accessory') ? '' : 'none';
    if(hardwareFields()) hardwareFields().style.display = cfg.formKind === 'accessory' ? '' : 'none';
    if(ctx.byId('serviceFormFields')) ctx.byId('serviceFormFields').style.display = cfg.formKind === 'service' ? '' : 'none';
    const laborWrap = laborFields();
    const hourlyToggleWrap = ctx.byId('laborHourlyToggleWrap');
    const isQuoteRateForm = cfg.formKind === 'service' && kind === 'quoteRates';
    if(laborWrap) laborWrap.style.display = isQuoteRateForm ? '' : 'none';
    if(hourlyToggleWrap) hourlyToggleWrap.style.display = isQuoteRateForm ? '' : 'none';
    const materialTypeWrap = filterMaterialWrapper();
    const manufacturerWrap = filterManufacturerWrapper();
    const grainRow = formHasGrainRow();
    const priceWrap = formPriceWrapper();
    const priceUnitWrap = formMaterialPriceUnitWrapper();
    const seriesWrap = hardwareSeriesTopWrap();
    if(materialTypeWrap) materialTypeWrap.style.display = cfg.formKind === 'material' ? '' : 'none';
    if(manufacturerWrap) manufacturerWrap.style.display = (cfg.formKind === 'material' || cfg.formKind === 'accessory') ? '' : 'none';
    if(grainRow) grainRow.style.display = cfg.formKind === 'material' ? 'flex' : 'none';
    if(priceWrap) priceWrap.style.display = cfg.formKind === 'accessory' ? 'none' : '';
    if(priceUnitWrap) priceUnitWrap.style.display = cfg.formKind === 'material' ? '' : 'none';
    if(seriesWrap) seriesWrap.style.display = cfg.formKind === 'accessory' ? '' : 'none';
    setFormNameLabel(cfg.formKind === 'accessory' ? 'Nazwa katalogowa' : (kind === 'quoteRates' ? 'Nazwa przyjazna / nazwa pozycji' : 'Nazwa'));
    toggleHardwareTechnicalNamePreview(cfg.formKind === 'accessory');
    if(cfg.formKind === 'material') applyMaterialFormState(item || defaultMaterialDraft());
    else if(cfg.formKind === 'accessory') applyAccessoryFormState(item || (ctx.priceModalHardwareForm && ctx.priceModalHardwareForm.defaultAccessoryDraft ? ctx.priceModalHardwareForm.defaultAccessoryDraft() : {}));
    else applyServiceFormState(item || defaultServiceDraft(kind));
    if(cfg.formKind === 'service'){
      const categoryWrap = formCategoryWrapper();
      const nameWrap = formServiceNameWrapper();
      if(categoryWrap) categoryWrap.style.display = '';
      if(nameWrap) nameWrap.style.display = '';
    }
    if(ctx.mountFormChoiceLaunchers) ctx.mountFormChoiceLaunchers(()=> updateItemActionState());
    if(kind === 'quoteRates') { hideLaborUsageField(); refreshLaborRateTypeSelect(readString('laborRateType') || 'workshop'); mountLaborChoiceLaunchers(); wireLaborAutomatButtons(); syncLaborAutomatUi(); syncLaborRateProfileUi(); }
    if(ctx.decorateFieldHelpLabels) ctx.decorateFieldHelpLabels();
    try{ if(ctx.priceModalHardwareReplacements && typeof ctx.priceModalHardwareReplacements.setSourceItem === 'function') ctx.priceModalHardwareReplacements.setSourceItem(item || null); }catch(_){ }
    wireItemDirtyEvents();
    ctx.runtimeState.itemInitialSignature = currentItemSignature();
    updateItemActionState();
  }

  function openPriceItemModal(id){
    const modal = ctx.byId('priceItemModal');
    if(!modal) return;
    const wasOpen = modal.style.display === 'flex';
    ctx.appUiState().editingId = id || null;
    ctx.persistUi();
    ctx.runtimeState.itemModalOpen = true;
    modal.style.display = 'flex';
    ctx.setModalShellOpen(modal, wasOpen);
    renderItemModal();
  }
  function doClosePriceItemModal(){
    ctx.runtimeState.itemModalOpen = false;
    ctx.runtimeState.itemInitialSignature = '';
    ctx.appUiState().editingId = null;
    ctx.persistUi();
    const modal = ctx.byId('priceItemModal');
    if(modal) modal.style.display = 'none';
    return true;
  }
  async function requestClosePriceItemModal(){
    if(!ctx.runtimeState.itemModalOpen) return true;
    if(isItemDirty()){
      const ok = await ctx.confirmDiscard();
      if(!ok) return false;
    }
    doClosePriceItemModal();
    return true;
  }

  Object.assign(ctx, { currentEditedItem, getCurrentMaterialDraft, getCurrentAccessoryDraft, getCurrentServiceDraft, isItemDirty, updateItemActionState, renderItemModal, openPriceItemModal, doClosePriceItemModal, requestClosePriceItemModal });
})();
