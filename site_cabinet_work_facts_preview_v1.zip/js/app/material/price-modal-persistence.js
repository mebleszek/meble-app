// js/app/material/price-modal-persistence.js
// Walidacja, zapis i usuwanie pozycji katalogów/cenników.
(function(){
  'use strict';
  window.FC = window.FC || {};
  const FC = window.FC;
  const ctx = FC.priceModalContext || {};

  function validateMaterialForm(data){
    if(!String(data && data.name || '').trim()){ ctx.info('Brak nazwy', 'Wprowadź nazwę materiału, zanim go zapiszesz.'); return false; }
    if(!String(data && data.materialType || '').trim()){ ctx.info('Brak typu', 'Wybierz typ materiału.'); return false; }
    if(!String(data && data.manufacturer || '').trim()){ ctx.info('Brak producenta', 'Wybierz producenta dla materiału.'); return false; }
    return true;
  }
  function validateAccessoryForm(data){
    if(!String(data && data.name || '').trim()){ ctx.info('Brak nazwy', 'Wprowadź nazwę akcesorium, zanim je zapiszesz.'); return false; }
    if(!String(data && data.manufacturer || '').trim()){ ctx.info('Brak producenta', 'Wybierz producenta akcesorium.'); return false; }
    if(FC.hardwareCatalog && typeof FC.hardwareCatalog.uniqueTypeConflict === 'function'){
      const conflict = FC.hardwareCatalog.uniqueTypeConflict(ctx.currentList(), data, ctx.appUiState() && ctx.appUiState().editingId);
      if(conflict){
        ctx.info('Duplikat wymagań technicznych u producenta', 'Dla tego producenta, kategorii i tych samych cech technicznych używanych do porównania istnieje już pozycja: ' + String(conflict.name || conflict.symbol || conflict.id || '—') + '. Nazwa techniczna jest tylko podglądem; blokada duplikatu opiera się na parametrach oznaczonych „Użyj do porównania”.');
        return false;
      }
    }
    return true;
  }

  function isQuoteRateHourlyRow(data){
    if(!(ctx.currentListKind && ctx.currentListKind() === 'quoteRates')) return false;
    const labor = FC.laborCatalog || {};
    try{ return labor.isHourlyRateDefinition ? labor.isHourlyRateDefinition(data || {}) : String(data && data.autoRole || '') === 'hourlyRate'; }
    catch(_){ return String(data && data.autoRole || '') === 'hourlyRate'; }
  }
  function validateQuoteRateHourlyProfile(data){
    if(!isQuoteRateHourlyRow(data)) return true;
    const labor = FC.laborCatalog || {};
    const editingId = ctx.appUiState && ctx.appUiState().editingId;
    const current = editingId ? (ctx.currentList().find((item)=> String(item && item.id || '') === String(editingId)) || null) : null;
    const oldCode = current ? String(current.rateKey || current.rateCode || current.rateType || '') : '';
    if(labor.validateRateProfile){
      const result = labor.validateRateProfile(data, ctx.currentList().filter((item)=> String(item && item.id || '') !== String(editingId || '')), oldCode ? { oldCode } : {});
      if(!result || !result.ok){
        ctx.info('Nie można zapisać stawki godzinowej', String((result && result.message) || 'Sprawdź nazwę, kod techniczny i kwotę stawki.'));
        return false;
      }
    }
    return true;
  }
  function validateQuoteRateLaborAutomat(data){
    if(!(ctx.currentListKind && ctx.currentListKind() === 'quoteRates')) return true;
    if(isQuoteRateHourlyRow(data)) return true;
    const labor = FC.laborCatalog || {};
    const raw = String(data && (data.workAutomatCode || data.automatCode || data.laborAutomatCode) || '').trim();
    const code = labor.normalizeWorkAutomatCode ? labor.normalizeWorkAutomatCode(raw) : raw;
    if(!code){
      // Legacy fallback: stare, istniejące pozycje bez nowego automatu mogą zostać zapisane bez wymuszania migracji.
      // Nowe pozycje startują z manual_fixed w formularzu, więc nadal dostają automat w nowym modelu.
      if(ctx.appUiState && ctx.appUiState().editingId) return true;
      ctx.info('Brak automatu robocizny', 'Wybierz automat robocizny dla nowej stawki wyceny mebli.');
      return false;
    }
    if(labor.isValidWorkAutomatCode && !labor.isValidWorkAutomatCode(code)){ ctx.info('Błędny kod techniczny', 'Kod techniczny automatu może mieć tylko małe litery, cyfry i podkreślenia.'); return false; }
    try{
      const store = ctx.catalogStore && ctx.catalogStore();
      const list = store && typeof store.getLaborAutomats === 'function' ? store.getLaborAutomats() : [];
      const found = labor.findWorkAutomat ? labor.findWorkAutomat(list, code) : null;
      if(!found){ ctx.info('Nieznany automat robocizny', 'Wybrany kod automatu nie istnieje w słowniku automatów robocizny.'); return false; }
    }catch(_){ }
    return true;
  }
  function validateServiceForm(data){
    if(!String(data && data.name || '').trim()){ ctx.info('Brak nazwy', 'Wprowadź nazwę usługi, zanim ją zapiszesz.'); return false; }
    if(!String(data && data.category || '').trim()){ ctx.info('Brak kategorii', 'Wybierz kategorię usługi.'); return false; }
    if(!validateQuoteRateHourlyProfile(data)) return false;
    if(!validateQuoteRateLaborAutomat(data)) return false;
    return true;
  }
  function editedTimestamp(){ try{ return new Date().toISOString(); }catch(_){ return String(Date.now()); } }
  function markPriceAsUserEdited(payload){
    return Object.assign({}, payload || {}, { starterPrice:false, priceUserEditedAt:editedTimestamp() });
  }

  function upsertCurrentList(payload){
    const next = ctx.currentList();
    if(ctx.appUiState().editingId){
      const idx = next.findIndex((item)=> item.id === ctx.appUiState().editingId);
      if(idx >= 0) next[idx] = Object.assign({}, next[idx], payload);
    }else next.push(Object.assign({ id:FC.utils.uid() }, payload));
    ctx.saveCurrentList(next);
  }

  function saveMaterialFromForm(){
    const data = ctx.getCurrentMaterialDraft(); if(!validateMaterialForm(data)) return false;
    upsertCurrentList(markPriceAsUserEdited(Object.assign({}, data, { price:Number(data.price) || 0, hasGrain:!!data.hasGrain })));
    ctx.doClosePriceItemModal(); ctx.renderPriceModal(); try{ renderCabinetModal(); }catch(_){ } return true;
  }
  function saveAccessoryFromForm(){
    const data = ctx.getCurrentAccessoryDraft(); if(!validateAccessoryForm(data)) return false;
    let payload = Object.assign({}, data, { price:Number(data.price) || 0 });
    try{
      if(FC.hardwareCatalog && typeof FC.hardwareCatalog.normalizeAccessory === 'function') payload = FC.hardwareCatalog.normalizeAccessory(payload, FC.utils && FC.utils.uid);
    }catch(_){ }
    upsertCurrentList(markPriceAsUserEdited(payload));
    ctx.doClosePriceItemModal(); ctx.renderPriceModal(); return true;
  }
  function saveServiceFromForm(){
    try{ if(ctx.currentListKind() === 'quoteRates' && FC.wycenaCore && typeof FC.wycenaCore.ensureServiceCatalogInRuntime === 'function') FC.wycenaCore.ensureServiceCatalogInRuntime(); }catch(_){ }
    const data = ctx.getCurrentServiceDraft(); if(!validateServiceForm(data)) return false;
    const payload = markPriceAsUserEdited(Object.assign({}, data, { price:Number(data.price) || 0 }));
    try{
      if(ctx.currentListKind() === 'quoteRates' && FC.laborCatalog && typeof FC.laborCatalog.normalizeDefinition === 'function'){
        upsertCurrentList(FC.laborCatalog.normalizeDefinition(payload));
      }else upsertCurrentList(payload);
    }catch(_){ upsertCurrentList(payload); }
    ctx.doClosePriceItemModal(); ctx.renderPriceModal(); return true;
  }
  async function saveActivePriceItem(){
    if(!ctx.runtimeState.itemModalOpen) return false;
    if(!ctx.isItemDirty()) return ctx.requestClosePriceItemModal('exit');
    const ok = await ctx.confirmSave(); if(!ok) return false;
    const formKind = ctx.currentConfig().formKind;
    if(formKind === 'material') return saveMaterialFromForm();
    if(formKind === 'accessory') return saveAccessoryFromForm();
    return saveServiceFromForm();
  }
  async function deletePriceItem(item){
    if(ctx.currentListKind && ctx.currentListKind() === 'quoteRates' && isQuoteRateHourlyRow(item)){
      ctx.info('Nie można usunąć stawki godzinowej', 'Stawki godzinowe są trwałym cennikiem robocizny. Możesz zmienić nazwę, kwotę albo odznaczyć „Aktywna”, ale nie usuwaj kodu używanego przez czynności i wyceny.');
      return false;
    }
    const ok = await ctx.confirmDelete(); if(!ok) return false;
    const next = ctx.currentList().filter((row)=> String(row.id) !== String(item && item.id));
    ctx.saveCurrentList(next);
    if(String(ctx.appUiState().editingId || '') === String(item && item.id || '')) ctx.doClosePriceItemModal();
    ctx.renderPriceModal();
    try{ renderCabinetModal(); }catch(_){ }
    return true;
  }
  function deleteActivePriceItem(){ const item = ctx.currentEditedItem(); if(!item) return false; return deletePriceItem(item); }

  Object.assign(ctx, { saveMaterialFromForm, saveAccessoryFromForm, saveServiceFromForm, saveActivePriceItem, deletePriceItem, deleteActivePriceItem });
})();
