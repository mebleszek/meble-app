// js/app/cabinet/cabinet-hardware-requirements-panel.js
// Skrócony widok i edycja wymagań technicznych szafki w modalu WYWIADU. Pokazuje wymagania, nie konkretne produkty katalogowe.
(function(){
  'use strict';
  window.FC = window.FC || {};
  const FC = window.FC;

  function text(value){ return String(value == null ? '' : value).trim(); }
  function number(value){ const n = Number(String(value == null ? '' : value).replace(',', '.')); return Number.isFinite(n) ? n : 0; }
  function esc(value){
    return text(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function formatBool(value){ return value ? 'tak' : 'nie'; }

  function formatTechnicalValue(raw, key){
    if(raw == null) return '';
    if(typeof raw !== 'object'){
      if(typeof raw === 'boolean') return formatBool(raw);
      return text(raw);
    }
    if(raw.value != null){
      if(typeof raw.value === 'boolean') return formatBool(raw.value);
      if(String(key || '').indexOf('kat') !== -1 && !/[°]/.test(String(raw.value))) return `${raw.value}°`;
      return text(raw.value);
    }
    const from = raw.from != null ? number(raw.from) : null;
    const to = raw.to != null ? number(raw.to) : null;
    if(from != null && to != null && from > 0 && to > 0){
      return `${from}–${to}${String(key || '').indexOf('kat') !== -1 ? '°' : ''}`;
    }
    if(from != null && from > 0){
      return `min. ${from}${String(key || '').indexOf('kat') !== -1 ? '°' : ''}`;
    }
    if(to != null && to > 0){
      return `maks. ${to}${String(key || '').indexOf('kat') !== -1 ? '°' : ''}`;
    }
    return text(JSON.stringify(raw));
  }

  function param(params, key){
    return params && Object.prototype.hasOwnProperty.call(params, key) ? params[key] : null;
  }

  function row(label, value, extraClass){
    const val = text(value);
    if(!val) return '';
    return '<div class="cabinet-hardware-req-row' + (extraClass ? ' ' + esc(extraClass) : '') + '">' +
      '<div class="cabinet-hardware-req-row__label">' + esc(label) + '</div>' +
      '<div class="cabinet-hardware-req-row__value">' + esc(val) + '</div>' +
    '</div>';
  }

  function statusBadge(req){
    if(!req) return '';
    if(req.kind === 'hinge') return '<span class="cabinet-hardware-req-badge cabinet-hardware-req-badge--ok">wymagane</span>';
    if(req.kind === 'none') return '<span class="cabinet-hardware-req-badge cabinet-hardware-req-badge--empty">brak</span>';
    if(req.kind === 'future') return '<span class="cabinet-hardware-req-badge cabinet-hardware-req-badge--warn">w budowie</span>';
    return '<span class="cabinet-hardware-req-badge">wymaganie</span>';
  }

  function typeLabelFromParams(params, fallback){
    const angle = formatTechnicalValue(param(params, 'kat_rzeczywisty') || param(params, 'kat_otwarcia'), 'kat_rzeczywisty');
    const overlay = formatTechnicalValue(param(params, 'nalozenie'), 'nalozenie');
    const cls = formatTechnicalValue(param(params, 'klasa_kata'), 'klasa_kata');
    const parts = [];
    if(angle) parts.push(angle.replace(/^min\.\s*/i, ''));
    if(overlay) parts.push(overlay);
    if(cls && parts.join(' ').indexOf(cls) === -1) parts.push('klasa: ' + cls);
    const label = parts.join(' ').replace(/\s+/g, ' ').trim();
    return label || text(fallback) || 'wymaganie techniczne';
  }

  function hingeTechnicalSummary(req){
    const params = req && req.technicalParams || {};
    const bits = [];
    const typeLabel = typeLabelFromParams(params, req && req.label);
    if(typeLabel) bits.push(typeLabel);
    const prowadnik = formatTechnicalValue(param(params, 'typ_prowadnika') || param(params, 'prowadnik'), 'typ_prowadnika');
    if(prowadnik) bits.push('prowadnik: ' + prowadnik);
    if(param(params, 'hamulec') != null) bits.push('hamulec: ' + formatTechnicalValue(param(params, 'hamulec'), 'hamulec'));
    if(param(params, 'sprezyna') != null) bits.push('sprężyna: ' + formatTechnicalValue(param(params, 'sprezyna'), 'sprezyna'));
    return bits.join(' • ');
  }

  function hingeSummary(req){
    const qty = Math.max(0, Math.round(number(req && req.qty)));
    const bits = [];
    const tech = hingeTechnicalSummary(req);
    if(tech) bits.push(tech);
    bits.push('ilość: ' + (qty > 0 ? `${qty} kpl.` : '0 kpl.'));
    return bits.join(' • ');
  }

  function canonicalHingeTypeIds(){
    const api = FC.cabinetHardwareRequirements || {};
    const types = api.HINGE_TYPES || {};
    return new Set(Object.keys(types).map((key)=> text(types[key])).filter(Boolean));
  }

  function canonicalRequirementForOption(typeId){
    const id = text(typeId);
    if(!id || !canonicalHingeTypeIds().has(id)) return null;
    const api = FC.cabinetHardwareRequirements;
    if(!(api && typeof api.getHingeRequirementPreset === 'function')) return null;
    try{ return api.getHingeRequirementPreset(id, 'option_canonical_preview'); }
    catch(_){ return null; }
  }

  function addChoiceOption(map, option, sourceReq){
    const value = text(option && (option.value || option.typeId)) || text(sourceReq && sourceReq.typeId);
    if(!value || map.has(value)) return;
    const sourceOption = option && typeof option === 'object' ? option : {};
    const canonicalReq = canonicalRequirementForOption(value);
    const params = (canonicalReq && canonicalReq.technicalParams) || (option && option.technicalParams) || (sourceReq && sourceReq.technicalParams) || {};
    const label = (canonicalReq && text(canonicalReq.label)) || text(option && option.label) || typeLabelFromParams(params, sourceReq && sourceReq.label) || value;
    map.set(value, Object.assign({}, sourceOption, {
      value,
      typeId:value,
      label,
      technicalParams:params,
      description: hingeTechnicalSummary(Object.assign({}, sourceReq || canonicalReq || {}, { technicalParams:params, label, typeId:value }))
    }));
  }

  function buildHingeChoiceOptions(req){
    const api = FC.cabinetHardwareRequirements;
    const map = new Map();
    let catalogOptions = api && typeof api.getHingeRequirementOptions === 'function' ? api.getHingeRequirementOptions() : [];
    catalogOptions = Array.isArray(catalogOptions) ? catalogOptions : [];
    catalogOptions.forEach((opt)=> addChoiceOption(map, opt, opt && opt.requirement));

    // Kanoniczne wymagania techniczne nie są produktem katalogowym. Dodajemy je,
    // żeby panel zawsze pozwalał wybrać regułę szafki z poprawnymi cechami
    // (np. hamulec/sprężyna), nawet jeśli katalog ma jeszcze stare pozycje.
    try{
      const types = api && api.HINGE_TYPES || {};
      Object.keys(types).map((key)=> text(types[key])).filter(Boolean).forEach((typeId)=> {
        if(map.has(typeId)) return;
        const preset = api && typeof api.getHingeRequirementPreset === 'function' ? api.getHingeRequirementPreset(typeId, 'canonical_choice') : null;
        if(preset) addChoiceOption(map, { typeId, label:text(preset.label), canonicalChoice:true }, preset);
      });
    }catch(_){ }

    const current = text(req && req.typeId);
    if(current && !map.has(current)) addChoiceOption(map, { typeId:current, label:text(req && req.label) }, req);

    const defaultId = text(req && req.defaultTypeId);
    if(defaultId && !map.has(defaultId) && api && typeof api.getHingeRequirementPreset === 'function'){
      try{ addChoiceOption(map, { typeId:defaultId }, api.getHingeRequirementPreset(defaultId, 'default_preview')); }catch(_){ }
    }
    return Array.from(map.values());
  }

  function normalizeKey(value){
    return text(value).toLowerCase().replace(/ł/g, 'l').replace(/Ł/g, 'l').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '');
  }

  function scalarParamValue(params, key){
    const raw = param(params || {}, key);
    if(raw == null) return '';
    if(typeof raw === 'object'){
      if(raw.value != null) return raw.value;
      if(raw.from != null) return raw.from;
      if(raw.to != null) return raw.to;
    }
    return raw;
  }

  function displayParamValue(params, key){
    return formatTechnicalValue(param(params || {}, key), key) || text(scalarParamValue(params || {}, key));
  }

  function sameCascadeValue(a, b){
    return normalizeKey(a) === normalizeKey(b);
  }

  function getCatalogStore(){
    try{
      if(FC.catalogStore && typeof FC.catalogStore === 'function') return FC.catalogStore();
      if(FC.catalogStore && typeof FC.catalogStore === 'object') return FC.catalogStore;
    }catch(_){ }
    return null;
  }

  function getHardwareTechnicalDefinitions(){
    const store = getCatalogStore();
    try{ if(store && typeof store.getHardwareTechnicalParams === 'function') return store.getHardwareTechnicalParams() || []; }catch(_){ }
    return (FC.hardwareTechnicalParams && FC.hardwareTechnicalParams.DEFAULT_DEFINITIONS) || [];
  }

  function hingeCascadeFields(){
    const tech = FC.hardwareTechnicalParams || null;
    const definitions = getHardwareTechnicalDefinitions();
    let fields = [];
    try{
      if(tech && typeof tech.fieldsForCategory === 'function') fields = tech.fieldsForCategory(definitions, 'Zawiasy') || [];
    }catch(_){ fields = []; }
    if(!Array.isArray(fields) || !fields.length){
      fields = [
        { key:'nalozenie', label:'Typ / nakładanie kompletu zawiasowego', order:10, keyFeature:true, compareMode:'equal' },
        { key:'klasa_kata', label:'Klasa / zakres zamienności kąta', order:25, keyFeature:true, compareMode:'equal' },
        { key:'hamulec', label:'Hamulec / domyk', order:30, keyFeature:true, compareMode:'equal' },
        { key:'sprezyna', label:'Sprężyna', order:40, keyFeature:true, compareMode:'equal' },
        { key:'typ_prowadnika', label:'Wymagany typ prowadnika', order:50, keyFeature:true, compareMode:'equal' },
        { key:'forma_prowadnika', label:'Wymagana forma prowadnika', order:55, keyFeature:true, compareMode:'equal' }
      ];
    }
    const skip = new Set(['rola_kompletu','system_kompatybilnosci','pokrycie_prowadnika','kat_otwarcia','prowadnik']);
    return fields
      .filter((field)=> field && field.active !== false && field.key && !skip.has(text(field.key)))
      .filter((field)=> field.keyFeature !== false && text(field.compareMode || 'equal') !== 'ignore')
      .sort((a, b)=> (Number(a.order) || 0) - (Number(b.order) || 0) || text(a.label || a.key).localeCompare(text(b.label || b.key), 'pl'));
  }

  function fieldTitle(field){
    const label = text(field && (field.label || field.key)) || 'parametr';
    const lower = label.toLowerCase();
    if(field && field.key === 'nalozenie') return 'Wybierz typ / nakładanie kompletu zawiasowego';
    if(field && field.key === 'klasa_kata') return 'Wybierz klasę / zakres zamienności kąta';
    if(field && field.key === 'hamulec') return 'Wybierz hamulec / domyk';
    if(field && field.key === 'sprezyna') return 'Wybierz sprężynę';
    if(lower.startsWith('wybierz ')) return label;
    return 'Wybierz ' + lower;
  }

  function uniqueCascadeFieldOptions(options, key){
    const map = new Map();
    (Array.isArray(options) ? options : []).forEach((opt)=>{
      const params = opt && opt.technicalParams || {};
      const raw = scalarParamValue(params, key);
      const value = text(raw);
      const norm = normalizeKey(value);
      if(!norm || map.has(norm)) return;
      const label = displayParamValue(params, key) || value;
      map.set(norm, { value, label });
    });
    return Array.from(map.values()).sort((a, b)=> text(a.label).localeCompare(text(b.label), 'pl'));
  }

  function filterByCascadeValue(options, key, selected){
    const wanted = normalizeKey(selected);
    if(!wanted) return Array.isArray(options) ? options.slice() : [];
    return (Array.isArray(options) ? options : []).filter((opt)=> sameCascadeValue(scalarParamValue(opt && opt.technicalParams || {}, key), selected));
  }

  async function pickCascadeField(choiceApi, cfg){
    const values = uniqueCascadeFieldOptions(cfg.options, cfg.key);
    if(!values.length) return '';
    const current = text(scalarParamValue(cfg.currentParams || {}, cfg.key));
    if(values.length === 1) return values[0].value;
    const picked = await choiceApi.openRozrysChoiceOverlay({
      title:cfg.title,
      value:values.find((item)=> sameCascadeValue(item.value, current)) ? current : '',
      options:values.map((item)=> ({ value:item.value, label:item.label }))
    });
    return picked == null ? null : picked;
  }

  function optionId(option){
    return text(option && (option.value || option.typeId));
  }

  async function pickFinalHingeOption(choiceApi, options, req, title){
    const list = (Array.isArray(options) ? options : []).filter((opt)=> !!optionId(opt));
    if(!list.length) return null;
    const currentType = text(req && req.typeId);
    const hasCurrent = list.some((opt)=> optionId(opt) === currentType);
    const picked = await choiceApi.openRozrysChoiceOverlay({
      title:title || 'Wybierz wymaganie kompletu zawiasowego',
      value:hasCurrent ? currentType : '',
      options:list.map((opt)=> ({
        value:optionId(opt),
        label:text(opt && opt.label) || optionId(opt),
        description:text(opt && opt.description)
      }))
    });
    return picked == null ? null : picked;
  }

  async function openHingeChoice(req){
    const choiceApi = FC && FC.rozrysChoice;
    if(!(choiceApi && typeof choiceApi.openRozrysChoiceOverlay === 'function')) return null;
    const allOptions = buildHingeChoiceOptions(req);
    if(!allOptions.length) return null;

    let filtered = allOptions.slice();
    const currentParams = req && req.technicalParams || {};
    const cascade = hingeCascadeFields().map((field)=> ({ key:text(field.key), title:fieldTitle(field), field }));

    let openedChoice = false;
    for(const step of cascade){
      const values = uniqueCascadeFieldOptions(filtered, step.key);
      if(values.length <= 1){
        if(values.length === 1) filtered = filterByCascadeValue(filtered, step.key, values[0].value);
        continue;
      }
      openedChoice = true;
      const picked = await pickCascadeField(choiceApi, Object.assign({}, step, { options:filtered, currentParams }));
      if(picked == null) return null;
      filtered = filterByCascadeValue(filtered, step.key, picked);
      if(!filtered.length) return null;
    }

    // Jeżeli wszystkie kroki kaskady mają tylko jedną wartość, nadal otwieramy
    // aplikacyjny modal końcowy. Przycisk „Zmień” nie może wyglądać jak aktywny
    // i nie pokazać żadnego wyboru. Sam wybór bieżącej wartości nie zapisuje
    // jednak override — to pilnuje obsługa kliknięcia poniżej.
    if(!openedChoice) return pickFinalHingeOption(choiceApi, filtered.length ? filtered : allOptions, req, 'Wybierz wymaganie kompletu zawiasowego');

    const currentType = text(req && req.typeId);
    if(filtered.length > 1) return pickFinalHingeOption(choiceApi, filtered, req, 'Doprecyzuj wymaganie kompletu zawiasowego');
    const preferred = filtered.find((opt)=> optionId(opt) === currentType) || filtered[0];
    return optionId(preferred);
  }

  function actionButtons(req){
    const doorKey = text(req && req.doorKey) || 'single';
    const disabledRestore = req && req.overridden ? '' : ' disabled aria-disabled="true"';
    return '<div class="cabinet-hardware-req-actions">' +
      '<button type="button" class="cabinet-hardware-req-action cabinet-hardware-req-action--change" data-req-action="hinge-change" data-door-key="' + esc(doorKey) + '">Zmień</button>' +
      '<button type="button" class="cabinet-hardware-req-action cabinet-hardware-req-action--default" data-req-action="hinge-default" data-door-key="' + esc(doorKey) + '"' + disabledRestore + '>Przywróć domyślne</button>' +
    '</div>';
  }

  function pairActionButtons(doors){
    const list = Array.isArray(doors) ? doors.filter((item)=> item && item.kind === 'hinge') : [];
    const doorKeys = list.map((req)=> text(req && req.doorKey)).filter(Boolean);
    const anyOverride = list.some((req)=> !!(req && req.overridden));
    const disabledRestore = anyOverride ? '' : ' disabled aria-disabled="true"';
    const keysAttr = esc(doorKeys.join(','));
    return '<div class="cabinet-hardware-req-pair-actions">' +
      '<button type="button" class="cabinet-hardware-req-action cabinet-hardware-req-action--change cabinet-hardware-req-action--pair" data-req-action="hinge-change-all" data-door-keys="' + keysAttr + '">Zmień oba</button>' +
      '<button type="button" class="cabinet-hardware-req-action cabinet-hardware-req-action--default cabinet-hardware-req-action--pair" data-req-action="hinge-default-all" data-door-keys="' + keysAttr + '"' + disabledRestore + '>Przywróć domyślne dla obu</button>' +
    '</div>';
  }

  function compactDoor(req, sideClass){
    const state = req && req.overridden ? 'Ręcznie' : 'Domyślnie';
    return '<div class="cabinet-hardware-req-door cabinet-hardware-req-door--compact cabinet-hardware-req-door--' + esc(sideClass || '') + '">' +
      '<div class="cabinet-hardware-req-door__title">' + esc(req && req.doorLabel || 'Drzwiczki') + '</div>' +
      '<div class="cabinet-hardware-req-summary">' +
        '<div class="cabinet-hardware-req-summary__state">' + esc(state) + '</div>' +
        '<div class="cabinet-hardware-req-summary__value">' + esc(hingeSummary(req)) + '</div>' +
      '</div>' +
      actionButtons(req) +
    '</div>';
  }
  function compactDoorGroup(list, sideClass){
    const rows = Array.isArray(list) ? list.filter((item)=> item && item.kind === 'hinge') : [];
    const first = rows[0] || {};
    const state = rows.some((req)=> !!(req && req.overridden)) ? 'Ręcznie' : 'Domyślnie';
    const summary = rows.map((req)=> hingeSummary(req)).filter(Boolean).join(' + ');
    return '<div class="cabinet-hardware-req-door cabinet-hardware-req-door--compact cabinet-hardware-req-door--' + esc(sideClass || '') + '">' +
      '<div class="cabinet-hardware-req-door__title">' + esc(first.doorLabel || 'Drzwiczki') + '</div>' +
      '<div class="cabinet-hardware-req-summary">' +
        '<div class="cabinet-hardware-req-summary__state">' + esc(state) + '</div>' +
        '<div class="cabinet-hardware-req-summary__value">' + esc(summary) + '</div>' +
      '</div>' +
      actionButtons(Object.assign({}, first, { overridden:rows.some((req)=> !!(req && req.overridden)) })) +
    '</div>';
  }

  function groupDoorRequirements(doors){
    const groups = [];
    const byKey = new Map();
    (Array.isArray(doors) ? doors : []).forEach((req)=> {
      const key = text(req && req.doorKey) || 'single';
      if(!byKey.has(key)){
        byKey.set(key, []);
        groups.push(byKey.get(key));
      }
      byKey.get(key).push(req);
    });
    return groups;
  }

  function compactAggregate(req){
    const state = req && req.overridden ? 'Ręcznie' : 'Domyślnie';
    return '<div class="cabinet-hardware-req-card__body cabinet-hardware-req-card__body--compact">' +
      '<div class="cabinet-hardware-req-summary">' +
        '<div class="cabinet-hardware-req-summary__state">' + esc(state) + '</div>' +
        '<div class="cabinet-hardware-req-summary__value">' + esc(hingeSummary(req)) + '</div>' +
      '</div>' +
    '</div>';
  }

  function hingeBody(req){
    const doors = Array.isArray(req && req.doorRequirements) ? req.doorRequirements.filter((item)=> item && item.kind === 'hinge') : [];
    const groups = groupDoorRequirements(doors);
    if(groups.length === 2){
      const pairDoors = groups.map((items)=> items[0]).filter(Boolean);
      return '<div class="cabinet-hardware-req-door-pair-wrap">' +
        '<div class="cabinet-hardware-req-door-pair cabinet-hardware-req-door-pair--compact">' +
          compactDoorGroup(groups[0], 'left') +
          '<div class="cabinet-hardware-req-door-divider" aria-hidden="true"></div>' +
          compactDoorGroup(groups[1], 'right') +
        '</div>' +
        pairActionButtons(pairDoors) +
      '</div>';
    }
    if(groups.length > 0){
      return '<div class="cabinet-hardware-req-door-list cabinet-hardware-req-door-list--compact">' + groups.map((items)=> compactDoorGroup(items, 'single')).join('') + '</div>';
    }
    return compactAggregate(req);
  }

  function noneRows(req){
    const rows = [];
    rows.push(row('Powód', req && req.reason ? req.reason : 'Ta szafka nie wymaga tego okucia.'));
    if(req && req.canEnableWithFlag) rows.push(row('Można włączyć', 'pole techniczne szafki: ' + req.canEnableWithFlag, 'cabinet-hardware-req-row--muted'));
    if(req && req.ruleId) rows.push(row('Reguła źródłowa', req.ruleId, 'cabinet-hardware-req-row--muted'));
    return rows.join('');
  }

  function genericRows(req){
    const rows = [];
    const params = req && req.technicalParams && typeof req.technicalParams === 'object' ? req.technicalParams : {};
    Object.keys(params).forEach((key)=> rows.push(row(key, formatTechnicalValue(params[key], key))));
    if(req && req.reason) rows.push(row('Powód', req.reason));
    if(req && req.note) rows.push(row('Uwaga', req.note, 'cabinet-hardware-req-row--note'));
    if(req && req.ruleId) rows.push(row('Reguła źródłowa', req.ruleId, 'cabinet-hardware-req-row--muted'));
    return rows.join('') || row('Status', 'Brak szczegółowych parametrów dla tego wymagania.');
  }

  function requirementCard(req){
    const title = text((req && req.displayTitle) || (req && req.category) || (req && req.hardwareGroup) || 'Okucie');
    let body = '';
    if(req && req.kind === 'hinge') body = hingeBody(req);
    else if(req && req.kind === 'none') body = '<div class="cabinet-hardware-req-card__body">' + noneRows(req) + '</div>';
    else body = '<div class="cabinet-hardware-req-card__body">' + genericRows(req) + '</div>';
    return '<div class="cabinet-hardware-req-card" data-requirement-kind="' + esc(req && req.kind || '') + '">' +
      '<div class="cabinet-hardware-req-card__head">' +
        '<div>' +
          '<div class="cabinet-hardware-req-card__title">' + esc(title) + '</div>' +
          '<div class="cabinet-hardware-req-card__subtitle">Skrót wymagań. Szczegóły zmieniasz tylko po kliknięciu.</div>' +
        '</div>' +
        statusBadge(req) +
      '</div>' + body +
    '</div>';
  }

  function getRequirements(room, draft){
    const api = FC.cabinetHardwareRequirements;
    if(!(api && typeof api.getCabinetHardwareRequirements === 'function')) return [];
    try{ return api.getCabinetHardwareRequirements(room, draft) || []; }
    catch(_){ return []; }
  }

  function findDoorRequirement(container, doorKey){
    const requirements = container && container.__cabinetHardwareReqLastRequirements || [];
    const hinge = requirements.find((req)=> req && req.kind === 'hinge');
    const doors = Array.isArray(hinge && hinge.doorRequirements) ? hinge.doorRequirements : [];
    return doors.find((req)=> text(req && req.doorKey) === text(doorKey || 'single')) || (text(doorKey) === 'single' ? hinge : null);
  }

  function getContext(container){
    return container && container.__cabinetHardwareReqContext && typeof container.__cabinetHardwareReqContext === 'object'
      ? container.__cabinetHardwareReqContext
      : null;
  }

  function findChoiceOptionByTypeId(req, typeId){
    const id = text(typeId);
    if(!id) return null;
    return buildHingeChoiceOptions(req).find((opt)=> optionId(opt) === id) || null;
  }

  function buildOverridePatchFromChoice(req, picked){
    const id = text(picked);
    const patch = { typeId:id };
    if(!id) return patch;
    const opt = findChoiceOptionByTypeId(req, id);
    if(opt && opt.technicalParams && typeof opt.technicalParams === 'object') patch.technicalParams = opt.technicalParams;
    if(opt && text(opt.label)) patch.label = text(opt.label);
    return patch;
  }

  function bindEvents(container){
    if(!container || !container.addEventListener || container.__cabinetHardwareReqBound) return;
    container.__cabinetHardwareReqBound = true;
    container.addEventListener('click', async function(ev){
      const target = ev && ev.target && ev.target.closest ? ev.target.closest('[data-req-action]') : null;
      if(!target) return;
      const action = target.getAttribute('data-req-action') || '';
      if(!['hinge-change','hinge-default','hinge-change-all','hinge-default-all'].includes(action)) return;
      ev.preventDefault();
      const ctxAtClick = getContext(container);
      if(!ctxAtClick || !ctxAtClick.draft) return;
      const room = ctxAtClick.room;
      const draft = ctxAtClick.draft;
      const opts = ctxAtClick.opts || {};
      const doorKey = target.getAttribute('data-door-key') || 'single';
      const doorKeysAttr = target.getAttribute('data-door-keys') || '';
      const doorKeys = doorKeysAttr.split(',').map(text).filter(Boolean);
      const api = FC.cabinetHardwareRequirements;
      if(action === 'hinge-default' || action === 'hinge-default-all'){
        const keys = action === 'hinge-default-all' ? doorKeys : [doorKey];
        keys.forEach((key)=> { if(api && typeof api.setHingeDoorOverride === 'function') api.setHingeDoorOverride(draft, key, { typeId:'' }); });
        if(opts && typeof opts.onChange === 'function') opts.onChange({ doorKey:keys[0] || doorKey, doorKeys:keys, typeId:'', restoredDefault:true, draft });
        renderPanel(container, room, draft, opts || {});
        return;
      }
      const req = action === 'hinge-change-all' ? (findDoorRequirement(container, doorKeys[0] || 'left') || findDoorRequirement(container, 'single')) : findDoorRequirement(container, doorKey);
      const picked = await openHingeChoice(req);
      if(picked == null) return;
      const latest = getContext(container) || ctxAtClick;
      const currentRoom = latest.room || room;
      const currentDraft = latest.draft || draft;
      const currentOpts = latest.opts || opts || {};
      const keys = action === 'hinge-change-all' ? (doorKeys.length ? doorKeys : [doorKey]) : [doorKey];
      let changed = false;
      keys.forEach((key)=> {
        const currentReq = findDoorRequirement(container, key);
        if(text(currentReq && currentReq.typeId) === text(picked) && !(currentReq && currentReq.overridden)) return;
        if(api && typeof api.setHingeDoorOverride === 'function'){
          api.setHingeDoorOverride(currentDraft, key, buildOverridePatchFromChoice(currentReq || req, picked));
          changed = true;
        }
      });
      if(!changed) return;
      if(currentOpts && typeof currentOpts.onChange === 'function') currentOpts.onChange({ doorKey:keys[0] || doorKey, doorKeys:keys, typeId:picked, draft:currentDraft });
      renderPanel(container, currentRoom, currentDraft, currentOpts || {});
    });
  }

  function renderPanel(container, room, draft, opts){
    if(!container) return [];
    const options = opts || {};
    container.__cabinetHardwareReqContext = { room, draft, opts:options };
    const requirements = getRequirements(room, draft);
    container.__cabinetHardwareReqLastRequirements = requirements;
    const cards = requirements.map(requirementCard).join('');
    container.innerHTML = '<div class="cabinet-hardware-req-panel cabinet-hardware-req-panel--compact">' +
      '<div class="cabinet-hardware-req-panel__head">' +
        '<div>' +
          '<h3 class="section-title cabinet-hardware-req-panel__title">Wymagania techniczne do wyceny</h3>' +
          '<div class="cabinet-hardware-req-panel__hint">Skrót tego, co WYCENA ma dobrać z katalogu okuć. Nie wybieramy tu producenta ani modelu.</div>' +
        '</div>' +
      '</div>' +
      '<div class="cabinet-hardware-req-panel__cards">' + (cards || '<div class="cabinet-hardware-req-empty">Brak wymagań technicznych dla tej szafki.</div>') + '</div>' +
    '</div>';
    bindEvents(container);
    return requirements;
  }

  FC.cabinetHardwareRequirementsPanel = {
    renderPanel,
    getRequirements,
    formatTechnicalValue,
    buildHingeChoiceOptions,
    openHingeChoice,
  };
})();
