(function(){
  const ns = (window.FC = window.FC || {});

function getCabinetModalValidationApi(){ return (window.FC && window.FC.cabinetModalValidation) || {}; }
function getCabinetModalDraftApi(){ return (window.FC && window.FC.cabinetModalDraft) || {}; }
function getCabinetModalFieldsApi(){ return (window.FC && window.FC.cabinetModalFields) || {}; }
function getCabinetModalLaborApi(){ return (window.FC && window.FC.cabinetModalLabor) || {}; }
function getCabinetModalSetWizardApi(){ return (window.FC && window.FC.cabinetModalSetWizard) || {}; }
function getCabinetModalStandingApi(){ return (window.FC && window.FC.cabinetModalStanding) || {}; }
function getCabinetModalHangingApi(){ return (window.FC && window.FC.cabinetModalHanging) || {}; }
function getCabinetModalModuleApi(){ return (window.FC && window.FC.cabinetModalModule) || {}; }
function getCabinetModalFinalizeApi(){ return (window.FC && window.FC.cabinetModalFinalize) || {}; }
function inferUniqueFallbackTypeFromSubType(subTypeVal){
  const st = String(subTypeVal || '');
  if(['zlewowa','zmywarkowa','lodowkowa','piekarnikowa'].includes(st)) return 'stojąca';
  if(st === 'dolna_podblatowa') return 'wisząca';
  return null;
}

function doesTypeOwnSubType(typeVal, subTypeVal){
  const st = String(subTypeVal || '');
  if(!typeVal || !st) return true;
  const opts = getSubTypeOptionsForTypeSafe(typeVal);
  const values = Array.isArray(opts) ? opts.map(function(opt){ return String(opt && opt.v || ''); }) : [];
  return values.includes(st);
}

function resolveCabinetModalTypeForUi(typeVal, subTypeVal){
  const st = String(subTypeVal || '');
  if(!typeVal){
    return inferUniqueFallbackTypeFromSubType(st) || typeVal;
  }
  if(doesTypeOwnSubType(typeVal, st)) return typeVal;
  const fallbackType = inferUniqueFallbackTypeFromSubType(st);
  if(fallbackType) return fallbackType;
  return typeVal;
}

function getCabinetModalTypeApi(typeVal, subTypeVal){
  const effectiveType = resolveCabinetModalTypeForUi(typeVal, subTypeVal);
  if(effectiveType === 'stojąca') return getCabinetModalStandingApi();
  if(effectiveType === 'wisząca') return getCabinetModalHangingApi();
  if(effectiveType === 'moduł') return getCabinetModalModuleApi();
  return {};
}


function isFridgeCabinetDraft(draft){
  const d = draft && typeof draft === 'object' ? draft : {};
  return String(d.type || '') === 'stojąca' && String(d.subType || '') === 'lodowkowa';
}

function syncCabinetMaterialVisibility(draft){
  const hideGeneralFrontFields = isFridgeCabinetDraft(draft);
  ['cmFrontMaterialWrap','cmFrontColorWrap'].forEach(function(id){
    const wrap = document.getElementById(id);
    if(wrap) wrap.style.display = hideGeneralFrontFields ? 'none' : '';
  });
}

function callCabinetFrontsHelper(fnName, args, fallback){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.callCabinetFrontsHelper === 'function') return api.callCabinetFrontsHelper(fnName, args, fallback);
  if(typeof fallback === 'function') return fallback.apply(null, args || []);
  throw new Error('Brak helpera cabinetFronts: ' + fnName);
}

function callCalcHelper(fnName, args, fallback){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.callCalcHelper === 'function') return api.callCalcHelper(fnName, args, fallback);
  if(typeof fallback === 'function') return fallback.apply(null, args || []);
  throw new Error('Brak helpera calc: ' + fnName);
}

function calcTopForSetSafe(room, blende, sumLowerHeights){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.calcTopForSetSafe === 'function') return api.calcTopForSetSafe(room, blende, sumLowerHeights);
  return 0;
}

function getSubTypeOptionsForTypeSafe(typeVal){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.getSubTypeOptionsForTypeSafe === 'function') return api.getSubTypeOptionsForTypeSafe(typeVal);
  return [{ v:'standardowa', t:'Standardowa' }];
}
function applyTypeRulesSafe(room, updated, typeVal){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.applyTypeRulesSafe === 'function') return api.applyTypeRulesSafe(room, updated, typeVal);
  updated.type = typeVal;
  return updated;
}
function applySubTypeRulesSafe(room, updated, subTypeVal){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.applySubTypeRulesSafe === 'function') return api.applySubTypeRulesSafe(room, updated, subTypeVal);
  updated.subType = subTypeVal;
  return updated;
}
function ensureFrontCountRulesSafe(cab){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.ensureFrontCountRulesSafe === 'function') return api.ensureFrontCountRulesSafe(cab);
  return cab;
}
function cabinetAllowsFrontCountSafe(cab){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.cabinetAllowsFrontCountSafe === 'function') return api.cabinetAllowsFrontCountSafe(cab);
  return true;
}
function getFlapFrontCountSafe(cab){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.getFlapFrontCountSafe === 'function') return api.getFlapFrontCountSafe(cab);
  return Number(cab && cab.frontCount) || 0;
}
function syncDraftFromCabinetModalFormSafe(draft){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.syncDraftFromCabinetModalFormSafe === 'function') return api.syncDraftFromCabinetModalFormSafe(draft);
  return draft;
}
function validateAventosForDraftSafe(room, draft){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.validateAventosForDraftSafe === 'function') return api.validateAventosForDraftSafe(room, draft);
  return null;
}
function applyAventosValidationUISafe(room, draft){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.applyAventosValidationUISafe === 'function') return api.applyAventosValidationUISafe(room, draft);
  return null;
}
function addFrontSafe(room, front){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.addFrontSafe === 'function') return api.addFrontSafe(room, front);
  projectData[room].fronts = projectData[room].fronts || [];
  projectData[room].fronts.push(front);
  return front;
}
function removeFrontsForSetSafe(room, setId){
  const api = getCabinetModalValidationApi();
  if(api && typeof api.removeFrontsForSetSafe === 'function') return api.removeFrontsForSetSafe(room, setId);
  projectData[room].fronts = (projectData[room].fronts || []).filter(function(front){ return String(front && front.setId) !== String(setId); });
}

function makeDefaultCabinetDraftForRoom(room){
  const api = getCabinetModalDraftApi();
  if(api && typeof api.makeDefaultCabinetDraftForRoom === 'function') return api.makeDefaultCabinetDraftForRoom(room);
  return null;
}

function makeDefaultCabinetDraftForType(room, typeValue){
  const api = getCabinetModalDraftApi();
  if(api && typeof api.makeDefaultCabinetDraftForType === 'function') return api.makeDefaultCabinetDraftForType(room, typeValue);
  return makeDefaultCabinetDraftForRoom(room);
}

function openCabinetModalForAdd(){
  const draftApi = getCabinetModalDraftApi();
  if(draftApi && typeof draftApi.beginAddState === 'function') draftApi.beginAddState(uiState.roomType);
  else {
    cabinetModalState.mode = 'add';
    cabinetModalState.editingId = null;
    cabinetModalState.setEditId = null;
    cabinetModalState.chosen = null;
    cabinetModalState.setPreset = null;
    cabinetModalState.draft = makeDefaultCabinetDraftForRoom(uiState.roomType);
    try{ cabinetModalState.chosen = cabinetModalState.draft && cabinetModalState.draft.type ? cabinetModalState.draft.type : null; }catch(_){ }
  }
  renderCabinetModal();
  const m = document.getElementById('cabinetModal');
  if(m){
    m.style.display = 'flex';
    try{
      m.classList.add('modal-open-guard');
      requestAnimationFrame(() => setTimeout(() => {
        try{ m.classList.remove('modal-open-guard'); }catch(_){ }
      }, 260));
    }catch(_){ }
  }
  lockModalScroll();
}

function lockModalScroll(){
  document.documentElement.classList.add('modal-lock');
  document.body.classList.add('modal-lock');
}
function unlockModalScroll(){
  document.documentElement.classList.remove('modal-lock');
  document.body.classList.remove('modal-lock');
}

function openCabinetModalForEdit(cabId){
  cabId = String(cabId);
  try{
    const listScrollMemory = window.FC && window.FC.listScrollMemory;
    if(listScrollMemory && typeof listScrollMemory.rememberForCabinet === 'function') listScrollMemory.rememberForCabinet(uiState && uiState.activeTab, cabId);
  }catch(_){ }
  const room = uiState.roomType; if(!room) return;
  const cab = projectData[room].cabinets.find(c => String(c.id) === cabId);
  if(!cab) return;

  if(cab.setId){
    openSetWizardForEdit(cab.setId);
    return;
  }

  const draftApi = getCabinetModalDraftApi();
  if(draftApi && typeof draftApi.beginEditState === 'function') draftApi.beginEditState(cabId, cab);
  else {
    cabinetModalState.mode = 'edit';
    cabinetModalState.editingId = cabId;
    cabinetModalState.setEditId = null;
    cabinetModalState.chosen = cab.type;
    cabinetModalState.setPreset = null;
    cabinetModalState.draft = FC.utils.clone(cab);
  }
  renderCabinetModal();
  const m = document.getElementById('cabinetModal');
  if(m){
    m.style.display = 'flex';
    try{
      m.classList.add('modal-open-guard');
      requestAnimationFrame(() => setTimeout(() => {
        try{ m.classList.remove('modal-open-guard'); }catch(_){ }
      }, 260));
    }catch(_){ }
  }
  lockModalScroll();
}

function openSetWizardForEdit(setId){
  const api = getCabinetModalSetWizardApi();
  if(api && typeof api.openSetWizardForEdit === 'function') return api.openSetWizardForEdit(setId);
  return null;
}

function closeCabinetModal(){
  unlockModalScroll();
  document.getElementById('cabinetModal').style.display = 'none';
  try{
    const listScrollMemory = window.FC && window.FC.listScrollMemory;
    if(listScrollMemory && typeof listScrollMemory.restorePending === 'function') listScrollMemory.restorePending();
  }catch(_){ }
}

/* ===== Cabinet Modal rendering ===== */
function renderCabinetTypeChoices(){
  const wrap = document.getElementById('cabinetTypeChoices');
  wrap.innerHTML = '';
  const choices = [
    { key:'stojąca', title:'Szafka dolna', sub:'Standardowy dół', ico:'⬇️' },
    { key:'wisząca', title:'Szafka wisząca', sub:'Standardowa góra', ico:'⬆️' },
    { key:'moduł', title:'Moduł', sub:'Wkład / segment', ico:'🧱' },
    { key:'zestaw', title:'Zestaw', sub:'Standardy na ikonkach', ico:'🧩' }
  ];

  choices.forEach(ch => {
    const tile = document.createElement('div');
    tile.className = 'choice-tile' + (cabinetModalState.chosen === ch.key ? ' selected' : '');
    tile.innerHTML = `
      <div class="choice-ico">${ch.ico}</div>
      <div>
        <div class="choice-title">${ch.title}</div>
        <div class="choice-sub">${ch.sub}</div>
      </div>
    `;
    tile.addEventListener('click', () => {
      cabinetModalState.chosen = ch.key;

      if(ch.key !== 'zestaw'){
        const room = uiState.roomType;


  function draftHeightIncludesLegs(){
    const det = draft && draft.details && typeof draft.details === 'object' ? draft.details : {};
    const raw = det.heightIncludesLegs;
    if(raw === false || raw === 0) return false;
    const txt = String(raw == null ? '' : raw).trim().toLowerCase();
    if(['0','false','nie','no','off'].includes(txt)) return false;
    return true;
  }

  function effectiveDraftLegHeight(){
    const det = draft && draft.details && typeof draft.details === 'object' ? draft.details : {};
    if(det.legHeightCm != null && String(det.legHeightCm).trim() !== '') return Number(det.legHeightCm) || 0;
    try{ return Number(projectData && projectData[room] && projectData[room].settings && projectData[room].settings.legHeight) || 0; }catch(_){ return 0; }
  }
  function syncLegHeightUi(){
    const wrap = document.getElementById('cmLegHeightWrap');
    const input = document.getElementById('cmLegHeight');
    const checkWrap = document.getElementById('cmHeightIncludesLegsWrap');
    const check = document.getElementById('cmHeightIncludesLegs');
    if(!wrap || !input) return;
    const show = String(draft && draft.type || '') === 'stojąca';
    if(checkWrap) checkWrap.style.display = show ? '' : 'none';
    wrap.style.display = show ? '' : 'none';
    if(show){
      const includes = draftHeightIncludesLegs();
      if(check) check.checked = includes;
      input.value = effectiveDraftLegHeight();
      input.disabled = !includes;
      input.closest && input.closest('div') && input.closest('div').classList.toggle('is-muted', !includes);
    }
  }

    projectData[room].cabinets = projectData[room].cabinets || [];
        if(cabinetModalState.mode === 'add'){
          cabinetModalState.draft = makeDefaultCabinetDraftForType(room, ch.key) || cabinetModalState.draft || makeDefaultCabinetDraftForRoom(room);
        }
        if(!cabinetModalState.draft) cabinetModalState.draft = makeDefaultCabinetDraftForRoom(room);

        if(cabinetModalState.mode !== 'add' || String(cabinetModalState.draft.type || '') !== ch.key){
          applyTypeRulesSafe(room, cabinetModalState.draft, ch.key);
        } else {
          cabinetModalState.draft.type = ch.key;
        }
        const opts = getSubTypeOptionsForTypeSafe(ch.key).map(o=>o.v);
        if(!opts.includes(cabinetModalState.draft.subType)) cabinetModalState.draft.subType = opts[0];
        applySubTypeRulesSafe(room, cabinetModalState.draft, cabinetModalState.draft.subType);
        ensureFrontCountRulesSafe(cabinetModalState.draft);
      }
      renderCabinetModal();
    });
    wrap.appendChild(tile);
  });
}

function populateSelect(el, options, selected){
  const api = getCabinetModalFieldsApi();
  if(api && typeof api.populateSelect === 'function') return api.populateSelect(el, options, selected);
  if(!el) return;
  el.innerHTML = '';
}

function populateFrontColorsTo(selectEl, typeVal, selected){
  const api = getCabinetModalFieldsApi();
  if(api && typeof api.populateFrontColorsTo === 'function') return api.populateFrontColorsTo(selectEl, typeVal, selected);
  if(!selectEl) return;
  selectEl.innerHTML = '';
}

function populateBodyColorsTo(selectEl, selected){
  const api = getCabinetModalFieldsApi();
  if(api && typeof api.populateBodyColorsTo === 'function') return api.populateBodyColorsTo(selectEl, selected);
  if(!selectEl) return;
  selectEl.innerHTML = '';
}

function populateOpeningOptionsTo(selectEl, typeVal, selected){
  const api = getCabinetModalFieldsApi();
  if(api && typeof api.populateOpeningOptionsTo === 'function') return api.populateOpeningOptionsTo(selectEl, typeVal, selected);
  if(!selectEl) return;
  selectEl.innerHTML = '';
}

function renderCabinetExtraDetailsInto(container, draft){
  container.innerHTML = '';
  try{ container.classList.add('cabinet-extra-details'); }catch(_){ }
  const t = draft.type;
  const rawSubType = String(draft && draft.subType || '');
  const validationApi = getCabinetModalValidationApi();
  const fieldsApi = getCabinetModalFieldsApi();
  const st = (validationApi && typeof validationApi.normalizeLegacySubType === 'function')
    ? validationApi.normalizeLegacySubType(rawSubType)
    : (rawSubType === 'szufladowa' ? 'szuflady' : rawSubType);
  const d = draft.details || {};

  function addSelect(labelText, key, options, onChangeExtra){
    if(fieldsApi && typeof fieldsApi.appendExtraSelectField === 'function') return fieldsApi.appendExtraSelectField(container, { draft, labelText, key, options, onChangeExtra, onRender: renderCabinetModal });
    return null;
  }

  function addNumber(labelText, key, fallback){
    if(fieldsApi && typeof fieldsApi.appendExtraNumberField === 'function') return fieldsApi.appendExtraNumberField(container, { draft, labelText, key, fallback });
    return null;
  }

  const typeApi = getCabinetModalTypeApi(t, st);
  if(typeApi && typeof typeApi.renderExtraDetails === 'function'){
    const handled = typeApi.renderExtraDetails({
      container,
      draft,
      subType: st,
      details: d,
      addSelect,
      addNumber,
      renderCabinetModal,
      cabinetModalState,
      uiState,
      projectData,
      ensureFrontCountRulesSafe,
      getFlapFrontCountSafe
    });
    if(handled) return;
  }
}

/* ===== Zestawy (presety) ===== */
function renderSetTiles(){
  const api = getCabinetModalSetWizardApi();
  if(api && typeof api.renderSetTiles === 'function') return api.renderSetTiles();
  return null;
}

function renderSetParamsUI(presetId){
  const api = getCabinetModalSetWizardApi();
  if(api && typeof api.renderSetParamsUI === 'function') return api.renderSetParamsUI(presetId);
  return null;
}

function wireSetParamsLiveUpdate(presetId){
  const api = getCabinetModalSetWizardApi();
  if(api && typeof api.wireSetParamsLiveUpdate === 'function') return api.wireSetParamsLiveUpdate(presetId);
  return null;
}

/* ===== Cabinet modal render ===== */
function renderCabinetModal(){
  const isSetEdit = !!cabinetModalState.setEditId;

  // Nagłówek: Anuluj zawsze widoczne, Zatwierdź tylko gdy pokazujemy formularz / zestaw.
  const saveTopBtn = document.getElementById('cabinetModalSave');
  const cancelTopBtn = document.getElementById('cabinetModalCancel');
  if(cancelTopBtn){
    cancelTopBtn.style.display = 'inline-flex';
    cancelTopBtn.disabled = false;
    cancelTopBtn.textContent = 'Anuluj';
  }
  if(saveTopBtn){
    saveTopBtn.style.display = 'none';
    saveTopBtn.disabled = true;
  }

  document.getElementById('cabinetModalIcon').textContent = isSetEdit ? '✏️' : (cabinetModalState.mode === 'edit' ? '✏️' : '➕');
  document.getElementById('cabinetModalTitle').textContent = isSetEdit ? 'Edytuj zestaw' : (cabinetModalState.mode === 'edit' ? 'Edytuj szafkę' : 'Dodaj');

  const choiceCard = document.getElementById('cabinetChoiceCard');
  choiceCard.style.display = isSetEdit ? 'none' : 'block';

  if(!isSetEdit){
    renderCabinetTypeChoices();
  } else {
    cabinetModalState.chosen = 'zestaw';
  }

  const formArea = document.getElementById('cabinetFormArea');
  const setArea = document.getElementById('setWizardArea');

  formArea.style.display = 'none';
  setArea.style.display = 'none';

  if(cabinetModalState.chosen === 'zestaw'){
    const setApi = getCabinetModalSetWizardApi();
    if(setApi && typeof setApi.renderSetWizardMode === 'function'){
      setApi.renderSetWizardMode({ isSetEdit, saveTopBtn });
      return;
    }
    return;
  }

  if(!cabinetModalState.chosen) return;

  formArea.style.display = 'block';
  try{ formArea.classList.add('cabinet-choice-sync'); }catch(_){ }

  if(saveTopBtn){
    saveTopBtn.style.display = 'inline-flex';
    saveTopBtn.disabled = false;
    // IMPORTANT: when leaving set mode, reset the CTA label so it doesn't stick as "Dodaj zestaw".
    saveTopBtn.textContent = (cabinetModalState.mode === 'edit') ? 'Zapisz zmiany' : 'Dodaj';
  }

  // pokazujemy Zatwierdź w nagłówku dopiero gdy jest formularz
  if(saveTopBtn){
    saveTopBtn.style.display = 'inline-flex';
    saveTopBtn.disabled = false;
    saveTopBtn.textContent = (cabinetModalState.mode === 'edit') ? 'Zapisz zmiany' : 'Dodaj';
  }

  const draft = cabinetModalState.draft;
  const room = uiState.roomType;


  function draftHeightIncludesLegs(){
    const det = draft && draft.details && typeof draft.details === 'object' ? draft.details : {};
    const raw = det.heightIncludesLegs;
    if(raw === false || raw === 0) return false;
    const txt = String(raw == null ? '' : raw).trim().toLowerCase();
    if(['0','false','nie','no','off'].includes(txt)) return false;
    return true;
  }

  function effectiveDraftLegHeight(){
    const det = draft && draft.details && typeof draft.details === 'object' ? draft.details : {};
    if(det.legHeightCm != null && String(det.legHeightCm).trim() !== '') return Number(det.legHeightCm) || 0;
    try{ return Number(projectData && projectData[room] && projectData[room].settings && projectData[room].settings.legHeight) || 0; }catch(_){ return 0; }
  }
  function syncLegHeightUi(){
    const wrap = document.getElementById('cmLegHeightWrap');
    const input = document.getElementById('cmLegHeight');
    const checkWrap = document.getElementById('cmHeightIncludesLegsWrap');
    const check = document.getElementById('cmHeightIncludesLegs');
    if(!wrap || !input) return;
    const show = String(draft && draft.type || '') === 'stojąca';
    if(checkWrap) checkWrap.style.display = show ? '' : 'none';
    wrap.style.display = show ? '' : 'none';
    if(show){
      const includes = draftHeightIncludesLegs();
      if(check) check.checked = includes;
      input.value = effectiveDraftLegHeight();
      input.disabled = !includes;
      input.closest && input.closest('div') && input.closest('div').classList.toggle('is-muted', !includes);
    }
  }

  function isProjectUnusual(){
    const det = draft && draft.details && typeof draft.details === 'object' ? draft.details : {};
    const raw = det.projectUnusual != null ? det.projectUnusual : det.unusualProject;
    if(raw === true || raw === 1) return true;
    const txt = String(raw == null ? '' : raw).trim().toLowerCase();
    return ['1','true','tak','yes','on'].includes(txt);
  }
  function syncProjectUnusualUi(){
    const wrap = document.getElementById('cmProjectUnusualWrap');
    const check = document.getElementById('cmProjectUnusual');
    if(wrap) wrap.style.display = cabinetModalState.chosen === 'zestaw' ? 'none' : '';
    if(check) check.checked = isProjectUnusual();
  }


  function refreshCabinetHardwareRequirementsPanel(){
    try{
      const host = document.getElementById('cmHardwareRequirements');
      const reqPanelApi = window.FC && window.FC.cabinetHardwareRequirementsPanel;
      if(!host || !(reqPanelApi && typeof reqPanelApi.renderPanel === 'function')) return;
      try{ syncDraftFromCabinetModalFormSafe(draft); }catch(_sync){ }
      try{ ensureFrontCountRulesSafe(draft); }catch(_rules){ }
      reqPanelApi.renderPanel(host, room, draft, {
        editable:true,
        onChange:function(){
          try{ applyAventosValidationUISafe(room, draft); }catch(_){ }
        }
      });
    }catch(_){ }
  }

  // Rodzaj z kafelka
  draft.type = cabinetModalState.chosen;

  const cmSubType = document.getElementById('cmSubType');
  populateSelect(cmSubType, getSubTypeOptionsForTypeSafe(draft.type), draft.subType);

  renderCabinetExtraDetailsInto(document.getElementById('cmExtraDetails'), draft);
  try{
    const laborApi = getCabinetModalLaborApi();
    if(laborApi && typeof laborApi.renderLaborSection === 'function') laborApi.renderLaborSection(document.getElementById('cmLaborAddons'), draft, renderCabinetModal);
  }catch(_){ }
  document.getElementById('cmWidth').value = draft.width;
  document.getElementById('cmHeight').value = draft.height;
  document.getElementById('cmDepth').value = draft.depth;
  syncLegHeightUi();
  syncProjectUnusualUi();

  document.getElementById('cmFrontMaterial').value = draft.frontMaterial || 'laminat';
  document.getElementById('cmBackMaterial').value = draft.backMaterial || 'HDF 3mm biała';

  populateFrontColorsTo(document.getElementById('cmFrontColor'), draft.frontMaterial || 'laminat', draft.frontColor || '');
  populateBodyColorsTo(document.getElementById('cmBodyColor'), draft.bodyColor || '');
  populateOpeningOptionsTo(document.getElementById('cmOpeningSystem'), draft.type, draft.openingSystem || 'uchwyt klienta');
  const cmPcvMode = document.getElementById('cmBodyPcvMode');
  if(cmPcvMode) cmPcvMode.value = (draft.bodyPcvMode === 'front' ? 'front' : 'body');
  syncCabinetMaterialVisibility(draft);

  // FRONT COUNT UI
  const fcSel = document.getElementById('cmFrontCount');
  const fcStatic = document.getElementById('cmFrontCountStatic');
  const fcHint = document.getElementById('cmFrontCountHint');
  const fcWrap = document.getElementById('cmFrontCountWrap');
  const shelvesWrap = document.getElementById('cmShelvesWrap');
  const shelvesInput = document.getElementById('cmShelves');

  const flapWrap = document.getElementById('cmFlapWrap');
  const flapVendorSel = document.getElementById('cmFlapVendor');
  const flapKindWrap = document.getElementById('cmFlapKindWrap');
  const flapKindSel = document.getElementById('cmFlapKind');
  const flapInfo = document.getElementById('cmFlapInfo');
  const flapFrontInfo = document.getElementById('cmFlapFrontInfo');
  const fcLabelEl = document.getElementById('cmFrontCountLabel');

  const typeApi = getCabinetModalTypeApi(draft.type);
  if(typeApi && typeof typeApi.configureFrontControls === 'function'){
    typeApi.configureFrontControls({
      draft,
      room,
      fcSel,
      fcStatic,
      fcHint,
      fcWrap,
      shelvesWrap,
      shelvesInput,
      flapWrap,
      flapVendorSel,
      flapKindWrap,
      flapKindSel,
      flapInfo,
      flapFrontInfo,
      fcLabelEl,
      renderCabinetModal,
      populateSelect,
      ensureFrontCountRulesSafe,
      cabinetAllowsFrontCountSafe,
      getFlapFrontCountSafe
    });
  }

  cmSubType.onchange = () => {
    applySubTypeRulesSafe(room, draft, cmSubType.value);
    ensureFrontCountRulesSafe(draft);
    const currentTypeApi = getCabinetModalTypeApi(draft.type);
    if(currentTypeApi && typeof currentTypeApi.afterSubTypeChange === 'function'){
      currentTypeApi.afterSubTypeChange({ draft, room, nextSubType: cmSubType.value, projectData, getFlapFrontCountSafe });
    }
    renderCabinetModal();
  };

  fcSel.onchange = () => {
    draft.frontCount = Number(fcSel.value || 2);
    ensureFrontCountRulesSafe(draft);
    refreshCabinetHardwareRequirementsPanel();
  };

  document.getElementById('cmWidth').onchange = e => {
    draft.width = parseFloat(e.target.value || 0);
    refreshCabinetHardwareRequirementsPanel();
  };

  // Live re-check dla uchylnych: po zmianie wysokości od razu przelicz LF i sprawdź zakresy
  const _liveAventosCheck = () => {
    try{
      const room = uiState.roomType;


  function draftHeightIncludesLegs(){
    const det = draft && draft.details && typeof draft.details === 'object' ? draft.details : {};
    const raw = det.heightIncludesLegs;
    if(raw === false || raw === 0) return false;
    const txt = String(raw == null ? '' : raw).trim().toLowerCase();
    if(['0','false','nie','no','off'].includes(txt)) return false;
    return true;
  }

  function effectiveDraftLegHeight(){
    const det = draft && draft.details && typeof draft.details === 'object' ? draft.details : {};
    if(det.legHeightCm != null && String(det.legHeightCm).trim() !== '') return Number(det.legHeightCm) || 0;
    try{ return Number(projectData && projectData[room] && projectData[room].settings && projectData[room].settings.legHeight) || 0; }catch(_){ return 0; }
  }
  function syncLegHeightUi(){
    const wrap = document.getElementById('cmLegHeightWrap');
    const input = document.getElementById('cmLegHeight');
    const checkWrap = document.getElementById('cmHeightIncludesLegsWrap');
    const check = document.getElementById('cmHeightIncludesLegs');
    if(!wrap || !input) return;
    const show = String(draft && draft.type || '') === 'stojąca';
    if(checkWrap) checkWrap.style.display = show ? '' : 'none';
    wrap.style.display = show ? '' : 'none';
    if(show){
      const includes = draftHeightIncludesLegs();
      if(check) check.checked = includes;
      input.value = effectiveDraftLegHeight();
      input.disabled = !includes;
      input.closest && input.closest('div') && input.closest('div').classList.toggle('is-muted', !includes);
    }
  }

      syncDraftFromCabinetModalFormSafe(draft);
      ensureFrontCountRulesSafe(draft);

      // Szuflady systemowe GTV/Rejs nie są już blokowane w formularzu.
      // Szafka zapisuje wymaganie techniczne, a WYCENA dobiera konkretny wpis z katalogu albo pokazuje brak ceny.
      applyAventosValidationUISafe(room, draft);
      refreshCabinetHardwareRequirementsPanel();
    }catch(_e){ /* nie psuj modala */ }
  };
  const _cmHeightEl = document.getElementById('cmHeight');
  if(_cmHeightEl){
    _cmHeightEl.oninput = _liveAventosCheck;
    _cmHeightEl.onchange = _liveAventosCheck;
  }

  const _cmWidthEl = document.getElementById('cmWidth');
  if(_cmWidthEl){
    _cmWidthEl.oninput = _liveAventosCheck;
    _cmWidthEl.onchange = _liveAventosCheck;
  }
  const _cmDepthEl = document.getElementById('cmDepth');
  if(_cmDepthEl){
    _cmDepthEl.oninput = _liveAventosCheck;
    _cmDepthEl.onchange = _liveAventosCheck;
  }
  const _cmHeightIncludesLegsEl = document.getElementById('cmHeightIncludesLegs');
  if(_cmHeightIncludesLegsEl){
    _cmHeightIncludesLegsEl.onchange = () => {
      _liveAventosCheck();
      syncLegHeightUi();
    };
  }
  const _cmLegHeightEl = document.getElementById('cmLegHeight');
  if(_cmLegHeightEl){
    _cmLegHeightEl.oninput = _liveAventosCheck;
    _cmLegHeightEl.onchange = _liveAventosCheck;
  }
  const _cmProjectUnusualEl = document.getElementById('cmProjectUnusual');
  if(_cmProjectUnusualEl){
    _cmProjectUnusualEl.onchange = _liveAventosCheck;
  }

  document.getElementById('cmFrontMaterial').onchange = e => {
    draft.frontMaterial = e.target.value;
    const first = materials.find(m => m.materialType === draft.frontMaterial);
    draft.frontColor = first ? first.name : '';
    renderCabinetModal();
  };
  document.getElementById('cmFrontColor').onchange = e => { draft.frontColor = e.target.value; };
  document.getElementById('cmBackMaterial').onchange = e => { draft.backMaterial = e.target.value; };
  document.getElementById('cmBodyColor').onchange = e => { draft.bodyColor = e.target.value; };
  document.getElementById('cmOpeningSystem').onchange = e => { draft.openingSystem = e.target.value; refreshCabinetHardwareRequirementsPanel(); };
  const _cmBodyPcvMode = document.getElementById('cmBodyPcvMode');
  if(_cmBodyPcvMode) _cmBodyPcvMode.onchange = e => { draft.bodyPcvMode = String(e.target.value || '') === 'front' ? 'front' : 'body'; };

  try{
    const launcherApi = window.FC && window.FC.cabinetChoiceLaunchers;
    if(launcherApi && typeof launcherApi.refreshCabinetChoices === 'function') launcherApi.refreshCabinetChoices(document.getElementById('cabinetModal'));
    else {
      if(launcherApi && typeof launcherApi.mountSafeFieldLaunchers === 'function') launcherApi.mountSafeFieldLaunchers();
      if(launcherApi && typeof launcherApi.mountDynamicSelectLaunchers === 'function'){
        launcherApi.mountDynamicSelectLaunchers(document.getElementById('cmExtraDetails'));
        launcherApi.mountDynamicSelectLaunchers(document.getElementById('setFrontBlock'));
      }
      if(launcherApi && typeof launcherApi.mountVisibleFallbackLaunchers === 'function'){
        launcherApi.mountVisibleFallbackLaunchers(document.getElementById('cabinetFormArea'));
      }
    }
  }catch(_){ }

  const _cabCancel = document.getElementById('cabinetModalCancel');
  if(_cabCancel) _cabCancel.onclick = closeCabinetModal;
  const finalizeApi = getCabinetModalFinalizeApi();
  if(finalizeApi && typeof finalizeApi.bindTopSaveButton === 'function'){
    finalizeApi.bindTopSaveButton({
      draft,
      renderCabinets,
      closeCabinetModal,
      showCabinetInfo
    });
  }

  refreshCabinetHardwareRequirementsPanel();

  // Walidacja klapy (AVENTOS) – blokuj zapis jeśli poza zakresem
  applyAventosValidationUISafe(room, draft);
}

/* ===== set wizard delegated to js/app/cabinet/cabinet-modal-set-wizard.js ===== */
function getSetParamsFromUI(presetId){
  const api = getCabinetModalSetWizardApi();
  if(api && typeof api.getSetParamsFromUI === 'function') return api.getSetParamsFromUI(presetId);
  return null;
}

function fillSetParamsUIFromSet(set){
  const api = getCabinetModalSetWizardApi();
  if(api && typeof api.fillSetParamsUIFromSet === 'function') return api.fillSetParamsUIFromSet(set);
  return null;
}

function getNextSetNumber(room){
  const api = getCabinetModalSetWizardApi();
  if(api && typeof api.getNextSetNumber === 'function') return api.getNextSetNumber(room);
  return 1;
}

function createOrUpdateSetFromWizard(){
  const api = getCabinetModalSetWizardApi();
  if(api && typeof api.createOrUpdateSetFromWizard === 'function') return api.createOrUpdateSetFromWizard();
  return null;
}

/* ===== Read-only: cabinet details summary ===== */

  ns.cabinetModal = {
    makeDefaultCabinetDraftForRoom,
    makeDefaultCabinetDraftForType,
    openCabinetModalForAdd,
    lockModalScroll,
    unlockModalScroll,
    openCabinetModalForEdit,
    openSetWizardForEdit,
    closeCabinetModal,
    renderCabinetTypeChoices,
    populateSelect,
    populateFrontColorsTo,
    populateBodyColorsTo,
    populateOpeningOptionsTo,
    renderCabinetExtraDetailsInto,
    renderSetTiles,
    renderSetParamsUI,
    wireSetParamsLiveUpdate,
    renderCabinetModal,
    getSetParamsFromUI,
    fillSetParamsUIFromSet,
    getNextSetNumber,
    createOrUpdateSetFromWizard
  };
})();
function showCabinetInfo(title, message){
  try{
    if(FC.infoBox && typeof FC.infoBox.open === 'function'){
      FC.infoBox.open({ title:String(title || 'Informacja'), message:String(message || '') });
      return;
    }
  }catch(_){ }
  try{ console.warn('[cabinetModal]', title, message); }catch(_){ }
}

async function askCabinetConfirm(cfg){
  try{
    if(FC.confirmBox && typeof FC.confirmBox.ask === 'function') return !!(await FC.confirmBox.ask(cfg || {}));
  }catch(_){ }
  return true;
}


