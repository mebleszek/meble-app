(function(){
  'use strict';
  window.FC = window.FC || {};
  const FC = window.FC;

  const SHEET_MATERIAL_TYPES = ['laminat','akryl','lakier','hdf','obrzeże','blat'];
  const QUOTE_RATE_CATEGORIES = ['Korpusy','Elementy szafki','Usługi przy szafce','Montaż','Montaż AGD','Pomiar','Transport','Projekt','Inne'];
  const WORKSHOP_SERVICE_CATEGORIES = ['Cięcie','Oklejanie','Montaż','Naprawa','Transport','Inne'];

  const PRICE_LIST_CONFIG = {
    materials: {
      key:'materials',
      storageKey:'sheetMaterials',
      title:'Materiały',
      subtitle:'Szukaj, filtruj i zarządzaj materiałami arkuszowymi do mebli.',
      addLabel:'Dodaj materiał',
      icon:'🧩',
      formKind:'material',
      mode:'furnitureProjects',
    },
    accessories: {
      key:'accessories',
      storageKey:'accessories',
      title:'Okucia i akcesoria',
      subtitle:'Szukaj, filtruj i zarządzaj katalogiem okuć, producentami, jednostkami i cenami do wyceny.',
      addLabel:'Dodaj okucie',
      icon:'🧷',
      formKind:'accessory',
      mode:'furnitureProjects',
    },
    quoteRates: {
      key:'quoteRates',
      storageKey:'quoteRates',
      title:'Cennik robocizny i usług',
      subtitle:'Szukaj, filtruj i zarządzaj robocizną, transportem, montażem AGD, usługami dodatkowymi i regułami do wyceny projektów meblowych.',
      addLabel:'Dodaj usługę / robociznę',
      icon:'💲',
      formKind:'service',
      mode:'furnitureProjects',
    },
    workshopServices: {
      key:'workshopServices',
      storageKey:'workshopServices',
      title:'Usługi stolarskie',
      subtitle:'Szukaj, filtruj i zarządzaj cennikiem drobnych usług stolarskich.',
      addLabel:'Dodaj usługę',
      icon:'🔧',
      formKind:'service',
      mode:'workshopServices',
    },
  };

  function normalizeText(value){ return String(value == null ? '' : value).trim(); }
  function normalizeLower(value){ return normalizeText(value).toLowerCase(); }
  function clone(value){
    try{ return (FC.utils && typeof FC.utils.clone === 'function') ? FC.utils.clone(value) : JSON.parse(JSON.stringify(value)); }
    catch(_){ return JSON.parse(JSON.stringify(value || null)); }
  }
  function getCatalogConfig(kind){
    const key = String(kind || 'materials');
    return clone(PRICE_LIST_CONFIG[key] || PRICE_LIST_CONFIG.materials);
  }
  function getCatalogKeys(){ return Object.keys(PRICE_LIST_CONFIG); }
  function getCatalogKeysForMode(mode){
    const current = String(mode || '').trim();
    return getCatalogKeys().filter((key)=> String((PRICE_LIST_CONFIG[key] && PRICE_LIST_CONFIG[key].mode) || '') === current);
  }
  function isAccessoryMaterialType(materialType){
    const raw = normalizeLower(materialType);
    return raw === 'akcesoria' || raw === 'accessories' || raw === 'akcesorium';
  }
  function isSheetMaterialType(materialType){
    const raw = normalizeLower(materialType);
    return SHEET_MATERIAL_TYPES.includes(raw);
  }
  function splitLegacyMaterials(list){
    const rows = Array.isArray(list) ? list : [];
    const out = { sheetMaterials:[], accessories:[] };
    rows.forEach((row)=>{
      if(!row || typeof row !== 'object') return;
      const materialType = normalizeLower(row.materialType);
      const normalized = Object.assign({}, row);
      if(isAccessoryMaterialType(materialType)){
        out.accessories.push({
          id: normalizeText(normalized.id),
          manufacturer: normalizeText(normalized.manufacturer),
          symbol: normalizeText(normalized.symbol),
          name: normalizeText(normalized.name),
          price: Number(normalized.price) || 0,
        });
        return;
      }
      if(!materialType || isSheetMaterialType(materialType)){
        out.sheetMaterials.push({
          id: normalizeText(normalized.id),
          materialType: materialType || 'laminat',
          manufacturer: normalizeText(normalized.manufacturer),
          symbol: normalizeText(normalized.symbol),
          name: normalizeText(normalized.name),
          price: Number(normalized.price) || 0,
          priceUnit: normalizeText(normalized.priceUnit || normalized.unitPriceMode || normalized.unit) || 'sheet',
          hasGrain: !!normalized.hasGrain,
          starterPrice: normalized.starterPrice === true,
          priceUserEditedAt: normalizeText(normalized.priceUserEditedAt || normalized.userEditedAt),
        });
      }
    });
    return out;
  }

  FC.catalogDomain = {
    SHEET_MATERIAL_TYPES,
    QUOTE_RATE_CATEGORIES,
    WORKSHOP_SERVICE_CATEGORIES,
    PRICE_LIST_CONFIG,
    getCatalogConfig,
    getCatalogKeys,
    getCatalogKeysForMode,
    isAccessoryMaterialType,
    isSheetMaterialType,
    splitLegacyMaterials,
  };
})();
