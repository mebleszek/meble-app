// js/app/investor/investor-ui.js
// UI zakładki/ekranu INWESTOR (lista + karta inwestora).
(() => {
  'use strict';
  window.FC = window.FC || {};
  const FC = window.FC;

  const PROJECT_STATUS_OPTIONS = [
    { value: 'nowy', label: 'Nowy' },
    { value: 'wstepna_wycena', label: 'Wstępna wycena' },
    { value: 'po_pomiarze', label: 'Po pomiarze' },
    { value: 'wycena', label: 'Wycena' },
    { value: 'umowa', label: 'Umowa' },
    { value: 'produkcja', label: 'Produkcja' },
    { value: 'montaz', label: 'Montaż' },
    { value: 'zakonczone', label: 'Zakończone' },
    { value: 'odrzucone', label: 'Odrzucone' },
  ];

  const state = {
    mode: 'list',
    query: '',
    selectedId: null,
    allowListAccess: true,
  };

  function $(id){ return document.getElementById(id); }
  function getRoot(){ return $('investorRoot') || $('investorView'); }
  function editor(){ return FC.investorEditorState || null; }
  function choice(){ return FC.investorChoice || null; }
  function roomUi(){ return FC.investorRooms || null; }
  function links(){ return FC.investorLinks || null; }
  function persistence(){ return FC.investorPersistence || null; }
  function guard(){ return FC.investorNavigationGuard || null; }
  function fieldRender(){ return FC.investorFieldRender || null; }
  function actions(){ return FC.investorActions || null; }

  function escapeHtml(s){
    const api = fieldRender();
    return api && typeof api.escapeHtml === 'function' ? api.escapeHtml(s) : String(s ?? '');
  }
  function escapeAttr(s){
    const api = fieldRender();
    return api && typeof api.escapeAttr === 'function' ? api.escapeAttr(s) : String(s ?? '');
  }

  function todayInput(){
    try{ return new Date().toISOString().slice(0, 10); }catch(_){ return ''; }
  }

  function normalizeDateInput(value){
    const text = String(value || '').trim();
    if(/^\d{4}-\d{2}-\d{2}$/.test(text)) return text;
    if(Number.isFinite(Number(value)) && Number(value) > 0){
      try{ return new Date(Number(value)).toISOString().slice(0, 10); }catch(_){ }
    }
    return todayInput();
  }

  function formatDateDisplay(value){
    const raw = normalizeDateInput(value);
    if(!raw) return '—';
    const m = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    return m ? `${m[3]}.${m[2]}.${m[1]}` : raw;
  }

  function persistUIInvestorId(id){
    try{
      if(window.FC && FC.uiState && typeof FC.uiState.set === 'function'){
        uiState = FC.uiState.set({ currentInvestorId: id || null });
        return;
      }
      if(typeof uiState !== 'undefined' && uiState){
        uiState.currentInvestorId = id || null;
        if(FC.storage && typeof FC.storage.setJSON === 'function' && typeof STORAGE_KEYS !== 'undefined'){
          FC.storage.setJSON(STORAGE_KEYS.ui, uiState);
        }
      }
    }catch(_){ }
  }

  function readUIInvestorId(){
    try{ return (FC.uiState && typeof FC.uiState.get === 'function') ? (FC.uiState.get().currentInvestorId || null) : null; }catch(_){ }
    try{ return (typeof uiState !== 'undefined' && uiState) ? (uiState.currentInvestorId || null) : null; }catch(_){ return null; }
  }

  function renderListOnly(targetEl){
    const el = targetEl;
    if(!el) return;
    if(!persistence()){
      el.innerHTML = '<div class="muted">Brak modułu bazy inwestorów.</div>';
      return;
    }
    const list = persistence().searchInvestors(state.query);
    el.innerHTML = buildList(list);
    bindList(targetEl);
  }

  function ensureInvestorContext(currentId){
    const ui = (typeof uiState !== 'undefined' && uiState) ? uiState : ((FC.uiState && typeof FC.uiState.get === 'function') ? FC.uiState.get() : null);
    if(ui && String(ui.activeTab || '') === 'inwestor' && currentId){
      state.selectedId = currentId;
      state.mode = 'detail';
      state.allowListAccess = false;
    }
  }

  function render(){
    const root = getRoot();
    if(!root) return;

    if(!persistence()){
      root.innerHTML = '<div class="card"><h3>Inwestor</h3><div class="muted">Brak modułu bazy inwestorów.</div></div>';
      return;
    }

    const currentId = persistence().getCurrentInvestorId() || readUIInvestorId();
    if(state.selectedId == null && currentId) state.selectedId = currentId;
    ensureInvestorContext(currentId);
    if(!state.allowListAccess && state.selectedId) state.mode = 'detail';
    if(state.mode === 'detail' && !state.selectedId && currentId) state.selectedId = currentId;
    if(state.mode === 'detail' && !state.selectedId) state.mode = 'list';

    if(state.mode === 'detail'){
      const inv = persistence().getInvestorById(state.selectedId || currentId);
      if(!inv){ state.mode = 'list'; return render(); }
      persistUIInvestorId(inv.id);
      root.innerHTML = buildDetail(inv);
      bindDetail(inv);
      return;
    }

    try{ guard() && guard().apply(false); }catch(_){ }
    const list = persistence().searchInvestors(state.query);
    root.innerHTML = buildList(list);
    bindList();
  }

  function buildList(list){
    const items = (list || []).map((inv) => {
      const title = (inv.kind === 'company' ? (inv.companyName || '(Firma bez nazwy)') : (inv.name || '(Bez nazwy)'));
      const sub = [inv.phone, inv.city, formatDateDisplay(inv.addedDate || inv.createdAt)].filter(Boolean).join(' • ');
      return `
        <div class="item" data-inv-id="${inv.id}" style="display:flex;justify-content:space-between;align-items:center;gap:10px;padding:12px;border:1px solid rgba(0,0,0,.08);border-radius:12px;margin:8px 0;">
          <div style="min-width:0">
            <div style="font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(title)}</div>
            <div class="muted xs" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(sub || '')}</div>
          </div>
          <button class="btn" data-action="open-investor" data-inv-id="${inv.id}">Otwórz</button>
        </div>
      `;
    }).join('');

    return `
      <div class="card">
        <h3>Lista inwestorów</h3>
        <div style="display:flex;gap:10px;align-items:center;margin-top:10px">
          <input id="invSearch" placeholder="Szukaj po nazwie/telefonie..." value="${escapeAttr(state.query)}" />
          <button class="btn-primary" data-action="create-investor">+ Dodaj</button>
        </div>
        <div id="invItems" style="margin-top:12px">${items || '<div class="muted">Brak inwestorów.</div>'}</div>
      </div>
    `;
  }

  function buildDetail(inv){
    const editorApi = editor();
    const fields = fieldRender();
    const actionsApi = actions();
    const draft = editorApi ? editorApi.getDraft(inv) : {};
    const currentState = editorApi ? editorApi.ensureInvestor(inv) : { isEditing:false, dirty:false };
    const isEditing = !!currentState.isEditing;
    const dirty = !!currentState.dirty;
    const isCompany = String(draft.kind || inv.kind || 'person') === 'company';
    const linksApi = links();
    const phoneLabel = (!isEditing && linksApi && typeof linksApi.buildLabelWithAction === 'function')
      ? linksApi.buildLabelWithAction('Telefon', 'phone', draft.phone || inv.phone || '')
      : fields.buildStaticLabel('Telefon');
    const emailLabel = (!isEditing && linksApi && typeof linksApi.buildLabelWithAction === 'function')
      ? linksApi.buildLabelWithAction('Email', 'email', draft.email || inv.email || '')
      : fields.buildStaticLabel('Email');
    const bottomButtons = actionsApi ? actionsApi.buildActionBarHtml({ isEditing, dirty }) : '';

    const typeOptions = [
      { value:'person', label:'Osoba prywatna' },
      { value:'company', label:'Firma' },
    ];
    const projectCards = roomUi() && typeof roomUi().buildProjectCards === 'function'
      ? roomUi().buildProjectCards(inv, isEditing, PROJECT_STATUS_OPTIONS)
      : '<div class="muted">Brak dodanych pomieszczeń.</div>';

    const rows = [];
    rows.push(fields.buildPairRow(
      fields.buildInputField('invName', fields.buildStaticLabel(isCompany ? 'Nazwa firmy' : 'Imię i nazwisko'), isCompany ? draft.companyName : draft.name, { readonly:!isEditing, compact:true }),
      fields.buildInputField('invPhone', phoneLabel, draft.phone, { readonly:!isEditing, compact:true })
    ));
    rows.push(fields.buildPairRow(
      fields.buildInputField('invCity', fields.buildStaticLabel('Miejscowość'), draft.city, { readonly:!isEditing, compact:true }),
      fields.buildInputField('invEmail', emailLabel, draft.email, { readonly:!isEditing, compact:true })
    ));
    rows.push(fields.buildPairRow(
      fields.buildInputField('invAddress', fields.buildStaticLabel('Adres'), draft.address, { readonly:!isEditing, full:true, compact:true }),
      '',
      { full:true }
    ));
    if(isCompany){
      rows.push(fields.buildPairRow(
        fields.buildSpacerField(),
        fields.buildInputField('invOwnerName', fields.buildStaticLabel('Właściciel — imię i nazwisko'), draft.ownerName, { readonly:!isEditing, compact:true })
      ));
      rows.push(fields.buildPairRow(
        fields.buildSpacerField(),
        fields.buildInputField('invNip', fields.buildStaticLabel('NIP'), draft.nip, { readonly:!isEditing, compact:true })
      ));
    }
    rows.push(fields.buildPairRow(
      fields.buildInputField('invSource', fields.buildStaticLabel('Źródło'), draft.source, { readonly:!isEditing, full:true, compact:true }),
      '',
      { full:true }
    ));
    rows.push(fields.buildPairRow(
      fields.buildInputField('invNotes', fields.buildStaticLabel('Dodatkowe informacje'), draft.notes, { readonly:!isEditing, full:true, textarea:true, rows:3 }),
      '',
      { full:true }
    ));

    return `
      <div class="card investor-card-sync" data-investor-editing="${isEditing ? '1' : '0'}">
        <div style="display:flex;justify-content:space-between;align-items:center;gap:10px">
          <h3 style="margin:0">Inwestor</h3>
        </div>

        <div class="investor-choice-grid">
          ${fields.buildChoiceField('invKind', 'Typ', typeOptions, draft.kind || 'person', 'investor-choice-field--kind', { readonlyPreview:!isEditing })}
          ${fields.buildInputField('invAddedDate', fields.buildStaticLabel('Data dodania'), normalizeDateInput(draft.addedDate || inv.addedDate || inv.createdAt), { readonly:!isEditing, compact:true, inputType:'date', displayValue:formatDateDisplay(draft.addedDate || inv.addedDate || inv.createdAt) })}
        </div>

        <div class="investor-details-rows">
          ${rows.join('')}
        </div>

        <div class="investor-bottom-actions" id="investorActionBar">${bottomButtons}</div>

        <div class="hr"></div>
        <div class="investor-rooms-head">
          <h4 style="margin:0">Pomieszczenia inwestora</h4>
          <button class="btn-primary investor-add-room-btn${isEditing ? ' is-disabled' : ''}" type="button" data-investor-action="add-room" ${isEditing ? 'disabled' : ''}>Dodaj pomieszczenie</button>
        </div>
        <div class="muted xs" style="margin-bottom:10px">Wyświetlam tylko pomieszczenia dodane do tego inwestora.</div>
        <div class="investor-room-quick-list">${projectCards}</div>
        ${isEditing ? '<div class="investor-disabled-note">W trybie edycji pomieszczenia, statusy projektów i górna nawigacja są zablokowane.</div>' : ''}
      </div>
    `;
  }

  function bindList(targetEl){
    const root = targetEl || getRoot();
    if(!root) return;
    const input = root.querySelector('#invSearch');
    if(input){
      input.addEventListener('input', ()=>{ state.query = input.value || ''; renderListOnly(targetEl || getRoot()); });
    }
  }

  function bindDetail(inv){
    const root = getRoot();
    const editorApi = editor();
    const choiceApi = choice();
    const persistenceApi = persistence();
    const actionsApi = actions();
    if(!(root && editorApi && persistenceApi)) return;

    persistUIInvestorId(inv.id);
    try{ guard() && guard().apply(!!editorApi.state.isEditing); }catch(_){ }

    const topActions = document.getElementById('investorActionBar');
    const kindSelect = document.getElementById('invKind');
    const fieldIds = ['invName','invPhone','invCity','invEmail','invAddress','invOwnerName','invSource','invNip','invNotes','invAddedDate'];
    const fields = fieldIds.reduce((acc, id)=> { acc[id] = document.getElementById(id); return acc; }, {});

    function currentInvestor(){ return (persistenceApi && persistenceApi.getInvestorById(inv.id)) || inv; }

    function refreshActionBar(){
      const currentState = editorApi ? editorApi.ensureInvestor(currentInvestor()) : { isEditing:false, dirty:false };
      if(!topActions) return;
      topActions.innerHTML = actionsApi ? actionsApi.buildActionBarHtml(currentState) : '';
      bindTopActions();
      try{ guard() && guard().apply(!!currentState.isEditing); }catch(_){ }
      try{
        if(roomUi() && typeof roomUi().mountProjectStatusChoices === 'function'){
          roomUi().mountProjectStatusChoices(currentInvestor(), PROJECT_STATUS_OPTIONS, {
            disabled: !!currentState.isEditing,
            onChange: (roomId, value)=> {
              if(currentState.isEditing) return;
              persistenceApi.setInvestorProjectStatus(currentInvestor().id, roomId, value);
              try{ if(FC.views && typeof FC.views.refreshSessionButtons === 'function') FC.views.refreshSessionButtons(); }catch(_){ }
              render();
            }
          });
        }
      }catch(_){ }
    }

    function patchFieldFromDom(id, key){
      if(!(editorApi && editorApi.state.isEditing)) return;
      const node = fields[id];
      if(!node) return;
      editorApi.setField(key, node.value || '');
      refreshActionBar();
    }

    function bindTopActions(){
      if(!(topActions && actionsApi)) return;
      actionsApi.bindTopActions(topActions, {
        getCurrentInvestor: currentInvestor,
        onRender: render,
        onDeleted: ()=> {
          state.selectedId = null;
          state.mode = 'list';
          persistUIInvestorId(null);
          try{ guard() && guard().apply(false); }catch(_){ }
          render();
        }
      });
    }

    bindTopActions();

    if(choiceApi && typeof choiceApi.mountChoice === 'function' && kindSelect){
      choiceApi.mountChoice({
        mount: document.getElementById('invKindLaunch'),
        selectEl: kindSelect,
        title:'Wybierz typ',
        buttonClass:'investor-choice-launch',
        disabled: !(editorApi && editorApi.state.isEditing),
        onChange: (value)=>{
          if(!(editorApi && editorApi.state.isEditing)) return;
          editorApi.setField('kind', value);
          render();
        }
      });
    }

    Object.entries({
      invName: () => editorApi.setField((kindSelect && kindSelect.value) === 'company' ? 'companyName' : 'name', fields.invName && fields.invName.value),
      invPhone: () => patchFieldFromDom('invPhone', 'phone'),
      invCity: () => patchFieldFromDom('invCity', 'city'),
      invEmail: () => patchFieldFromDom('invEmail', 'email'),
      invAddress: () => patchFieldFromDom('invAddress', 'address'),
      invOwnerName: () => patchFieldFromDom('invOwnerName', 'ownerName'),
      invSource: () => patchFieldFromDom('invSource', 'source'),
      invNip: () => patchFieldFromDom('invNip', 'nip'),
      invNotes: () => patchFieldFromDom('invNotes', 'notes'),
      invAddedDate: () => patchFieldFromDom('invAddedDate', 'addedDate'),
    }).forEach(([id, handler])=>{
      const node = fields[id];
      if(!node) return;
      node.addEventListener('input', ()=>{ if(!(editorApi && editorApi.state.isEditing)) return; handler(); refreshActionBar(); });
      node.addEventListener('change', ()=>{ if(!(editorApi && editorApi.state.isEditing)) return; handler(); refreshActionBar(); });
    });

    root.querySelectorAll('[data-action="back-investors"]').forEach((btn)=> {
      btn.addEventListener('click', ()=>{
        if(editorApi && editorApi.state.isEditing) return;
        state.mode = 'list';
        try{ guard() && guard().apply(false); }catch(_){ }
        render();
      });
    });

    root.querySelectorAll('[data-investor-action="add-room"]').forEach((btn)=> {
      btn.addEventListener('click', async ()=>{
        if(editorApi && editorApi.state.isEditing) return;
        try{
          if(FC.roomRegistry && typeof FC.roomRegistry.openAddRoomModal === 'function'){
            const room = await FC.roomRegistry.openAddRoomModal();
            if(room){
              try{ if(FC.roomRegistry.renderRoomsView) FC.roomRegistry.renderRoomsView(); }catch(_){ }
              render();
              try{ if(FC.views && typeof FC.views.refreshSessionButtons === 'function') FC.views.refreshSessionButtons(); }catch(_){ }
            }
          }
        }catch(_){ }
      });
    });

    refreshActionBar();
  }

  FC.investorUI = {
    render,
    renderListOnly,
    state,
    applyInvestorUiLocks: (inv)=> { try{ guard() && guard().apply(!!(editor() && editor().state.isEditing && inv && editor().state.investorId === inv.id)); }catch(_){ } },
  };
})();
