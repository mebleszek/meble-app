// js/app/material/price-modal-item-form.js
// Stan formularza i wewnętrzny modal dodawania/edycji pozycji katalogu.
(function(){
  'use strict';
  window.FC = window.FC || {};
  const FC = window.FC;
  const ctx = FC.priceModalContext || {};

  function filterMaterialWrapper(){ return ctx.byId('formMaterialTypeLaunch') && ctx.byId('formMaterialTypeLaunch').parentElement; }
  function filterManufacturerWrapper(){ return ctx.byId('formManufacturerLaunch') && ctx.byId('formManufacturerLaunch').parentElement; }
  function formCategoryWrapper(){ return ctx.byId('formCategoryLaunch') && ctx.byId('formCategoryLaunch').parentElement; }
  function formServiceNameWrapper(){ return ctx.byId('formServiceName') && ctx.byId('formServiceName').parentElement; }
  function formHasGrainRow(){ return ctx.byId('formHasGrain') && ctx.byId('formHasGrain').parentElement; }
  function laborFields(){ return ctx.byId('laborFormFields'); }


  const LABOR_CHOICE_FIELDS = [
    { id:'laborAutoRole', title:'Wybierz automat', placeholder:'Automat' },
    { id:'laborRateType', title:'Wybierz stawkę', placeholder:'Stawka' },
    { id:'laborTimeBlockHours', title:'Wybierz czas bazowy', placeholder:'Czas bazowy' },
    { id:'laborQuantityMode', title:'Wybierz tryb ilości', placeholder:'Tryb ilości' },
    { id:'laborStartHours', title:'Wybierz czas startowy', placeholder:'Start h' },
    { id:'laborStepHours', title:'Wybierz czas kolejnego kroku', placeholder:'Dodaj h' },
    { id:'laborVolumeTimeMode', title:'Wybierz gabarytoczas', placeholder:'Gabarytoczas' },
  ];


  const FIELD_HELP = {
    formMaterialType:{ title:'Typ materiału', message:'Określa rodzaj materiału w katalogu, np. laminat, blat albo HDF. Ten wybór wpływa na dalsze filtrowanie producentów i porządek w katalogu.' },
    formManufacturer:{ title:'Producent', message:'Producent lub marka pozycji katalogowej. Ułatwia filtrowanie oraz późniejsze wybieranie materiałów i akcesoriów w programie.' },
    formSymbol:{ title:'Symbol', message:'Pole na oznaczenie handlowe, kod albo symbol katalogowy. Warto je uzupełniać, jeśli później chcesz łatwo znaleźć konkretną pozycję.' },
    formName:{ title:'Nazwa', message:'Pełna nazwa pozycji widoczna w katalogu i przy wyborze w aplikacji.' },
    formHasGrain:{ title:'Ma słoje', message:'Włącz, jeśli materiał ma kierunek słojów. Dzięki temu ROZRYS może pilnować właściwego ułożenia elementów.' },
    formPrice:{ title:'Cena (PLN)', message:'Cena jednostkowa pozycji katalogowej. Dla materiałów i akcesoriów to zwykła cena pozycji, dla czynności może to być stała kwota.' },
    formCategory:{ title:'Kategoria', message:'Grupa porządkująca czynności w katalogu. Pomaga utrzymać porządek na liście i szybciej znaleźć właściwą pozycję.' },
    formServiceName:{ title:'Nazwa', message:'Nazwa czynności, stawki lub usługi. Powinna jasno mówić, czego dotyczy pozycja.' },
    formServicePrice:{ title:'Kwota stała / cena prosta', message:'Stała cena pozycji. Użyj jej, gdy czynność ma po prostu konkretną kwotę i nie ma być liczona z czasu albo innych parametrów.' },
    laborAutoRole:{ title:'Automat', message:'Określa, czy pozycja ma specjalną rolę w automatycznym liczeniu. Na przykład może być stawką godzinową albo regułą skręcania korpusu.' },
    laborRateType:{ title:'Stawka', message:'Wybierasz, z której stawki godzinowej korzysta dana reguła, np. warsztatowej albo montażowej.' },
    laborTimeBlockHours:{ title:'Czas bazowy', message:'Podstawowy czas doliczany dla jednej czynności albo jednego zastosowania reguły. Jeśli pozycja ma być czysto kwotowa, ustaw Brak.' },
    laborDefaultMultiplier:{ title:'Mnożnik domyślny', message:'Domyślny mnożnik trudności. Wartość 1 oznacza brak zmiany, 1.25 podnosi wynik o 25%.' },
    laborQuantityMode:{ title:'Tryb ilości', message:'Sposób liczenia przy większej liczbie sztuk. Możesz nie liczyć ilości wcale, liczyć liniowo, pakietami albo metodą start + krok.' },
    laborTierText:{ title:'Progi ilościowe', message:'Tu wpisujesz pakiety ilościowe dla trybu progowego. Przykład: 1-2=0.25;3-5=0.5;6-10=1 oznacza, ile godzin doliczyć dla danych zakresów ilości.' },
    laborStartHours:{ title:'Start h', message:'Początkowy czas przy trybie start + krok. To jednorazowa baza doliczana od startowej liczby sztuk.' },
    laborStartQty:{ title:'Start szt.', message:'Od ilu sztuk zaczyna działać wartość z pola Start h.' },
    laborStepEveryQty:{ title:'Co ile szt.', message:'Co ile kolejnych sztuk program ma doliczać następny krok czasu.' },
    laborStepHours:{ title:'Dodaj h', message:'Ile godzin doliczać za każdy kolejny krok ilości w trybie start + krok.' },
    laborVolumePricePerM3:{ title:'Gabaryt zł/m³', message:'Stała dopłata gabarytowa liczona od objętości szafki. To niezależna dopłata kwotowa za większy gabaryt.' },
    laborVolumeTimeMode:{ title:'Gabarytoczas', message:'Dodatkowe liczenie czasu zależne od objętości. Możesz je wyłączyć, liczyć stałe h/m³ albo ustawić progi objętości.' },
    laborVolumeTimePerM3:{ title:'Gabarytoczas h/m³', message:'Ile godzin doliczać za 1 m³, jeśli gabarytoczas działa w trybie h/m³.' },
    laborVolumeTimeTierText:{ title:'Progi gabarytoczasu', message:'Zakresy objętości i przypisany do nich czas. Przykład: 0.31-0.60=0.25;0.61-1=0.5.' },
    laborHeightMinMm:{ title:'Wysokość od (mm)', message:'Dolna granica wysokości, dla której reguła ma działać. Przydaje się np. do automatycznego skręcania korpusów wg wysokości.' },
    laborHeightMaxMm:{ title:'Wysokość do (mm)', message:'Górna granica wysokości, dla której reguła ma działać.' },
    laborActive:{ title:'Aktywna', message:'Jeśli zaznaczone, pozycja bierze udział w pracy programu i może być używana przy wycenie.' },
    laborInternalOnly:{ title:'Szczegóły tylko wewnętrzne', message:'Pozycja i jej szczegóły są przeznaczone do wewnętrznego liczenia. Ma pomagać Tobie, a nie być pokazywana klientowi jako jawny składnik.' },
  };

  function helpOpener(title, message){
    try{
      if(FC.infoBox && typeof FC.infoBox.open === 'function'){
        FC.infoBox.open({ title:String(title || 'Informacja'), message:String(message || '') });
        return;
      }
      if(FC.panelBox && typeof FC.panelBox.open === 'function'){
        FC.panelBox.open({ title:String(title || 'Informacja'), message:String(message || ''), width:'560px', boxClass:'panel-box--rozrys' });
      }
    }catch(_){ }
  }

  function buildLabelHelp(labelText, helpCfg){
    const row = document.createElement('div');
    row.className = 'label-help';
    const text = document.createElement('span');
    text.className = 'label-help__text';
    text.textContent = String(labelText || '');
    row.appendChild(text);
    if(helpCfg && helpCfg.message){
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'info-trigger';
      btn.setAttribute('aria-label', 'Pokaż informację: ' + String(helpCfg.title || labelText || ''));
      btn.addEventListener('click', ()=> helpOpener(helpCfg.title || labelText, helpCfg.message));
      row.appendChild(btn);
    }
    return row;
  }

  function decorateFieldHelp(fieldId){
    const control = ctx.byId(fieldId);
    const helpCfg = FIELD_HELP[fieldId];
    if(!(control && helpCfg)) return;
    let wrapper = control.parentElement;
    let label = null;
    if(fieldId === 'formHasGrain'){
      wrapper = control.parentElement;
      label = wrapper ? wrapper.querySelector('label') : null;
    }else if(wrapper){
      label = wrapper.querySelector(':scope > label');
    }
    if(!(wrapper && label) || label.dataset.helpDecorated === '1') return;
    const labelText = String(label.textContent || '').trim() || String(helpCfg.title || '');
    const helpNode = buildLabelHelp(labelText, helpCfg);
    label.replaceWith(helpNode);
    helpNode.dataset.helpDecorated = '1';
  }

  function decorateFieldHelpLabels(){
    Object.keys(FIELD_HELP).forEach(decorateFieldHelp);
  }

  function ensureLaborChoiceMount(selectEl){
    if(!(selectEl && selectEl.parentNode)) return null;
    const mountId = String(selectEl.id || '') + 'Launch';
    let mount = ctx.byId(mountId);
    if(!mount){
      mount = document.createElement('div');
      mount.id = mountId;
      mount.className = 'price-labor-choice-slot';
      selectEl.insertAdjacentElement('afterend', mount);
    }
    try{ selectEl.hidden = true; selectEl.setAttribute('aria-hidden', 'true'); }catch(_){ }
    return mount;
  }


  function hideLaborUsageField(){
    const el = ctx.byId('laborUsage');
    if(!el) return;
    try{ el.value = 'universal'; }catch(_){ }
    const wrap = el.closest ? el.closest('div') : el.parentElement;
    if(wrap) wrap.style.display = 'none';
  }

  function mountLaborChoiceLaunchers(){
    LABOR_CHOICE_FIELDS.forEach((field)=>{
      const selectEl = ctx.byId(field.id);
      const mount = ensureLaborChoiceMount(selectEl);
      if(!(selectEl && mount)) return;
      ctx.mountChoice({
        selectEl,
        mountId:mount.id,
        title:field.title,
        buttonClass:'investor-choice-launch price-labor-choice-launch',
        placeholder:field.placeholder,
        onChange:()=> updateItemActionState(),
      });
    });
  }

  function defaultMaterialDraft(){
    const type = ctx.firstNonEmptyValue(ctx.buildMaterialTypeOptions('laminat')) || 'laminat';
    const manufacturer = ctx.firstNonEmptyValue(ctx.buildManufacturerOptions('materials', type, '', { includeAll:false }));
    return { materialType:type, manufacturer, symbol:'', name:'', price:'', hasGrain:false };
  }
  function defaultAccessoryDraft(){
    const manufacturer = ctx.firstNonEmptyValue(ctx.buildManufacturerOptions('accessories', '', '', { includeAll:false }));
    return { manufacturer, symbol:'', name:'', price:'' };
  }
  function defaultServiceDraft(kind){
    const isQuoteRates = kind === 'quoteRates';
    return {
      category:ctx.firstNonEmptyValue(ctx.buildCategoryOptions(kind, isQuoteRates ? 'Korpusy' : 'Cięcie', { includeAll:false })) || (isQuoteRates ? 'Korpusy' : 'Cięcie'),
      name:'',
      price:'',
      usage:isQuoteRates ? 'universal' : '',
      autoRole:'none',
      rateType:'workshop',
      timeBlockHours:0,
      defaultMultiplier:1,
      quantityMode:'none',
      quantityTiers:[],
      startHours:0,
      startQty:1,
      stepEveryQty:1,
      stepHours:0,
      volumePricePerM3:0,
      volumeTimeMode:'none',
      volumeTimePerM3:0,
      volumeTimeTiers:[],
      heightMinMm:0,
      heightMaxMm:0,
      active:true,
      internalOnly:true,
    };
  }

  function currentEditedItem(){
    const editingId = ctx.appUiState() && ctx.appUiState().editingId;
    if(!editingId) return null;
    return ctx.currentList().find((item)=> item && item.id === editingId) || null;
  }
  function normalizePriceValue(value){ const raw = String(value == null ? '' : value).trim(); if(!raw) return ''; const parsed = Number(raw.replace(',', '.')); return Number.isFinite(parsed) ? parsed : raw; }
  function readNumber(id){ return normalizePriceValue(ctx.byId(id) && ctx.byId(id).value); }
  function readString(id){ return String((ctx.byId(id) && ctx.byId(id).value) || '').trim(); }
  function readBool(id){ return !!(ctx.byId(id) && ctx.byId(id).checked); }
  function setValue(id, value){ const el = ctx.byId(id); if(el) el.value = value == null ? '' : String(value); }
  function setChecked(id, value){ const el = ctx.byId(id); if(el) el.checked = !!value; }

  function getCurrentMaterialDraft(){ return { materialType:String((ctx.byId('formMaterialType') && ctx.byId('formMaterialType').value) || ''), manufacturer:String((ctx.byId('formManufacturer') && ctx.byId('formManufacturer').value) || '').trim(), symbol:String((ctx.byId('formSymbol') && ctx.byId('formSymbol').value) || '').trim(), name:String((ctx.byId('formName') && ctx.byId('formName').value) || '').trim(), price:normalizePriceValue(ctx.byId('formPrice') && ctx.byId('formPrice').value), hasGrain:!!(ctx.byId('formHasGrain') && ctx.byId('formHasGrain').checked) }; }
  function getCurrentAccessoryDraft(){ return { manufacturer:String((ctx.byId('formManufacturer') && ctx.byId('formManufacturer').value) || '').trim(), symbol:String((ctx.byId('formSymbol') && ctx.byId('formSymbol').value) || '').trim(), name:String((ctx.byId('formName') && ctx.byId('formName').value) || '').trim(), price:normalizePriceValue(ctx.byId('formPrice') && ctx.byId('formPrice').value) }; }
  function getCurrentLaborDraft(base){
    if(ctx.currentListKind() !== 'quoteRates') return {};
    const labor = FC.laborCatalog || {};
    const tierText = readString('laborTierText');
    const volumeTierText = readString('laborVolumeTimeTierText');
    return {
      usage:'universal',
      autoRole:readString('laborAutoRole') || 'none',
      rateType:readString('laborRateType') || 'workshop',
      rateKey:readString('laborAutoRole') === 'hourlyRate' ? (readString('laborRateType') || 'workshop') : '',
      timeBlockHours:Number(readNumber('laborTimeBlockHours')) || 0,
      defaultMultiplier:Number(readNumber('laborDefaultMultiplier')) || 1,
      quantityMode:readString('laborQuantityMode') || 'none',
      quantityTiers:labor.parseTierText ? labor.parseTierText(tierText) : [],
      startHours:Number(readNumber('laborStartHours')) || 0,
      startQty:Number(readNumber('laborStartQty')) || 1,
      stepEveryQty:Number(readNumber('laborStepEveryQty')) || 1,
      stepHours:Number(readNumber('laborStepHours')) || 0,
      volumePricePerM3:Number(readNumber('laborVolumePricePerM3')) || 0,
      volumeTimeMode:readString('laborVolumeTimeMode') || 'none',
      volumeTimePerM3:Number(readNumber('laborVolumeTimePerM3')) || 0,
      volumeTimeTiers:labor.parseVolumeTierText ? labor.parseVolumeTierText(volumeTierText) : [],
      heightMinMm:Number(readNumber('laborHeightMinMm')) || 0,
      heightMaxMm:Number(readNumber('laborHeightMaxMm')) || 0,
      active:readBool('laborActive'),
      internalOnly:readBool('laborInternalOnly'),
    };
  }
  function getCurrentServiceDraft(){
    const base = { category:String((ctx.byId('formCategory') && ctx.byId('formCategory').value) || '').trim(), name:String((ctx.byId('formServiceName') && ctx.byId('formServiceName').value) || '').trim(), price:normalizePriceValue(ctx.byId('formServicePrice') && ctx.byId('formServicePrice').value) };
    return Object.assign(base, getCurrentLaborDraft(base));
  }
  function currentItemSignature(){ const kind = ctx.currentConfig().formKind; const data = kind === 'material' ? getCurrentMaterialDraft() : (kind === 'accessory' ? getCurrentAccessoryDraft() : getCurrentServiceDraft()); return JSON.stringify(data); }
  function isItemDirty(){ return ctx.runtimeState.itemModalOpen && currentItemSignature() !== String(ctx.runtimeState.itemInitialSignature || ''); }

  function updateItemActionState(){
    const dirty = isItemDirty();
    const isEdit = !!(ctx.appUiState() && ctx.appUiState().editingId);
    const deleteBtn = ctx.byId('deletePriceItemBtn');
    const exitBtn = ctx.byId('priceItemExitBtn');
    const cancelBtn = ctx.byId('priceItemCancelBtn');
    const saveBtn = ctx.byId('priceItemSaveBtn');
    const footer = ctx.byId('priceItemFooter');
    if(footer) footer.style.display = ctx.runtimeState.itemModalOpen ? 'flex' : 'none';
    if(deleteBtn) deleteBtn.style.display = isEdit ? '' : 'none';
    if(exitBtn) exitBtn.style.display = dirty ? 'none' : '';
    if(cancelBtn) cancelBtn.style.display = dirty ? '' : 'none';
    if(saveBtn){ saveBtn.style.display = dirty ? '' : 'none'; saveBtn.textContent = isEdit ? 'Zapisz' : ctx.currentConfig().addLabel.replace(/^Dodaj\s+/i, 'Dodaj '); }
  }

  function wireItemDirtyEvents(){
    [
      'formSymbol','formName','formPrice','formServiceName','formServicePrice','formHasGrain','formMaterialType','formManufacturer','formCategory',
      'laborAutoRole','laborRateType','laborTimeBlockHours','laborDefaultMultiplier','laborQuantityMode','laborTierText',
      'laborStartHours','laborStartQty','laborStepEveryQty','laborStepHours','laborVolumePricePerM3','laborVolumeTimeMode','laborVolumeTimePerM3',
      'laborVolumeTimeTierText','laborHeightMinMm','laborHeightMaxMm','laborActive','laborInternalOnly'
    ].forEach((id)=>{
      const el = ctx.byId(id);
      if(!el) return;
      el.oninput = updateItemActionState;
      el.onchange = updateItemActionState;
    });
  }

  function applyMaterialFormState(item){
    const materialType = String(item && item.materialType || 'laminat');
    ctx.setSelectOptions(ctx.byId('formMaterialType'), ctx.buildMaterialTypeOptions(materialType), materialType, materialType);
    ctx.setSelectOptions(ctx.byId('formManufacturer'), ctx.buildManufacturerOptions('materials', materialType, item && item.manufacturer), String(item && item.manufacturer || ''), String(item && item.manufacturer || ''));
    if(ctx.byId('formSymbol')) ctx.byId('formSymbol').value = String(item && item.symbol || '');
    if(ctx.byId('formName')) ctx.byId('formName').value = String(item && item.name || '');
    if(ctx.byId('formPrice')) ctx.byId('formPrice').value = item && item.price != null ? item.price : '';
    if(ctx.byId('formHasGrain')) ctx.byId('formHasGrain').checked = !!(item && item.hasGrain);
  }
  function applyAccessoryFormState(item){
    ctx.setSelectOptions(ctx.byId('formManufacturer'), ctx.buildManufacturerOptions('accessories', '', item && item.manufacturer), String(item && item.manufacturer || ''), String(item && item.manufacturer || ''));
    if(ctx.byId('formSymbol')) ctx.byId('formSymbol').value = String(item && item.symbol || '');
    if(ctx.byId('formName')) ctx.byId('formName').value = String(item && item.name || '');
    if(ctx.byId('formPrice')) ctx.byId('formPrice').value = item && item.price != null ? item.price : '';
    if(ctx.byId('formHasGrain')) ctx.byId('formHasGrain').checked = false;
  }
  function applyLaborFormState(item){
    const labor = FC.laborCatalog || {};
    const def = labor.normalizeDefinition ? labor.normalizeDefinition(item || defaultServiceDraft('quoteRates')) : (item || {});
    setValue('laborUsage', 'universal');
    setValue('laborAutoRole', def.autoRole || 'none');
    setValue('laborRateType', def.rateType || def.rateKey || 'workshop');
    setValue('laborTimeBlockHours', Number(def.timeBlockHours) || 0);
    setValue('laborDefaultMultiplier', Number(def.defaultMultiplier) || 1);
    setValue('laborQuantityMode', def.quantityMode || 'none');
    setValue('laborTierText', labor.tiersToText ? labor.tiersToText(def.quantityTiers || []) : '');
    setValue('laborStartHours', Number(def.startHours) || 0);
    setValue('laborStartQty', Number(def.startQty) || 1);
    setValue('laborStepEveryQty', Number(def.stepEveryQty) || 1);
    setValue('laborStepHours', Number(def.stepHours) || 0);
    setValue('laborVolumePricePerM3', Number(def.volumePricePerM3) || 0);
    setValue('laborVolumeTimeMode', def.volumeTimeMode || 'none');
    setValue('laborVolumeTimePerM3', Number(def.volumeTimePerM3) || 0);
    setValue('laborVolumeTimeTierText', labor.volumeTiersToText ? labor.volumeTiersToText(def.volumeTimeTiers || []) : '');
    setValue('laborHeightMinMm', Number(def.heightMinMm) || 0);
    setValue('laborHeightMaxMm', Number(def.heightMaxMm) || 0);
    setChecked('laborActive', def.active !== false);
    setChecked('laborInternalOnly', def.internalOnly !== false);
  }
  function applyServiceFormState(item){
    const kind = ctx.currentListKind();
    const category = String(item && item.category || (kind === 'workshopServices' ? 'Cięcie' : 'Korpusy'));
    ctx.setSelectOptions(ctx.byId('formCategory'), ctx.buildCategoryOptions(kind, category), category, category);
    if(ctx.byId('formServiceName')) ctx.byId('formServiceName').value = String(item && item.name || '');
    if(ctx.byId('formServicePrice')) ctx.byId('formServicePrice').value = item && item.price != null ? item.price : '';
    if(kind === 'quoteRates') applyLaborFormState(item || defaultServiceDraft(kind));
  }

  function renderItemModal(){
    const kind = ctx.currentListKind();
    const cfg = ctx.currentConfig();
    const isEdit = !!(ctx.appUiState() && ctx.appUiState().editingId);
    const item = currentEditedItem();
    if(ctx.byId('editingIndicator')) ctx.byId('editingIndicator').style.display = isEdit ? '' : 'none';
    if(ctx.byId('priceItemModalTitle')) ctx.byId('priceItemModalTitle').textContent = isEdit ? 'Edytuj pozycję' : cfg.addLabel;
    if(ctx.byId('priceItemModalSubtitle')) ctx.byId('priceItemModalSubtitle').textContent = cfg.subtitle;
    if(ctx.byId('priceItemModalIcon')) ctx.byId('priceItemModalIcon').textContent = cfg.icon;
    if(ctx.byId('priceFormTitle')) ctx.byId('priceFormTitle').textContent = isEdit ? 'Edytuj pozycję' : cfg.addLabel;
    if(ctx.byId('materialFormFields')) ctx.byId('materialFormFields').style.display = (cfg.formKind === 'material' || cfg.formKind === 'accessory') ? '' : 'none';
    if(ctx.byId('serviceFormFields')) ctx.byId('serviceFormFields').style.display = cfg.formKind === 'service' ? '' : 'none';
    const laborWrap = laborFields();
    if(laborWrap) laborWrap.style.display = (cfg.formKind === 'service' && kind === 'quoteRates') ? '' : 'none';
    const materialTypeWrap = filterMaterialWrapper();
    const manufacturerWrap = filterManufacturerWrapper();
    const grainRow = formHasGrainRow();
    if(materialTypeWrap) materialTypeWrap.style.display = cfg.formKind === 'material' ? '' : 'none';
    if(manufacturerWrap) manufacturerWrap.style.display = (cfg.formKind === 'material' || cfg.formKind === 'accessory') ? '' : 'none';
    if(grainRow) grainRow.style.display = cfg.formKind === 'material' ? 'flex' : 'none';
    if(cfg.formKind === 'material') applyMaterialFormState(item || defaultMaterialDraft());
    else if(cfg.formKind === 'accessory') applyAccessoryFormState(item || defaultAccessoryDraft());
    else applyServiceFormState(item || defaultServiceDraft(kind));
    if(cfg.formKind === 'service'){
      const categoryWrap = formCategoryWrapper();
      const nameWrap = formServiceNameWrapper();
      if(categoryWrap) categoryWrap.style.display = '';
      if(nameWrap) nameWrap.style.display = '';
    }
    if(kind === 'quoteRates') { hideLaborUsageField(); mountLaborChoiceLaunchers(); }
    decorateFieldHelpLabels();
    wireItemDirtyEvents();
    ctx.runtimeState.itemInitialSignature = currentItemSignature();
    updateItemActionState();
  }

  function openPriceItemModal(id){
    const modal = ctx.byId('priceItemModal');
    if(!modal) return;
    const wasOpen = modal.style.display === 'flex';
    ctx.appUiState().editingId = id || null;
    ctx.persistUi();
    ctx.runtimeState.itemModalOpen = true;
    modal.style.display = 'flex';
    ctx.setModalShellOpen(modal, wasOpen);
    renderItemModal();
  }
  function doClosePriceItemModal(){
    ctx.runtimeState.itemModalOpen = false;
    ctx.runtimeState.itemInitialSignature = '';
    ctx.appUiState().editingId = null;
    ctx.persistUi();
    const modal = ctx.byId('priceItemModal');
    if(modal) modal.style.display = 'none';
    return true;
  }
  async function requestClosePriceItemModal(){
    if(!ctx.runtimeState.itemModalOpen) return true;
    if(isItemDirty()){
      const ok = await ctx.confirmDiscard();
      if(!ok) return false;
    }
    doClosePriceItemModal();
    return true;
  }

  Object.assign(ctx, { currentEditedItem, getCurrentMaterialDraft, getCurrentAccessoryDraft, getCurrentServiceDraft, isItemDirty, updateItemActionState, renderItemModal, openPriceItemModal, doClosePriceItemModal, requestClosePriceItemModal });
})();
