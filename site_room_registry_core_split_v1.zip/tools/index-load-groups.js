const INDEX_LOAD_GROUPS = [
  {
    "id": "startup-foundation",
    "label": "Bootstrap / core / state foundation",
    "scripts": [
      "js/boot.js",
      "js/core/actions.js",
      "js/core/modals.js",
      "js/app/shared/core-failsafe.js",
      "js/app/shared/dom-guard.js",
      "js/app/shared/constants.js",
      "js/app/shared/utils.js",
      "js/app/shared/migrate.js",
      "js/app/shared/schema.js",
      "js/app/shared/storage.js",
      "js/app/project/project-model.js",
      "js/app/project/project-store.js",
      "js/app/project/project-bridge.js",
      "js/app/shared/ui-state.js",
      "js/app/investor/session.js",
      "js/app/investor/investors-store.js",
      "js/app/shared/room-registry-core.js",
      "js/app/shared/room-registry.js"
    ]
  },
  {
    "id": "business-domains",
    "label": "Catalog / service / investor domains",
    "scripts": [
      "js/app/catalog/catalog-domain.js",
      "js/app/catalog/catalog-migration.js",
      "js/app/service/service-order-store.js",
      "js/app/catalog/catalog-store.js",
      "js/app/catalog/catalog-selectors.js",
      "js/app/service/cutting/service-cutting-common.js",
      "js/app/service/cutting/service-cutting-rozrys.js",
      "js/app/service/cutting/service-order-detail.js",
      "js/app/service/service-orders.js",
      "js/app/investor/investor-editor-state.js",
      "js/app/investor/investor-persistence.js",
      "js/app/investor/investor-navigation-guard.js",
      "js/app/investor/investor-choice.js",
      "js/app/investor/investor-links.js",
      "js/app/investor/investor-field-render.js",
      "js/app/investor/investor-room-actions.js",
      "js/app/investor/investor-actions.js",
      "js/app/investor/investor-modals.js",
      "js/app/investor/investor-pdf.js",
      "js/app/investor/investor-rooms.js",
      "js/app/investor/investor-ui.js"
    ]
  },
  {
    "id": "ui-shell",
    "label": "Global UI shell / bindings / shared modal helpers",
    "scripts": [
      "js/app/ui/app-view.js",
      "js/app/ui/sections.js",
      "js/app/ui/views.js",
      "js/app/ui/work-mode-hub.js",
      "js/app/shared/validate.js",
      "js/app/ui/bindings.js",
      "js/app/ui/actions-register.js",
      "js/app/material/material-common.js",
      "js/app/material/material-registry.js",
      "js/app/material/price-modal.js",
      "js/app/ui/confirm-box.js",
      "js/app/ui/info-box.js",
      "js/app/ui/panel-box.js"
    ]
  },
  {
    "id": "app-runtime",
    "label": "Room / session / app runtime foundation",
    "scripts": [
      "js/app/material/material-part-options.js",
      "js/app/rozrys/rozrys-grain.js",
      "js/app/rozrys/rozrys-validation.js",
      "js/app/cabinet/corner-sketch.js",
      "js/app/cabinet/cabinet-cutlist.js",
      "js/app/cabinet/cabinet-actions.js",
      "js/app/cabinet/cabinet-summary.js",
      "js/app/ui/layout-state.js",
      "js/app/ui/list-scroll-memory.js",
      "js/app/ui/tab-navigation.js",
      "js/app/cabinet/front-hardware.js",
      "js/app/shared/calc.js",
      "js/app/investor/project-bootstrap.js",
      "js/app/bootstrap/app-state-bootstrap.js",
      "js/app/bootstrap/app-ui-bootstrap.js",
      "js/app/ui/settings-ui.js",
      "js/app/ui/wywiad-room-settings.js",
      "js/app/rozrys/rozrys-project-source.js",
      "js/app/rozrys/rozrys-lazy-manifest.js",
      "js/app/rozrys/rozrys-lazy-loader.js",
      "js/app/rozrys/rozrys-shell.js",
      "js/app.js",
      "js/app/shared/public-api.js"
    ]
  },
  {
    "id": "cabinet-wywiad",
    "label": "Wywiad / cabinet modal stack",
    "scripts": [
      "js/app/cabinet/cabinet-fronts.js",
      "js/app/cabinet/cabinet-modal-validation.js",
      "js/app/cabinet/cabinet-modal-draft.js",
      "js/app/cabinet/cabinet-modal-fields.js",
      "js/app/cabinet/cabinet-modal-finalize.js",
      "js/app/cabinet/cabinet-modal-set-wizard.js",
      "js/app/cabinet/cabinet-modal-standing-corner-standard.js",
      "js/app/cabinet/cabinet-modal-standing-specials.js",
      "js/app/cabinet/cabinet-modal-standing-extras.js",
      "js/app/cabinet/cabinet-modal-standing-front-controls.js",
      "js/app/cabinet/cabinet-modal-standing.js",
      "js/app/cabinet/cabinet-modal-hanging.js",
      "js/app/cabinet/cabinet-modal-module.js",
      "js/app/cabinet/cabinet-choice-launchers.js",
      "js/app/cabinet/cabinet-modal.js",
      "js/app/investor/investor-project.js",
      "js/app/ui/tabs-router.js"
    ]
  },
  {
    "id": "tabs-quote-wycena",
    "label": "Classic tabs / quote / wycena",
    "scripts": [
      "js/tabs/wywiad.js",
      "js/tabs/rysunek.js",
      "js/tabs/material.js",
      "js/tabs/czynnosci.js",
      "js/app/quote/quote-offer-store.js",
      "js/app/quote/quote-snapshot-store.js",
      "js/app/quote/quote-scope-entry.js",
      "js/app/project/project-status-sync.js",
      "js/app/project/project-status-manual-guard.js",
      "js/app/quote/quote-snapshot.js",
      "js/app/quote/quote-pdf.js",
      "js/app/wycena/wycena-core.js",
      "js/app/wycena/wycena-tab-helpers.js",
      "js/app/wycena/wycena-tab-selection.js",
      "js/app/wycena/wycena-tab-editor.js",
      "js/app/wycena/wycena-tab-scroll.js",
      "js/app/wycena/wycena-tab-history.js",
      "js/app/wycena/wycena-tab-status-bridge.js",
      "js/tabs/wycena.js"
    ]
  },
  {
    "id": "optimizer-and-stock",
    "label": "Optimizer / stock base",
    "scripts": [
      "js/app/optimizer/cut-optimizer.js",
      "js/app/optimizer/start-along.js",
      "js/app/optimizer/start-across.js",
      "js/app/optimizer/start-optimax.js",
      "js/app/optimizer/speed-turbo.js",
      "js/app/optimizer/speed-dokladnie.js",
      "js/app/optimizer/speed-max.js",
      "js/app/material/magazyn.js"
    ]
  },
  {
    "id": "rozrys-shared",
    "label": "ROZRYS shared APIs kept on startup",
    "scripts": [
      "js/app/rozrys/rozrys-choice.js",
      "js/app/rozrys/rozrys-prefs.js",
      "js/app/rozrys/rozrys-scope.js",
      "js/app/rozrys/rozrys-pickers.js",
      "js/app/rozrys/rozrys-sheet-model.js",
      "js/app/rozrys/rozrys-sheet-helpers.js",
      "js/app/rozrys/rozrys-sheet-draw.js",
      "js/app/rozrys/rozrys-print.js",
      "js/app/rozrys/rozrys-print-layout.js",
      "js/app/rozrys/rozrys-engine.js",
      "js/app/rozrys/rozrys-stock.js",
      "js/app/rozrys/rozrys-cache.js",
      "js/app/rozrys/rozrys-lists.js",
      "js/app/rozrys/rozrys-render.js",
      "js/app/rozrys/rozrys-summary.js"
    ]
  }
];

module.exports = { INDEX_LOAD_GROUPS };
