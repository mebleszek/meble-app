(function(){
  'use strict';
  window.FC = window.FC || {};
  const FC = window.FC;

  function escapeHtml(s){
    return String(s ?? '').replace(/[&<>"']/g, (c)=> ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  }

  function getRoomStatus(inv, roomId){
    const rooms = inv && Array.isArray(inv.rooms) ? inv.rooms : [];
    const found = rooms.find((room)=> room && String(room.id || '') === String(roomId || ''));
    return String((found && (found.projectStatus || found.status)) || (FC.investors && FC.investors.DEFAULT_PROJECT_STATUS) || 'nowy');
  }


  function getStatusLabel(value){
    const key = String(value || '').trim().toLowerCase();
    const labels = (FC.projectStatusManualGuard && FC.projectStatusManualGuard.STATUS_LABELS) || {};
    return labels[key] || (key ? key.replace(/_/g, ' ') : 'Status');
  }

  function buildStatusOptionsForRoom(statusOptions, currentStatus){
    const options = Array.isArray(statusOptions) ? statusOptions.slice() : [];
    const current = String(currentStatus || '').trim();
    if(current && !options.some((opt)=> String(opt && opt.value || '') === current)){
      options.unshift({ value:current, label:getStatusLabel(current), currentOnly:true, description:'Ten status wynika z wyceny i nie jest dostępny jako ręczny wybór w Inwestorze.' });
    }
    return options;
  }

  function buildProjectCards(inv, disabled, statusOptions){
    const rooms = (FC.roomRegistry && typeof FC.roomRegistry.getActiveRoomDefs === 'function') ? FC.roomRegistry.getActiveRoomDefs() : [];
    if(!rooms.length) return '<div class="muted">Brak dodanych pomieszczeń.</div>';
    return rooms.map((room)=> {
      const status = getRoomStatus(inv, room.id);
      const roomOptions = buildStatusOptionsForRoom(statusOptions, status);
      const statusOptionsHtml = roomOptions.map((opt)=> {
        const value = String(opt && opt.value || '');
        const selected = value === String(status || '') ? ' selected' : '';
        const currentOnly = opt && opt.currentOnly ? ' data-current-only="1" data-description="' + escapeHtml(opt.description || '') + '"' : '';
        return `<option value="${escapeHtml(value)}"${selected}${currentOnly}>${escapeHtml(opt && opt.label || value)}</option>`;
      }).join('');
      const buttonDisabled = disabled ? 'disabled' : '';
      return `
        <div class="investor-project-card">
          <div class="investor-project-card__top">
            <button class="btn investor-room-quick-btn${disabled ? ' is-disabled' : ''}" data-action="open-room" data-room="${escapeHtml(room.id)}" ${buttonDisabled}>${escapeHtml(room.label || room.name || room.id)}</button>
          </div>
          <div class="investor-project-status-shell${disabled ? ' is-disabled' : ''}">
            <select id="invProjectStatus_${escapeHtml(room.id)}" hidden>${statusOptionsHtml}</select>
            <div id="invProjectStatus_${escapeHtml(room.id)}Launch"></div>
          </div>
        </div>
      `;
    }).join('');
  }

  function mountProjectStatusChoices(inv, statusOptions, opts){
    const cfg = Object.assign({ disabled:false, onChange:null }, opts || {});
    const rooms = (FC.roomRegistry && typeof FC.roomRegistry.getActiveRoomDefs === 'function') ? FC.roomRegistry.getActiveRoomDefs() : [];
    const choiceApi = FC.investorChoice;
    if(!(choiceApi && typeof choiceApi.mountChoice === 'function')) return;
    rooms.forEach((room)=> {
      const selectEl = document.getElementById(`invProjectStatus_${room.id}`);
      const mount = document.getElementById(`invProjectStatus_${room.id}Launch`);
      if(!(selectEl && mount)) return;
      try{
        const currentValue = String(selectEl.value || '');
        let validationMap = null;
        try{
          if(FC.projectStatusManualGuard && typeof FC.projectStatusManualGuard.buildManualStatusChoiceStates === 'function'){
            const built = FC.projectStatusManualGuard.buildManualStatusChoiceStates(
              String(inv && inv.id || ''),
              String(room.id || ''),
              Array.from(selectEl.options || []).map((opt)=> String(opt && opt.value || ''))
            );
            validationMap = built && built.states && typeof built.states === 'object' ? built.states : null;
          }
        }catch(_){ validationMap = null; }
        Array.from(selectEl.options || []).forEach((opt)=> {
          if(!opt) return;
          opt.disabled = false;
          opt.removeAttribute('data-description');
          if(cfg.disabled) return;
          try{
            const value = String(opt.value || '');
            if(opt.getAttribute('data-current-only') === '1' || value === 'wstepna_wycena'){
              opt.disabled = true;
              opt.setAttribute('data-description', String(opt.getAttribute('data-description') || 'Wycena wstępna powstaje w dziale Wycena, nie przez ręczną zmianę statusu w Inwestorze.'));
              if(String(opt.value || '') === currentValue) opt.selected = true;
              return;
            }
            let validation = validationMap ? validationMap[value] : null;
            if(!validation && FC.projectStatusManualGuard && typeof FC.projectStatusManualGuard.validateManualStatusChange === 'function'){
              validation = FC.projectStatusManualGuard.validateManualStatusChange(String(inv && inv.id || ''), String(room.id || ''), value);
            }
            if(validation && validation.blocked){
              opt.disabled = true;
              opt.setAttribute('data-description', String(validation.title || validation.message || 'Niedostępne w tym stanie.'));
            }
          }catch(_){ }
          if(String(opt.value || '') === currentValue) opt.selected = true;
        });
      }catch(_){ }
      choiceApi.mountChoice({
        mount,
        selectEl,
        title:'Wybierz status projektu',
        buttonClass:'investor-choice-launch investor-project-status-btn',
        disabled: !!cfg.disabled,
        onChange: (value)=> {
          if(typeof cfg.onChange === 'function') cfg.onChange(String(room.id || ''), String(value || ''));
        }
      });
    });
  }

  FC.investorRooms = {
    buildProjectCards,
    mountProjectStatusChoices,
    getRoomStatus,
  };
})();
