/* magazyn.js — magazyn płyt (MVP)
   - Przechowuje typy płyt (materiał + format) i ilości
   - Dane w localStorage pod STORAGE_KEYS.sheets
   - UI renderowane w #magazynRoot
*/

(function(){
  'use strict';
  window.FC = window.FC || {};
  const FC = window.FC;

  function sk(){
    return (FC.constants && FC.constants.STORAGE_KEYS) ? FC.constants.STORAGE_KEYS : (typeof STORAGE_KEYS !== 'undefined' ? STORAGE_KEYS : {});
  }

  function getAll(){
    try{
      const key = sk().sheets;
      const data = (FC.storage && FC.storage.getJSON) ? FC.storage.getJSON(key, { sheets: [] }) : { sheets: [] };
      if(!data || !Array.isArray(data.sheets)) return { sheets: [] };
      return data;
    }catch(_){
      return { sheets: [] };
    }
  }

  function saveAll(data){
    try{
      const key = sk().sheets;
      if(FC.storage && FC.storage.setJSON) FC.storage.setJSON(key, data);
    }catch(_){ }
  }

  function uid(){
    return 'sh_' + Math.random().toString(36).slice(2,9) + Date.now().toString(36);
  }

  function upsertSheet(entry){
    const data = getAll();
    const e = entry || {};
    const id = e.id || uid();
    const norm = {
      id,
      material: String(e.material||'').trim(),
      width: Math.round(Number(e.width)||0),
      height: Math.round(Number(e.height)||0),
      qty: Math.round(Number(e.qty)||0),
    };
    if(!(norm.width>0 && norm.height>0)) return false;
    if(norm.qty < 0) norm.qty = 0;
    const idx = data.sheets.findIndex(s=>String(s.id)===String(id));
    if(idx>=0) data.sheets[idx] = norm;
    else data.sheets.unshift(norm);
    saveAll(data);
    return true;
  }

  function removeSheet(id){
    const data = getAll();
    data.sheets = data.sheets.filter(s=>String(s.id)!==String(id));
    saveAll(data);
  }

  function findForMaterial(material){
    const m = String(material||'').trim();
    const data = getAll();
    return data.sheets.filter(s=>String(s.material||'').trim()===m);
  }

  function addSheetStock(material, width, height, qtyDelta){
    const mat = String(material || '').trim();
    const w = Math.round(Number(width) || 0);
    const h = Math.round(Number(height) || 0);
    const delta = Math.max(1, Math.round(Number(qtyDelta) || 0));
    if(!(mat && w > 0 && h > 0 && delta > 0)) return false;
    const rows = findForMaterial(mat);
    const exact = rows.find((row)=> Math.round(Number(row && row.width) || 0) === w && Math.round(Number(row && row.height) || 0) === h);
    if(exact){
      return upsertSheet({ id: exact.id, material: mat, width: w, height: h, qty: Math.max(0, Math.round(Number(exact.qty) || 0)) + delta });
    }
    return upsertSheet({ material: mat, width: w, height: h, qty: delta });
  }

  function sortByAreaDesc(list){
    return (Array.isArray(list) ? list.slice() : []).sort((a,b)=>{
      const aa = (Number(a && a.width)||0) * (Number(a && a.height)||0);
      const bb = (Number(b && b.width)||0) * (Number(b && b.height)||0);
      if(bb !== aa) return bb - aa;
      if((Number(b && b.width)||0) !== (Number(a && a.width)||0)) return (Number(b && b.width)||0) - (Number(a && a.width)||0);
      return (Number(b && b.height)||0) - (Number(a && a.height)||0);
    });
  }

  function getPreferredFormat(material){
    const rows = sortByAreaDesc(findForMaterial(material));
    return rows[0] || null;
  }

  function findHalfSheetsForMaterial(material, fullWidth, fullHeight){
    const rows = findForMaterial(material).filter(s => (Number(s && s.qty)||0) > 0);
    const fw = Math.max(1, Math.round(Number(fullWidth)||0));
    const fh = Math.max(1, Math.round(Number(fullHeight)||0));
    if(!(fw > 0 && fh > 0)) return [];

    // Half sheet on the shop floor means the long side stays full length
    // and only the short side is cut roughly in half (e.g. 2800x1030).
    const fullLong = Math.max(fw, fh);
    const fullShort = Math.min(fw, fh);
    const halfShort = Math.max(1, Math.floor(fullShort / 20) * 10);
    const toleranceMm = 10;

    return rows.filter(row => {
      const w = Math.round(Number(row && row.width)||0);
      const h = Math.round(Number(row && row.height)||0);
      const rowLong = Math.max(w, h);
      const rowShort = Math.min(w, h);
      const keepsLength = rowLong === fullLong;
      const looksLikeHalf = Math.abs(rowShort - halfShort) <= toleranceMm;
      // Orientation matters: a real half sheet is treated as full-length x half-width,
      // not as the same rectangle rotated the other way around.
      const orientedLikeLengthHalf = (fw >= fh) ? (w >= h) : (h >= w);
      return keepsLength && looksLikeHalf && orientedLikeLengthHalf;
    });
  }

  function h(tag, attrs, children){
    const el = document.createElement(tag);
    if(attrs){
      for(const k in attrs){
        if(k==='class') el.className = attrs[k];
        else if(k==='html') el.innerHTML = attrs[k];
        else el.setAttribute(k, attrs[k]);
      }
    }
    (children||[]).forEach(ch=> el.appendChild(ch));
    return el;
  }

  function render(){
    const root = document.getElementById('magazynRoot');
    if(!root) return;

    const data = getAll();

    root.innerHTML = '';
    const card = h('div', { class:'card' });
    card.appendChild(h('h3', { style:'margin:0', html:'Magazyn płyt' }));
    card.appendChild(h('div', { class:'muted', style:'margin-top:6px', html:'Dodaj formaty płyt, żeby ROZRYS mógł je podpowiadać. Możesz też dodać realną pół płytę, np. 2800×1030, żeby końcówka mogła ją wykorzystać, jeśli jest na stanie.' }));

    // add form
    const form = h('div', { class:'mag-stock-form', style:'margin-top:12px' });
    const topRow = h('div', { class:'mag-stock-form__top' });
    topRow.appendChild(h('div', { class:'mag-stock-field mag-stock-field--material' }, [
      h('label', { html:'Materiał (klucz z Materiały)' }),
      h('input', { id:'magMat', placeholder:'np. Korpus: laminat • Egger W1100' })
    ]));
    form.appendChild(topRow);

    const bottomRow = h('div', { class:'mag-stock-form__bottom' });
    bottomRow.appendChild(h('div', { class:'mag-stock-field mag-stock-field--dim' }, [
      h('label', { html:'Szer. (mm)' }),
      h('input', { id:'magW', type:'number', placeholder:'2800' })
    ]));
    bottomRow.appendChild(h('div', { class:'mag-stock-field mag-stock-field--dim' }, [
      h('label', { html:'Wys. (mm)' }),
      h('input', { id:'magH', type:'number', placeholder:'2070' })
    ]));
    bottomRow.appendChild(h('div', { class:'mag-stock-field mag-stock-field--qty' }, [
      h('label', { html:'Ilość (szt.)' }),
      h('input', { id:'magQty', type:'number', placeholder:'1', value:'1', min:'1' })
    ]));

    const btnRow = h('div', { class:'mag-stock-form__actions' });
    const addBtn = h('button', { class:'btn-success', type:'button' });
    addBtn.textContent = 'Dodaj do magazynu';
    addBtn.addEventListener('click', () => {
      const mat = document.getElementById('magMat')?.value || '';
      const w = document.getElementById('magW')?.value;
      const hh = document.getElementById('magH')?.value;
      const qty = document.getElementById('magQty')?.value;
      if(!mat.trim()) return (FC.infoBox && FC.infoBox.open ? FC.infoBox.open({ title:'Brak materiału', message:'Wpisz materiał (klucz).' }) : alert('Wpisz materiał (klucz)'));
      if(!(Number(w)>0 && Number(hh)>0)) return (FC.infoBox && FC.infoBox.open ? FC.infoBox.open({ title:'Brak formatu', message:'Podaj format płyty.' }) : alert('Podaj format płyty'));
      const delta = Math.max(1, Math.round(Number(qty || 1) || 1));
      addSheetStock(mat.trim(), Number(w), Number(hh), delta);
      const qtyEl = document.getElementById('magQty');
      if(qtyEl) qtyEl.value = '1';
      render();
    });
    btnRow.appendChild(addBtn);
    bottomRow.appendChild(btnRow);
    form.appendChild(bottomRow);

    card.appendChild(form);

    card.appendChild(h('div', { class:'hr' }));

    if(!data.sheets.length){
      card.appendChild(h('div', { class:'muted', html:'Brak zapisanych płyt w magazynie.' }));
      root.appendChild(card);
      return;
    }

    // list
    const list = h('div', { style:'display:flex;flex-direction:column;gap:10px' });
    data.sheets.forEach(s=>{
      const row = h('div', { class:'card', style:'margin:0' });
      row.appendChild(h('div', { style:'font-weight:900', html: (s.material||'—') }));
      row.appendChild(h('div', { class:'muted xs', style:'margin-top:4px', html:`${s.width} × ${s.height} mm • ilość: ${s.qty}` }));
      const actions = h('div', { style:'display:flex;gap:8px;justify-content:flex-end;margin-top:8px' });
      const del = h('button', { class:'btn-danger', type:'button' });
      del.textContent = 'Usuń';
      del.addEventListener('click', async () => {
        let ok = true;
        if(FC.confirmBox && typeof FC.confirmBox.ask === 'function'){
          ok = await FC.confirmBox.ask({
            title:'Usunąć format z magazynu?',
            message:'Ta pozycja zostanie usunięta z magazynu płyt.',
            confirmText:'✓ TAK',
            cancelText:'✕ NIE',
            confirmTone:'success',
            cancelTone:'danger',
            dismissOnOverlay:false,
          });
        }else{
          ok = confirm('Usunąć z magazynu?');
        }
        if(!ok) return;
        removeSheet(s.id);
        render();
      });
      actions.appendChild(del);
      row.appendChild(actions);
      list.appendChild(row);
    });
    card.appendChild(list);
    root.appendChild(card);
  }

  FC.magazyn = {
    getAll,
    saveAll,
    upsertSheet,
    removeSheet,
    findForMaterial,
    addSheetStock,
    getPreferredFormat,
    findHalfSheetsForMaterial,
    render,
  };
})();
