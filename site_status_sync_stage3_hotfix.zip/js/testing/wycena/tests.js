(function(root){
  'use strict';
  const host = root || (typeof window !== 'undefined' ? window : globalThis);
  host.FC = host.FC || {};
  const FC = host.FC;
  const H = FC.testHarness;
  if(!H) throw new Error('Brak FC.testHarness');

  function clone(value){
    try{ return JSON.parse(JSON.stringify(value)); }catch(_){ return value; }
  }

  function withInvestorProjectFixture(options, run){
    const cfg = options && typeof options === 'object' ? options : {};
    const prevInvestors = FC.investors && typeof FC.investors.readAll === 'function' ? FC.investors.readAll() : [];
    const prevCurrentInvestorId = FC.investors && typeof FC.investors.getCurrentId === 'function' ? FC.investors.getCurrentId() : '';
    const prevProjects = FC.projectStore && typeof FC.projectStore.readAll === 'function' ? FC.projectStore.readAll() : [];
    const prevCurrentProjectId = FC.projectStore && typeof FC.projectStore.getCurrentProjectId === 'function' ? FC.projectStore.getCurrentProjectId() : '';
    const prevSnapshots = FC.quoteSnapshotStore && typeof FC.quoteSnapshotStore.readAll === 'function' ? FC.quoteSnapshotStore.readAll() : [];
    const prevDrafts = FC.quoteOfferStore && typeof FC.quoteOfferStore.readAll === 'function' ? FC.quoteOfferStore.readAll() : [];
    const prevOverride = FC.rozrys && FC.rozrys.__projectOverride;
    const prevProjectData = Object.prototype.hasOwnProperty.call(host, 'projectData') ? host.projectData : undefined;
    const prevCutList = FC.cabinetCutlist && FC.cabinetCutlist.getCabinetCutList;
    const investorId = String(cfg.investorId || 'inv_cross');
    const projectId = String(cfg.projectId || 'proj_cross');
    const rooms = Array.isArray(cfg.rooms) && cfg.rooms.length ? clone(cfg.rooms) : [
      { id:'room_kuchnia_gora', baseType:'kuchnia', name:'Kuchnia góra', label:'Kuchnia góra', projectStatus:'nowy' },
      { id:'room_salon', baseType:'pokoj', name:'Salon', label:'Salon', projectStatus:'nowy' },
    ];
    const projectData = clone(cfg.projectData || {
      schemaVersion: 2,
      meta: {
        roomDefs: rooms.reduce((acc, room)=>{
          acc[room.id] = { id:room.id, baseType:room.baseType, name:room.name, label:room.label };
          return acc;
        }, {}),
        roomOrder: rooms.map((room)=> room.id),
      },
      room_kuchnia_gora: { cabinets:[{ id:'cab_k' }], fronts:[], sets:[], settings:{} },
      room_salon: { cabinets:[{ id:'cab_s' }], fronts:[], sets:[], settings:{} },
    });
    const investor = Object.assign({ id:investorId, kind:'person', name:'Jan Test', rooms:clone(rooms), meta:{} }, clone(cfg.investor || {}), { id:investorId, rooms:clone(rooms) });
    const projectRecord = Object.assign({ id:projectId, investorId, title:'Projekt testowy', status:String(cfg.status || 'nowy'), projectData:clone(projectData), meta:{} }, clone(cfg.projectRecord || {}), { id:projectId, investorId, projectData:clone(projectData) });
    try{
      FC.investors && FC.investors.writeAll && FC.investors.writeAll([investor]);
      FC.investors && FC.investors.setCurrentId && FC.investors.setCurrentId(investorId);
      FC.projectStore && FC.projectStore.writeAll && FC.projectStore.writeAll([projectRecord]);
      FC.projectStore && FC.projectStore.setCurrentProjectId && FC.projectStore.setCurrentProjectId(projectId);
      if(FC.quoteSnapshotStore && typeof FC.quoteSnapshotStore.writeAll === 'function') FC.quoteSnapshotStore.writeAll([]);
      if(FC.quoteOfferStore && typeof FC.quoteOfferStore.writeAll === 'function') FC.quoteOfferStore.writeAll([]);
      host.projectData = clone(projectData);
      if(FC.rozrys) FC.rozrys.__projectOverride = host.projectData;
      if(typeof cfg.cutListFn === 'function' && FC.cabinetCutlist){
        FC.cabinetCutlist.getCabinetCutList = cfg.cutListFn;
      }
      return run({ investorId, projectId, rooms:clone(rooms), projectData:host.projectData });
    } finally {
      if(FC.cabinetCutlist && prevCutList) FC.cabinetCutlist.getCabinetCutList = prevCutList;
      if(FC.rozrys) FC.rozrys.__projectOverride = prevOverride;
      if(prevProjectData === undefined) { try{ delete host.projectData; }catch(_){ host.projectData = undefined; } }
      else host.projectData = prevProjectData;
      FC.quoteOfferStore && FC.quoteOfferStore.writeAll && FC.quoteOfferStore.writeAll(prevDrafts);
      FC.quoteSnapshotStore && FC.quoteSnapshotStore.writeAll && FC.quoteSnapshotStore.writeAll(prevSnapshots);
      FC.projectStore && FC.projectStore.writeAll && FC.projectStore.writeAll(prevProjects);
      FC.projectStore && FC.projectStore.setCurrentProjectId && FC.projectStore.setCurrentProjectId(prevCurrentProjectId);
      FC.investors && FC.investors.writeAll && FC.investors.writeAll(prevInvestors);
      FC.investors && FC.investors.setCurrentId && FC.investors.setCurrentId(prevCurrentInvestorId);
    }
  }

  function runAll(){
    return H.runSuite('WYCENA smoke testy', [
      H.makeTest('Wycena', 'Katalog usług AGD uzupełnia brakujące pozycje bez duplikowania istniejących', 'Pilnuje, czy Wycena zawsze ma osobne pozycje montażu AGD i czy kolejne przebiegi nie rozmnażają usług.', ()=>{
        H.assert(FC.wycenaCore && typeof FC.wycenaCore.ensureServiceCatalog === 'function', 'Brak wycenaCore.ensureServiceCatalog');
        const input = [
          { id:'svc_1', category:'AGD', name:'Piekarnik do zabudowy', price:111 },
          { id:'svc_2', category:'Montaż', name:'Montaż blatu', price:80 }
        ];
        const result = FC.wycenaCore.ensureServiceCatalog(input);
        H.assert(result && Array.isArray(result.list), 'ensureServiceCatalog nie zwrócił listy', result);
        const oven = result.list.filter((item)=> String(item && item.name || '') === 'Piekarnik do zabudowy');
        H.assert(oven.length === 1, 'Usługa AGD została zduplikowana', result.list);
        H.assert(result.list.some((item)=> String(item && item.name || '') === 'Zmywarka do zabudowy'), 'Brakuje domyślnej usługi AGD dla zmywarki', result.list);
      }),
      H.makeTest('Wycena', 'Price modal buduje pełniejsze listy wyboru i filtry dla cennika', 'Pilnuje, czy cennik ma własne filtry, zachowuje producentów z registry i nie gubi opcji „wszystkie”.', ()=>{
        H.assert(FC.priceModal && FC.priceModal._debug, 'Brak debug helpers w priceModal');
        const cats = FC.priceModal._debug.buildServiceCategoryOptions('AGD', { includeAll:true });
        H.assert(Array.isArray(cats) && cats.some((item)=> String(item && item.value || '') === 'AGD'), 'Lista kategorii nie zawiera AGD', cats);
        H.assert(cats.some((item)=> String(item && item.value || '') === ''), 'Lista kategorii nie ma opcji wszystkich', cats);
        const manufacturers = FC.priceModal._debug.buildManufacturerOptions('akcesoria', 'Blum', { includeAll:true });
        H.assert(Array.isArray(manufacturers) && manufacturers.some((item)=> /blum/i.test(String(item && item.value || ''))), 'Lista producentów akcesoriów nie zawiera Blum', manufacturers);
        H.assert(manufacturers.some((item)=> String(item && item.value || '') === ''), 'Lista producentów nie ma opcji wszystkich', manufacturers);
        const editManufacturers = FC.priceModal._debug.buildManufacturerOptions('akcesoria', 'Blum');
        H.assert(!editManufacturers.some((item)=> /brak/i.test(String(item && item.label || ''))), 'Do wyboru producenta wróciła pseudo-opcja Brak / własny wpis', editManufacturers);
        const materialTypes = FC.priceModal._debug.buildMaterialTypeOptions('akcesoria', { includeAll:true });
        H.assert(materialTypes.some((item)=> String(item && item.value || '') === 'akcesoria'), 'Lista typów materiału nie zawiera akcesoriów', materialTypes);
      }),

      H.makeTest('Wycena', 'Domyślne nazwy wersji ustawiają się jako Oferta i Wstępna oferta', 'Pilnuje, czy puste nazwy wersji nie zapisują się jako pusty string i dostają domyślne etykiety zgodne z typem oferty.', ()=>{
        H.assert(FC.quoteOfferStore && typeof FC.quoteOfferStore.normalizeCommercial === 'function', 'Brak FC.quoteOfferStore.normalizeCommercial');
        H.assert(FC.quoteSnapshot && typeof FC.quoteSnapshot.buildSnapshot === 'function', 'Brak FC.quoteSnapshot.buildSnapshot');
        const prelimDraft = FC.quoteOfferStore.normalizeCommercial({ preliminary:true, versionName:'' });
        const finalDraft = FC.quoteOfferStore.normalizeCommercial({ preliminary:false, versionName:'' });
        H.assert(String(prelimDraft.versionName || '') === 'Wstępna oferta', 'Domyślna nazwa wstępnej oferty jest błędna', prelimDraft);
        H.assert(String(finalDraft.versionName || '') === 'Oferta', 'Domyślna nazwa zwykłej oferty jest błędna', finalDraft);
        const prelimSnap = FC.quoteSnapshot.buildSnapshot({ commercial:{ preliminary:true, versionName:'' }, totals:{ grand:100 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] } });
        const finalSnap = FC.quoteSnapshot.buildSnapshot({ commercial:{ preliminary:false, versionName:'' }, totals:{ grand:100 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] } });
        H.assert(String(prelimSnap.commercial && prelimSnap.commercial.versionName || '') === 'Wstępna oferta', 'Snapshot nie ustawił domyślnej nazwy dla wyceny wstępnej', prelimSnap);
        H.assert(String(finalSnap.commercial && finalSnap.commercial.versionName || '') === 'Oferta', 'Snapshot nie ustawił domyślnej nazwy dla zwykłej oferty', finalSnap);
      }),

      H.makeTest('Wycena', 'Store oferty zapamiętuje pola handlowe i ilości stawek dla projektu', 'Pilnuje, czy rabat, warunki oferty i ilości stawek wyceny mebli są trzymane per projekt i gotowe do zapisania w snapshotcie.', ()=>{
        H.assert(FC.quoteOfferStore && typeof FC.quoteOfferStore.saveCurrentDraft === 'function', 'Brak FC.quoteOfferStore.saveCurrentDraft');
        const prevProjectStore = FC.projectStore && typeof FC.projectStore.readAll === 'function' ? FC.projectStore.readAll() : [];
        const prevCurrentProjectId = FC.projectStore && typeof FC.projectStore.getCurrentProjectId === 'function' ? FC.projectStore.getCurrentProjectId() : '';
        const prevDrafts = FC.quoteOfferStore.readAll();
        try{
          FC.projectStore.writeAll([{ id:'proj_offer', investorId:'inv_offer', title:'Projekt oferty', projectData:{ kuchnia:{ cabinets:[], fronts:[], sets:[], settings:{} } } }]);
          FC.projectStore.setCurrentProjectId && FC.projectStore.setCurrentProjectId('proj_offer');
          const saved = FC.quoteOfferStore.saveCurrentDraft({
            rateSelections:[{ rateId:'rate_1', qty:2 }],
            selection:{ selectedRooms:['room_kuchnia_gora'], materialScope:{ includeFronts:false, includeCorpus:true } },
            commercial:{ versionName:'Wersja A', preliminary:true, discountPercent:10, offerValidity:'14 dni', leadTime:'4 tygodnie', deliveryTerms:'Montaż w cenie', customerNote:'Oferta testowa' }
          });
          const current = FC.quoteOfferStore.getCurrentDraft();
          H.assert(saved && String(saved.projectId || '') === 'proj_offer', 'Store oferty nie zapisał draftu dla bieżącego projektu', saved);
          H.assert(Array.isArray(current.rateSelections) && current.rateSelections.length === 1 && Number(current.rateSelections[0].qty) === 2, 'Store oferty nie zachował ilości stawek', current);
          H.assert(String(current.commercial.offerValidity || '') === '14 dni' && Number(current.commercial.discountPercent) === 10 && current.commercial.preliminary === true && String(current.commercial.versionName || '') === 'Wersja A', 'Store oferty nie zachował pól handlowych, nazwy wersji albo flagi wyceny wstępnej', current);
          H.assert(Array.isArray(current.selection && current.selection.selectedRooms) && current.selection.selectedRooms[0] === 'room_kuchnia_gora', 'Store oferty nie zachował wyboru pomieszczeń', current);
          H.assert(current.selection && current.selection.materialScope && current.selection.materialScope.includeCorpus === true && current.selection.materialScope.includeFronts === false, 'Store oferty nie zachował zakresu korpusy/fronty', current);
        } finally {
          FC.quoteOfferStore.writeAll(prevDrafts);
          FC.projectStore.writeAll(prevProjectStore);
          FC.projectStore.setCurrentProjectId && FC.projectStore.setCurrentProjectId(prevCurrentProjectId);
        }
      }),


      H.makeTest('Wycena', 'Store oferty nie gubi wyboru pomieszczeń, gdy lista aktywnych pomieszczeń chwilowo zwróci pusty stan', 'Pilnuje, czy zapis wyboru pokoi w Wycena nie jest czyszczony tylko dlatego, że roomRegistry na chwilę odda pustą listę podczas normalizacji draftu.', ()=>{
        H.assert(FC.quoteOfferStore && typeof FC.quoteOfferStore.normalizeSelection === 'function', 'Brak FC.quoteOfferStore.normalizeSelection');
        H.assert(FC.wycenaCore && typeof FC.wycenaCore.normalizeQuoteSelection === 'function', 'Brak FC.wycenaCore.normalizeQuoteSelection');
        const prevRoomRegistry = FC.roomRegistry;
        try{
          FC.roomRegistry = Object.assign({}, prevRoomRegistry, {
            getActiveRoomIds(){ return []; }
          });
          const storeSelection = FC.quoteOfferStore.normalizeSelection({
            selectedRooms:['room_kuchnia_gora'],
            materialScope:{ includeFronts:true, includeCorpus:true }
          });
          H.assert(Array.isArray(storeSelection.selectedRooms) && storeSelection.selectedRooms[0] === 'room_kuchnia_gora', 'Store oferty wyczyścił zapis wyboru pomieszczeń przy pustym roomRegistry', storeSelection);
          const runtimeSelection = FC.wycenaCore.normalizeQuoteSelection({
            selectedRooms:['room_kuchnia_gora'],
            materialScope:{ includeFronts:true, includeCorpus:true }
          });
          H.assert(Array.isArray(runtimeSelection.selectedRooms) && runtimeSelection.selectedRooms[0] === 'room_kuchnia_gora', 'Wycena nie odtworzyła jawnie zapisanego wyboru pomieszczeń', runtimeSelection);
        } finally {
          FC.roomRegistry = prevRoomRegistry;
        }
      }),

      H.makeTest('Wycena', 'Draft oferty przechodzi z zakresu inwestora na projekt bez gubienia flagi wstępnej', 'Pilnuje, czy po pojawieniu się projectId draft zapisany wcześniej dla inwestora nadal jest odczytywany i nie gubi ustawień oferty.', ()=>{
        H.assert(FC.quoteOfferStore && typeof FC.quoteOfferStore.saveDraft === 'function', 'Brak FC.quoteOfferStore.saveDraft');
        const prevProjectStore = FC.projectStore && typeof FC.projectStore.readAll === 'function' ? FC.projectStore.readAll() : [];
        const prevCurrentProjectId = FC.projectStore && typeof FC.projectStore.getCurrentProjectId === 'function' ? FC.projectStore.getCurrentProjectId() : '';
        const prevDrafts = FC.quoteOfferStore.readAll();
        try{
          FC.projectStore.writeAll([{ id:'proj_scope', investorId:'inv_scope', title:'Projekt scope', projectData:{ kuchnia:{ cabinets:[], fronts:[], sets:[], settings:{} } } }]);
          FC.projectStore.setCurrentProjectId && FC.projectStore.setCurrentProjectId('');
          FC.quoteOfferStore.saveDraft({ commercial:{ preliminary:true, offerValidity:'7 dni' } }, { investorId:'inv_scope' });
          FC.projectStore.setCurrentProjectId && FC.projectStore.setCurrentProjectId('proj_scope');
          const current = FC.quoteOfferStore.getCurrentDraft();
          H.assert(current && current.commercial && current.commercial.preliminary === true && String(current.commercial.offerValidity || '') === '7 dni', 'Draft oferty zniknął po przejściu z zakresu inwestora na projekt', current);
        } finally {
          FC.quoteOfferStore.writeAll(prevDrafts);
          FC.projectStore.writeAll(prevProjectStore);
          FC.projectStore.setCurrentProjectId && FC.projectStore.setCurrentProjectId(prevCurrentProjectId);
        }
      }),
      H.makeTest('Wycena', 'Snapshot wyceny zapisuje stawki meblowe i pola handlowe wraz z podsumowaniem po rabacie', 'Pilnuje, czy zapisany snapshot oferty jest już dokumentem handlowym: ma robociznę, rabat i końcową sumę z jednej wersji danych.', ()=>{
        H.assert(FC.quoteSnapshot && typeof FC.quoteSnapshot.buildSnapshot === 'function', 'Brak FC.quoteSnapshot.buildSnapshot');
        const snapshot = FC.quoteSnapshot.buildSnapshot({
          selectedRooms:['room_kuchnia_gora'],
          roomLabels:['Kuchnia góra'],
          materialScope:{ includeFronts:false, includeCorpus:true },
          materialLines:[{ name:'Egger W1100 ST9 Biały Alpejski', qty:2, unit:'ark.', unitPrice:35, total:70 }],
          accessoryLines:[{ name:'Zawias Blum', qty:4, unitPrice:18, total:72 }],
          agdLines:[{ name:'Piekarnik do zabudowy', qty:1, unitPrice:120, total:120 }],
          quoteRateLines:[{ name:'Montaż zabudowy', category:'Montaż', qty:1, unit:'x', unitPrice:400, total:400 }],
          commercial:{ versionName:'Wersja B', preliminary:true, discountPercent:10, offerValidity:'14 dni', leadTime:'4 tygodnie', deliveryTerms:'Transport po stronie wykonawcy', customerNote:'Oferta testowa' },
          generatedAt:1712500000000,
        });
        H.assert(snapshot && snapshot.lines && Array.isArray(snapshot.lines.quoteRates) && snapshot.lines.quoteRates.length === 1, 'Snapshot wyceny nie zachował linii robocizny / stawek meblowych', snapshot);
        H.assert(snapshot.commercial && String(snapshot.commercial.offerValidity || '') === '14 dni' && snapshot.commercial.preliminary === true && snapshot.meta.preliminary === true && String(snapshot.commercial.versionName || '') === 'Wersja B', 'Snapshot wyceny nie zachował pól handlowych, nazwy wersji albo flagi wyceny wstępnej', snapshot);
        H.assert(snapshot.scope && snapshot.scope.materialScopeMode === 'corpus', 'Snapshot wyceny nie zapisał trybu zakresu elementów', snapshot.scope);
        H.assert(Math.abs(Number(snapshot.totals.subtotal || 0) - 662) < 0.001, 'Snapshot wyceny nie policzył sumy przed rabatem', snapshot.totals);
        H.assert(Math.abs(Number(snapshot.totals.discount || 0) - 66.2) < 0.001, 'Snapshot wyceny nie policzył rabatu', snapshot.totals);
        H.assert(Math.abs(Number(snapshot.totals.grand || 0) - 595.8) < 0.001, 'Snapshot wyceny nie policzył końcowej wartości oferty', snapshot.totals);
      }),
      H.makeTest('Wycena', 'Store snapshotów wyceny zapisuje historię dla projektu', 'Pilnuje, czy wycena ma już własny magazyn snapshotów powiązanych z projektem, gotowy pod późniejszy PDF i historię wycen.', ()=>{
        H.assert(FC.quoteSnapshotStore && typeof FC.quoteSnapshotStore.save === 'function', 'Brak FC.quoteSnapshotStore.save');
        const prev = FC.quoteSnapshotStore.readAll();
        try{
          FC.quoteSnapshotStore.writeAll([]);
          const saved = FC.quoteSnapshotStore.save({
            investor:{ id:'inv_hist', name:'Jan Test' },
            project:{ id:'proj_hist', investorId:'inv_hist', title:'Projekt testowy' },
            lines:{ materials:[{ name:'Płyta test', total:100 }], accessories:[], agdServices:[], quoteRates:[{ name:'Montaż test', total:50 }] },
            commercial:{ offerValidity:'14 dni' },
            totals:{ materials:100, accessories:0, services:0, quoteRates:50, subtotal:150, discount:0, grand:150 },
            generatedAt:1712600000000,
          });
          const latest = FC.quoteSnapshotStore.getLatestForProject('proj_hist');
          H.assert(saved && saved.id, 'Store snapshotów nie zwrócił zapisanego rekordu', saved);
          H.assert(latest && String(latest.id || '') === String(saved.id || ''), 'Store snapshotów nie zwrócił najnowszego snapshotu dla projektu', { saved, latest, all:FC.quoteSnapshotStore.readAll() });
          H.assert(Array.isArray(latest.lines.quoteRates) && latest.lines.quoteRates.length === 1, 'Store snapshotów zgubił linie robocizny', latest);
        } finally {
          FC.quoteSnapshotStore.writeAll(prev);
        }
      }),
      H.makeTest('Wycena', 'Historia wycen pozwala oznaczyć zaakceptowaną ofertę i usuwać snapshoty', 'Pilnuje, czy magazyn snapshotów potrafi oznaczyć jedną ofertę jako zaakceptowaną i usuwać konkretne wersje z historii.', ()=>{
        H.assert(FC.quoteSnapshotStore && typeof FC.quoteSnapshotStore.markSelectedForProject === 'function', 'Brak FC.quoteSnapshotStore.markSelectedForProject');
        H.assert(typeof FC.quoteSnapshotStore.remove === 'function', 'Brak FC.quoteSnapshotStore.remove');
        const prev = FC.quoteSnapshotStore.readAll();
        try{
          FC.quoteSnapshotStore.writeAll([]);
          const a = FC.quoteSnapshotStore.save({ investor:{ id:'inv_sel' }, project:{ id:'proj_sel', investorId:'inv_sel', title:'Projekt A' }, totals:{ materials:100, accessories:0, services:0, quoteRates:0, subtotal:100, discount:0, grand:100 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712800000000 });
          const b = FC.quoteSnapshotStore.save({ investor:{ id:'inv_sel' }, project:{ id:'proj_sel', investorId:'inv_sel', title:'Projekt A' }, totals:{ materials:120, accessories:0, services:0, quoteRates:0, subtotal:120, discount:0, grand:120 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712800100000 });
          const marked = FC.quoteSnapshotStore.markSelectedForProject('proj_sel', a.id);
          const selected = FC.quoteSnapshotStore.getSelectedForProject('proj_sel');
          H.assert(marked && String(marked.id || '') === String(a.id || ''), 'Store nie zwrócił oznaczonego snapshotu', { marked, a, b });
          H.assert(selected && String(selected.id || '') === String(a.id || ''), 'Store nie oznaczył właściwej oferty jako zaakceptowanej', { selected, all:FC.quoteSnapshotStore.listForProject('proj_sel') });
          H.assert(FC.quoteSnapshotStore.remove(b.id) === true, 'Store nie usunął snapshotu z historii', { a, b, all:FC.quoteSnapshotStore.readAll() });
          H.assert(FC.quoteSnapshotStore.getById(b.id) == null, 'Usunięty snapshot nadal istnieje w historii', FC.quoteSnapshotStore.readAll());
        } finally {
          FC.quoteSnapshotStore.writeAll(prev);
        }
      }),

      H.makeTest('Wycena', 'Status projektu synchronizuje zaakceptowaną ofertę w obie strony', 'Pilnuje, czy zaakceptowanie wyceny wstępnej daje etap pomiaru, a ręczna zmiana statusu projektu czyści lub przywraca właściwy stan ofert.', ()=>{
        H.assert(FC.quoteSnapshotStore && typeof FC.quoteSnapshotStore.markSelectedForProject === 'function', 'Brak FC.quoteSnapshotStore.markSelectedForProject');
        H.assert(typeof FC.quoteSnapshotStore.syncSelectionForProjectStatus === 'function', 'Brak FC.quoteSnapshotStore.syncSelectionForProjectStatus');
        const prev = FC.quoteSnapshotStore.readAll();
        try{
          FC.quoteSnapshotStore.writeAll([]);
          const prelim = FC.quoteSnapshotStore.save({ investor:{ id:'inv_flow' }, project:{ id:'proj_flow', investorId:'inv_flow', title:'Projekt flow' }, commercial:{ preliminary:true }, totals:{ materials:100, accessories:0, services:0, quoteRates:0, subtotal:100, discount:0, grand:100 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712810000000 });
          const finalQuote = FC.quoteSnapshotStore.save({ investor:{ id:'inv_flow' }, project:{ id:'proj_flow', investorId:'inv_flow', title:'Projekt flow' }, totals:{ materials:150, accessories:0, services:0, quoteRates:0, subtotal:150, discount:0, grand:150 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712810100000 });
          const acceptedPrelim = FC.quoteSnapshotStore.markSelectedForProject('proj_flow', prelim.id, { status:'pomiar' });
          H.assert(acceptedPrelim && acceptedPrelim.meta && acceptedPrelim.meta.selectedByClient === true && acceptedPrelim.meta.acceptedStage === 'pomiar', 'Akceptacja wyceny wstępnej nie ustawiła etapu pomiaru', acceptedPrelim);
          FC.quoteSnapshotStore.syncSelectionForProjectStatus('proj_flow', 'wycena');
          H.assert(FC.quoteSnapshotStore.getSelectedForProject('proj_flow') == null, 'Przejście projektu na etap wyceny nie wyczyściło zaakceptowanej wyceny wstępnej', FC.quoteSnapshotStore.listForProject('proj_flow'));
          const syncedFinal = FC.quoteSnapshotStore.syncSelectionForProjectStatus('proj_flow', 'zaakceptowany');
          H.assert(syncedFinal && String(syncedFinal.id || '') === String(finalQuote.id || '') , 'Status zaakceptowany nie wskazał właściwej wyceny po pomiarze', { syncedFinal, all:FC.quoteSnapshotStore.listForProject('proj_flow') });
          H.assert(FC.quoteSnapshotStore.getRecommendedStatusForProject('proj_flow', 'zaakceptowany') === 'zaakceptowany', 'Rekomendowany status po zaakceptowanej finalnej ofercie jest błędny', FC.quoteSnapshotStore.listForProject('proj_flow'));
          FC.quoteSnapshotStore.remove(finalQuote.id);
          H.assert(FC.quoteSnapshotStore.getRecommendedStatusForProject('proj_flow', 'zaakceptowany') === 'wstepna_wycena', 'Po usunięciu zwykłej oferty status nie wrócił do wstępnej wyceny', FC.quoteSnapshotStore.listForProject('proj_flow'));
        } finally {
          FC.quoteSnapshotStore.writeAll(prev);
        }
      }),

      H.makeTest('Wycena', 'Akceptacja końcowa potrafi przekonwertować zaakceptowaną wycenę wstępną na zwykłą ofertę', 'Pilnuje, czy przycisk konwersji nie tworzy obcej wersji, tylko zamienia tę samą wstępną ofertę w zwykłą końcową z etapem zaakceptowanym.', ()=>{
        H.assert(FC.quoteSnapshotStore && typeof FC.quoteSnapshotStore.convertPreliminaryToFinal === 'function', 'Brak FC.quoteSnapshotStore.convertPreliminaryToFinal');
        const prev = FC.quoteSnapshotStore.readAll();
        try{
          FC.quoteSnapshotStore.writeAll([]);
          const prelim = FC.quoteSnapshotStore.save({ id:'snap_convert_prelim', investor:{ id:'inv_convert' }, project:{ id:'proj_convert', investorId:'inv_convert', title:'Projekt convert' }, commercial:{ preliminary:true, versionName:'Wstępna oferta' }, meta:{ selectedByClient:true, acceptedAt:1712810300000, acceptedStage:'pomiar' }, totals:{ materials:210, accessories:0, services:0, quoteRates:0, subtotal:210, discount:0, grand:210 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712810300000 });
          const converted = FC.quoteSnapshotStore.convertPreliminaryToFinal('proj_convert', prelim.id);
          H.assert(converted && String(converted.id || '') === String(prelim.id || ''), 'Konwersja nie zwróciła tej samej oferty', { prelim, converted });
          H.assert(converted && converted.commercial && converted.commercial.preliminary === false, 'Konwersja nie zdjęła flagi wstępnej z oferty handlowej', converted);
          H.assert(converted && converted.meta && converted.meta.preliminary === false && converted.meta.selectedByClient === true && String(converted.meta.acceptedStage || '') === 'zaakceptowany', 'Konwersja nie ustawiła końcowego stanu zaakceptowania', converted);
          H.assert(String(converted.commercial && converted.commercial.versionName || '') === 'Oferta', 'Konwersja nie podmieniła domyślnej nazwy na zwykłą ofertę', converted);
        } finally {
          FC.quoteSnapshotStore.writeAll(prev);
        }
      }),


      H.makeTest('Wycena ↔ Inwestor', 'Ręczna zmiana statusu inwestora przełącza wskazaną ofertę i status projektu', 'Pilnuje, czy zmiana statusu projektu po stronie Inwestor korzysta z tej samej logiki co Wycena i nie rozjeżdża store projektu oraz historii ofert.', ()=>{
        H.assert(FC.investorPersistence && typeof FC.investorPersistence.setInvestorProjectStatus === 'function', 'Brak FC.investorPersistence.setInvestorProjectStatus');
        H.assert(FC.quoteSnapshotStore && typeof FC.quoteSnapshotStore.markSelectedForProject === 'function', 'Brak FC.quoteSnapshotStore.markSelectedForProject');
        withInvestorProjectFixture({}, ({ investorId, projectId })=>{
          const prelim = FC.quoteSnapshotStore.save({ id:'snap_cross_prelim', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt testowy' }, commercial:{ preliminary:true }, totals:{ grand:100 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820000000 });
          const finalQuote = FC.quoteSnapshotStore.save({ id:'snap_cross_final', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt testowy' }, totals:{ grand:150 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820100000 });
          FC.quoteSnapshotStore.markSelectedForProject(projectId, prelim.id, { status:'pomiar' });
          FC.investorPersistence.setInvestorProjectStatus(investorId, 'room_kuchnia_gora', 'pomiar');
          let selected = FC.quoteSnapshotStore.getSelectedForProject(projectId);
          let record = FC.projectStore.getByInvestorId(investorId);
          H.assert(selected && String(selected.id || '') === String(prelim.id || ''), 'Status pomiar nie utrzymał zaakceptowanej oferty wstępnej', { selected, all:FC.quoteSnapshotStore.listForProject(projectId) });
          H.assert(record && String(record.status || '') === 'pomiar', 'Status pomiar nie zapisał się do projectStore', record);
          FC.investorPersistence.setInvestorProjectStatus(investorId, 'room_kuchnia_gora', 'wycena');
          selected = FC.quoteSnapshotStore.getSelectedForProject(projectId);
          record = FC.projectStore.getByInvestorId(investorId);
          H.assert(selected == null, 'Status wycena nie wyczyścił wskazanej oferty', { selected, all:FC.quoteSnapshotStore.listForProject(projectId) });
          H.assert(record && String(record.status || '') === 'wycena', 'Status wycena nie zapisał się do projectStore', record);
          FC.investorPersistence.setInvestorProjectStatus(investorId, 'room_kuchnia_gora', 'zaakceptowany');
          selected = FC.quoteSnapshotStore.getSelectedForProject(projectId);
          record = FC.projectStore.getByInvestorId(investorId);
          H.assert(selected && String(selected.id || '') === String(finalQuote.id || ''), 'Status zaakceptowany nie wskazał finalnej oferty', { selected, all:FC.quoteSnapshotStore.listForProject(projectId) });
          H.assert(record && String(record.status || '') === 'zaakceptowany', 'Status zaakceptowany nie zapisał się do projectStore', record);
        });
      }),



      H.makeTest('Wycena ↔ Centralny status', 'Inwestor i Wycena wołają jeden wspólny mechanizm statusów', 'Pilnuje ETAP 2: oba wejścia do zmiany statusu mają przechodzić przez centralny serwis zamiast przez dwie niezależne ścieżki.', ()=>{
        H.assert(FC.projectStatusSync && typeof FC.projectStatusSync.setInvestorRoomStatus === 'function', 'Brak FC.projectStatusSync.setInvestorRoomStatus');
        H.assert(FC.projectStatusSync && typeof FC.projectStatusSync.setStatusFromSnapshot === 'function', 'Brak FC.projectStatusSync.setStatusFromSnapshot');
        const prevSetInvestorRoomStatus = FC.projectStatusSync.setInvestorRoomStatus;
        const prevSetStatusFromSnapshot = FC.projectStatusSync.setStatusFromSnapshot;
        let investorCalls = 0;
        let snapshotCalls = 0;
        FC.projectStatusSync.setInvestorRoomStatus = function(){
          investorCalls += 1;
          return prevSetInvestorRoomStatus.apply(this, arguments);
        };
        FC.projectStatusSync.setStatusFromSnapshot = function(){
          snapshotCalls += 1;
          return prevSetStatusFromSnapshot.apply(this, arguments);
        };
        try{
          withInvestorProjectFixture({}, ({ investorId, projectId })=>{
            const prelim = FC.quoteSnapshotStore.save({ id:'snap_central_pre', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt centralny' }, scope:{ selectedRooms:['room_kuchnia_gora'], roomLabels:['Kuchnia góra'] }, commercial:{ preliminary:true, versionName:'Central pre' }, totals:{ grand:100 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820255000 });
            FC.investorPersistence.setInvestorProjectStatus(investorId, 'room_kuchnia_gora', 'pomiar');
            FC.wycenaTabDebug.setProjectStatusFromSnapshot(prelim, 'pomiar', { syncSelection:true });
          });
          H.assert(investorCalls === 1, 'Wejście z Inwestor nie przeszło przez centralny serwis statusów', { investorCalls, snapshotCalls });
          H.assert(snapshotCalls === 1, 'Wejście z Wycena nie przeszło przez centralny serwis statusów', { investorCalls, snapshotCalls });
        } finally {
          FC.projectStatusSync.setInvestorRoomStatus = prevSetInvestorRoomStatus;
          FC.projectStatusSync.setStatusFromSnapshot = prevSetStatusFromSnapshot;
        }
      }),

      H.makeTest('Wycena ↔ Centralny status', 'Centralny serwis statusów synchronizuje inwestora, projekt i wybór oferty', 'Pilnuje ETAP 2: jedna centralna ścieżka ma ustawić statusy pokoi, store projektu i zaakceptowaną ofertę bez potrzeby wywoływania osobnych mostków.', ()=>{
        H.assert(FC.projectStatusSync && typeof FC.projectStatusSync.setStatusFromSnapshot === 'function', 'Brak FC.projectStatusSync.setStatusFromSnapshot');
        withInvestorProjectFixture({}, ({ investorId, projectId })=>{
          const prelim = FC.quoteSnapshotStore.save({ id:'snap_central_sync_pre', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt central sync' }, scope:{ selectedRooms:['room_kuchnia_gora'], roomLabels:['Kuchnia góra'] }, commercial:{ preliminary:true, versionName:'Central sync pre' }, totals:{ grand:101 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820260000 });
          const finalQuote = FC.quoteSnapshotStore.save({ id:'snap_central_sync_final', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt central sync' }, scope:{ selectedRooms:['room_kuchnia_gora'], roomLabels:['Kuchnia góra'] }, commercial:{ preliminary:false, versionName:'Central sync final' }, totals:{ grand:151 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820270000 });
          FC.projectStatusSync.setStatusFromSnapshot(prelim, 'pomiar', { syncSelection:true, refreshUi:false });
          let investor = FC.investors.getById(investorId);
          let project = FC.projectStore.getById(projectId);
          let selected = FC.quoteSnapshotStore.getSelectedForProject(projectId);
          const kitchenAfterPomiar = (investor.rooms || []).find((room)=> String(room && room.id || '') === 'room_kuchnia_gora');
          H.assert(String(kitchenAfterPomiar && kitchenAfterPomiar.projectStatus || '') === 'pomiar', 'Centralny serwis nie ustawił statusu pokoju na pomiar', investor && investor.rooms);
          H.assert(project && String(project.status || '') === 'pomiar', 'Centralny serwis nie zsynchronizował projectStore na pomiar', project);
          H.assert(selected && String(selected.id || '') === String(prelim.id || ''), 'Centralny serwis nie wskazał zaakceptowanej oferty wstępnej', { selected, all:FC.quoteSnapshotStore.listForProject(projectId) });
          FC.projectStatusSync.setStatusFromSnapshot(finalQuote, 'zaakceptowany', { syncSelection:true, refreshUi:false });
          investor = FC.investors.getById(investorId);
          project = FC.projectStore.getById(projectId);
          selected = FC.quoteSnapshotStore.getSelectedForProject(projectId);
          const kitchenAfterFinal = (investor.rooms || []).find((room)=> String(room && room.id || '') === 'room_kuchnia_gora');
          H.assert(String(kitchenAfterFinal && kitchenAfterFinal.projectStatus || '') === 'zaakceptowany', 'Centralny serwis nie ustawił statusu pokoju na zaakceptowany', investor && investor.rooms);
          H.assert(project && String(project.status || '') === 'zaakceptowany', 'Centralny serwis nie zsynchronizował projectStore na zaakceptowany', project);
          H.assert(selected && String(selected.id || '') === String(finalQuote.id || ''), 'Centralny serwis nie przełączył zaakceptowanej oferty na końcową', { selected, all:FC.quoteSnapshotStore.listForProject(projectId) });
        });
      }),


      H.makeTest('Wycena ↔ Centralny status', 'Centralny status ignoruje stare statusy z roomRegistry przy zapisie projektu', 'Pilnuje regresję z ETAPU 3: obce albo stare statusy wiszące w roomRegistry nie mogą nadpisywać projectStore.status ani statusów pokoi przy zmianie scoped.', ()=>{
        H.assert(FC.projectStatusSync && typeof FC.projectStatusSync.setStatusFromSnapshot === 'function', 'Brak FC.projectStatusSync.setStatusFromSnapshot');
        H.assert(FC.roomRegistry && typeof FC.roomRegistry.getActiveRoomDefs === 'function', 'Brak FC.roomRegistry.getActiveRoomDefs');
        H.assert(typeof FC.roomRegistry.getActiveRoomIds === 'function', 'Brak FC.roomRegistry.getActiveRoomIds');
        withInvestorProjectFixture({}, ({ investorId, projectId })=>{
          const prelim = FC.quoteSnapshotStore.save({ id:'snap_registry_pre', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt registry' }, scope:{ selectedRooms:['room_kuchnia_gora'], roomLabels:['Kuchnia góra'] }, commercial:{ preliminary:true, versionName:'Registry pre' }, totals:{ grand:111 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820280000 });
          const prevGetActiveRoomDefs = FC.roomRegistry.getActiveRoomDefs;
          const prevGetActiveRoomIds = FC.roomRegistry.getActiveRoomIds;
          const staleDefs = [
            { id:'room_kuchnia_gora', baseType:'kuchnia', name:'Kuchnia góra', label:'Kuchnia góra', projectStatus:'wycena' },
            { id:'room_salon', baseType:'pokoj', name:'Salon', label:'Salon', projectStatus:'wycena' },
            { id:'room_stale', baseType:'pokoj', name:'Stary pokój', label:'Stary pokój', projectStatus:'wycena' },
          ];
          FC.roomRegistry.getActiveRoomDefs = ()=> clone(staleDefs);
          FC.roomRegistry.getActiveRoomIds = ()=> staleDefs.map((room)=> String(room && room.id || '')).filter(Boolean);
          try{
            FC.projectStatusSync.setStatusFromSnapshot(prelim, 'pomiar', { syncSelection:true, refreshUi:false });
            const investor = FC.investors.getById(investorId);
            const project = FC.projectStore.getById(projectId);
            const kitchen = (investor && investor.rooms || []).find((room)=> String(room && room.id || '') === 'room_kuchnia_gora');
            const salon = (investor && investor.rooms || []).find((room)=> String(room && room.id || '') === 'room_salon');
            H.assert(String(kitchen && kitchen.projectStatus || '') === 'pomiar', 'Brudny roomRegistry nadpisał status aktywnego pokoju', investor && investor.rooms);
            H.assert(String(salon && salon.projectStatus || '') === 'nowy', 'Brudny roomRegistry nadpisał status innego pokoju projektu', investor && investor.rooms);
            H.assert(project && String(project.status || '') === 'pomiar', 'Brudny roomRegistry nadpisał zagregowany status projectStore', project);
          } finally {
            FC.roomRegistry.getActiveRoomDefs = prevGetActiveRoomDefs;
            FC.roomRegistry.getActiveRoomIds = prevGetActiveRoomIds;
          }
        });
      }),

      H.makeTest('Wycena ↔ Centralny status', 'Sprzątanie ETAPU 3 nie wraca do starego lokalnego patchowania statusów', 'Pilnuje ETAP 3: wejścia statusów nie mają już po centralizacji dopalać starej ścieżki updateInvestorRoom jako drugiego mechanizmu zapisu.', ()=>{
        H.assert(FC.projectStatusSync && typeof FC.projectStatusSync.setInvestorRoomStatus === 'function', 'Brak FC.projectStatusSync.setInvestorRoomStatus');
        H.assert(FC.projectStatusSync && typeof FC.projectStatusSync.setStatusFromSnapshot === 'function', 'Brak FC.projectStatusSync.setStatusFromSnapshot');
        H.assert(FC.investorPersistence && typeof FC.investorPersistence.updateInvestorRoom === 'function', 'Brak FC.investorPersistence.updateInvestorRoom');
        const prevUpdateInvestorRoom = FC.investorPersistence.updateInvestorRoom;
        let fallbackCalls = 0;
        FC.investorPersistence.updateInvestorRoom = function(){
          fallbackCalls += 1;
          return prevUpdateInvestorRoom.apply(this, arguments);
        };
        try{
          withInvestorProjectFixture({}, ({ investorId, projectId })=>{
            const prelim = FC.quoteSnapshotStore.save({ id:'snap_cleanup_pre', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt cleanup' }, scope:{ selectedRooms:['room_kuchnia_gora'], roomLabels:['Kuchnia góra'] }, commercial:{ preliminary:true, versionName:'Cleanup pre' }, totals:{ grand:101 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820285000 });
            FC.investorPersistence.setInvestorProjectStatus(investorId, 'room_kuchnia_gora', 'pomiar');
            FC.wycenaTabDebug.setProjectStatusFromSnapshot(prelim, 'pomiar', { syncSelection:true });
          });
          H.assert(fallbackCalls === 0, 'Po sprzątaniu statusów wróciło stare lokalne patchowanie updateInvestorRoom', { fallbackCalls });
        } finally {
          FC.investorPersistence.updateInvestorRoom = prevUpdateInvestorRoom;
        }
      }),

      H.makeTest('Wycena ↔ Statusy pomieszczeń', 'Akceptacja oferty jednego pomieszczenia zmienia status tylko tego pokoju', 'Pilnuje, czy zaakceptowanie wyceny scoped do jednego pomieszczenia nie nadpisuje statusów pozostałych pokoi inwestora.', ()=>{
        H.assert(FC.wycenaTabDebug && typeof FC.wycenaTabDebug.setProjectStatusFromSnapshot === 'function', 'Brak FC.wycenaTabDebug.setProjectStatusFromSnapshot');
        withInvestorProjectFixture({}, ({ investorId, projectId })=>{
          const snapshot = FC.quoteSnapshotStore.save({
            id:'snap_room_only_pre',
            investor:{ id:investorId },
            project:{ id:projectId, investorId, title:'Projekt scoped' },
            scope:{ selectedRooms:['room_kuchnia_gora'], roomLabels:['Kuchnia góra'], materialScopeMode:'both', materialScope:{ includeFronts:true, includeCorpus:true } },
            commercial:{ preliminary:true, versionName:'Wstępna kuchnia' },
            totals:{ grand:100 },
            lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] },
            generatedAt:1712820300000,
          });
          FC.quoteSnapshotStore.markSelectedForProject(projectId, snapshot.id, { status:'pomiar' });
          FC.wycenaTabDebug.setProjectStatusFromSnapshot(snapshot, 'pomiar');
          const investor = FC.investors.getById(investorId);
          const kitchen = (investor.rooms || []).find((room)=> String(room && room.id || '') === 'room_kuchnia_gora');
          const salon = (investor.rooms || []).find((room)=> String(room && room.id || '') === 'room_salon');
          const project = FC.projectStore.getById(projectId);
          H.assert(String(kitchen && kitchen.projectStatus || '') === 'pomiar', 'Pokój objęty wyceną nie dostał statusu pomiar', investor.rooms);
          H.assert(String(salon && salon.projectStatus || '') === 'nowy', 'Status drugiego pokoju został nadpisany mimo że wycena go nie obejmowała', investor.rooms);
          H.assert(project && String(project.status || '') === 'pomiar', 'Zagregowany status projektu nie przeszedł na pomiar po akceptacji scoped wyceny', project);
        });
      }),

      H.makeTest('Wycena ↔ Statusy pomieszczeń', 'Wspólna wycena aktualizuje tylko pokoje ze swojego zakresu', 'Pilnuje, czy wycena obejmująca kilka wybranych pomieszczeń aktualizuje tylko te pokoje, a nie cały projekt w ciemno.', ()=>{
        H.assert(FC.wycenaTabDebug && typeof FC.wycenaTabDebug.setProjectStatusFromSnapshot === 'function', 'Brak FC.wycenaTabDebug.setProjectStatusFromSnapshot');
        withInvestorProjectFixture({
          rooms:[
            { id:'room_kuchnia_gora', baseType:'kuchnia', name:'Kuchnia góra', label:'Kuchnia góra', projectStatus:'nowy' },
            { id:'room_salon', baseType:'pokoj', name:'Salon', label:'Salon', projectStatus:'nowy' },
            { id:'room_lazienka', baseType:'lazienka', name:'Łazienka', label:'Łazienka', projectStatus:'nowy' },
          ],
          projectData:{
            schemaVersion:2,
            meta:{
              roomDefs:{
                room_kuchnia_gora:{ id:'room_kuchnia_gora', baseType:'kuchnia', name:'Kuchnia góra', label:'Kuchnia góra' },
                room_salon:{ id:'room_salon', baseType:'pokoj', name:'Salon', label:'Salon' },
                room_lazienka:{ id:'room_lazienka', baseType:'lazienka', name:'Łazienka', label:'Łazienka' },
              },
              roomOrder:['room_kuchnia_gora','room_salon','room_lazienka'],
            },
            room_kuchnia_gora:{ cabinets:[{ id:'cab_k' }], fronts:[], sets:[], settings:{} },
            room_salon:{ cabinets:[{ id:'cab_s' }], fronts:[], sets:[], settings:{} },
            room_lazienka:{ cabinets:[{ id:'cab_l' }], fronts:[], sets:[], settings:{} },
          }
        }, ({ investorId, projectId })=>{
          const snapshot = FC.quoteSnapshotStore.save({
            id:'snap_shared_final',
            investor:{ id:investorId },
            project:{ id:projectId, investorId, title:'Projekt shared' },
            scope:{ selectedRooms:['room_kuchnia_gora','room_salon'], roomLabels:['Kuchnia góra','Salon'], materialScopeMode:'both', materialScope:{ includeFronts:true, includeCorpus:true } },
            commercial:{ preliminary:false, versionName:'Oferta wspólna' },
            totals:{ grand:250 },
            lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] },
            generatedAt:1712820400000,
          });
          FC.wycenaTabDebug.setProjectStatusFromSnapshot(snapshot, 'wycena');
          const investor = FC.investors.getById(investorId);
          const byId = Object.fromEntries((investor.rooms || []).map((room)=> [String(room && room.id || ''), room]));
          H.assert(String(byId.room_kuchnia_gora && byId.room_kuchnia_gora.projectStatus || '') === 'wycena', 'Pierwszy pokój ze wspólnej wyceny nie dostał statusu wycena', investor.rooms);
          H.assert(String(byId.room_salon && byId.room_salon.projectStatus || '') === 'wycena', 'Drugi pokój ze wspólnej wyceny nie dostał statusu wycena', investor.rooms);
          H.assert(String(byId.room_lazienka && byId.room_lazienka.projectStatus || '') === 'nowy', 'Pokój spoza wspólnej wyceny dostał status mimo braku w zakresie', investor.rooms);
        });
      }),

      H.makeTest('Wycena ↔ Statusy pomieszczeń', 'Zmiana zaakceptowanej wyceny wspólnej na jednopomieszczeniową cofa pozostałe pokoje', 'Pilnuje regresję, w której po przełączeniu akceptacji z wyceny wspólnej na wycenę jednego pokoju inne pomieszczenia błędnie zostawały na statusie pomiar.', ()=>{
        H.assert(FC.quoteSnapshotStore && typeof FC.quoteSnapshotStore.markSelectedForProject === 'function', 'Brak FC.quoteSnapshotStore.markSelectedForProject');
        H.assert(FC.wycenaTabDebug && typeof FC.wycenaTabDebug.setProjectStatusFromSnapshot === 'function', 'Brak FC.wycenaTabDebug.setProjectStatusFromSnapshot');
        withInvestorProjectFixture({}, ({ investorId, projectId })=>{
          const sharedPre = FC.quoteSnapshotStore.save({ id:'snap_shared_pre', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt przełączenie' }, scope:{ selectedRooms:['room_kuchnia_gora','room_salon'], roomLabels:['Kuchnia góra','Salon'] }, commercial:{ preliminary:true, versionName:'Wspólna pre' }, totals:{ grand:210 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820450000 });
          const kitchenPre = FC.quoteSnapshotStore.save({ id:'snap_kitchen_pre_only', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt przełączenie' }, scope:{ selectedRooms:['room_kuchnia_gora'], roomLabels:['Kuchnia góra'] }, commercial:{ preliminary:true, versionName:'Kuchnia pre' }, totals:{ grand:105 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820460000 });
          FC.quoteSnapshotStore.markSelectedForProject(projectId, sharedPre.id, { status:'pomiar' });
          FC.wycenaTabDebug.setProjectStatusFromSnapshot(sharedPre, 'pomiar');
          FC.quoteSnapshotStore.markSelectedForProject(projectId, kitchenPre.id, { status:'pomiar' });
          FC.wycenaTabDebug.setProjectStatusFromSnapshot(kitchenPre, 'pomiar');
          const investor = FC.investors.getById(investorId);
          const byId = Object.fromEntries((investor.rooms || []).map((room)=> [String(room && room.id || ''), room]));
          H.assert(String(byId.room_kuchnia_gora && byId.room_kuchnia_gora.projectStatus || '') === 'pomiar', 'Pokój z nowo zaakceptowaną wyceną jednopomieszczeniową stracił status pomiar', investor.rooms);
          H.assert(String(byId.room_salon && byId.room_salon.projectStatus || '') === 'wstepna_wycena', 'Pokój zdjęty z akceptacji nie wrócił do własnego statusu scoped po wyłączeniu wspólnej wyceny', { rooms:investor.rooms, all:FC.quoteSnapshotStore.listForProject(projectId) });
        });
      }),

      H.makeTest('Wycena ↔ Statusy pomieszczeń', 'Status wyceny scoped nie zależy od pierwszego pokoju inwestora', 'Pilnuje, czy odczyt statusu oferty bierze pokoje z zakresu snapshotu zamiast przypadkowego pierwszego pomieszczenia inwestora.', ()=>{
        H.assert(FC.wycenaTabDebug && typeof FC.wycenaTabDebug.currentProjectStatus === 'function', 'Brak FC.wycenaTabDebug.currentProjectStatus');
        withInvestorProjectFixture({}, ({ investorId, projectId })=>{
          FC.investorPersistence.setInvestorProjectStatus(investorId, 'room_salon', 'pomiar');
          const snapshot = FC.quoteSnapshotStore.save({
            id:'snap_scope_status',
            investor:{ id:investorId },
            project:{ id:projectId, investorId, title:'Projekt fallback' },
            scope:{ selectedRooms:['room_salon'], roomLabels:['Salon'], materialScopeMode:'both', materialScope:{ includeFronts:true, includeCorpus:true } },
            commercial:{ preliminary:true, versionName:'Salon pomiar' },
            totals:{ grand:90 },
            lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] },
            generatedAt:1712820500000,
          });
          const status = FC.wycenaTabDebug.currentProjectStatus(snapshot);
          H.assert(String(status || '') === 'pomiar', 'Status scoped oferty wrócił do pierwszego pokoju albo złego fallbacku zamiast do właściwego pomieszczenia', { status, investor:FC.investors.getById(investorId), snapshot });
        });
      }),

      H.makeTest('Wycena ↔ Statusy pomieszczeń', 'Ręczna zmiana statusu pokoju wybiera tylko pasującą ofertę i nie rusza innych pokoi', 'Pilnuje, czy ręczne ustawienie statusu w Inwestor synchronizuje Wycena po zakresie pomieszczenia zamiast po dowolnej pierwszej ofercie projektu.', ()=>{
        H.assert(FC.investorPersistence && typeof FC.investorPersistence.setInvestorProjectStatus === 'function', 'Brak FC.investorPersistence.setInvestorProjectStatus');
        withInvestorProjectFixture({}, ({ investorId, projectId })=>{
          const kitchenPre = FC.quoteSnapshotStore.save({ id:'snap_room_kitchen_pre', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt ręczny' }, scope:{ selectedRooms:['room_kuchnia_gora'], roomLabels:['Kuchnia góra'] }, commercial:{ preliminary:true, versionName:'Kuchnia pre' }, totals:{ grand:100 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820600000 });
          const salonPre = FC.quoteSnapshotStore.save({ id:'snap_room_salon_pre', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt ręczny' }, scope:{ selectedRooms:['room_salon'], roomLabels:['Salon'] }, commercial:{ preliminary:true, versionName:'Salon pre' }, totals:{ grand:120 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820700000 });
          FC.investorPersistence.setInvestorProjectStatus(investorId, 'room_salon', 'pomiar');
          const investor = FC.investors.getById(investorId);
          const byId = Object.fromEntries((investor.rooms || []).map((room)=> [String(room && room.id || ''), room]));
          const selected = FC.quoteSnapshotStore.getSelectedForProject(projectId);
          H.assert(String(byId.room_kuchnia_gora && byId.room_kuchnia_gora.projectStatus || '') === 'wstepna_wycena', 'Ręczna zmiana statusu salonu zignorowała scoped historię kuchni albo nadpisała ją błędnym statusem', investor.rooms);
          H.assert(String(byId.room_salon && byId.room_salon.projectStatus || '') === 'pomiar', 'Ręczna zmiana statusu salonu nie zapisała się w docelowym pokoju', investor.rooms);
          H.assert(selected && String(selected.id || '') === String(salonPre.id || ''), 'Synchronizacja Wycena po ręcznej zmianie pokoju wybrała złą ofertę scoped', { selected, kitchenPre, salonPre, all:FC.quoteSnapshotStore.listForProject(projectId) });
        });
      }),

      H.makeTest('Wycena ↔ Statusy pomieszczeń', 'Scoped rekomendacja statusu po usunięciu oferty nie opiera się na innych pokojach', 'Pilnuje, czy cofanie statusu po usunięciu oferty bierze tylko snapshoty z tego samego zakresu pomieszczeń, a nie oferty innych pokoi.', ()=>{
        H.assert(FC.quoteSnapshotStore && typeof FC.quoteSnapshotStore.getRecommendedStatusForProject === 'function', 'Brak FC.quoteSnapshotStore.getRecommendedStatusForProject');
        withInvestorProjectFixture({}, ({ investorId, projectId })=>{
          FC.quoteSnapshotStore.save({ id:'snap_scope_pre_k', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt scoped rec' }, scope:{ selectedRooms:['room_kuchnia_gora'], roomLabels:['Kuchnia góra'] }, commercial:{ preliminary:true, versionName:'K pre' }, totals:{ grand:100 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820800000 });
          FC.quoteSnapshotStore.save({ id:'snap_scope_final_s', investor:{ id:investorId }, project:{ id:projectId, investorId, title:'Projekt scoped rec' }, scope:{ selectedRooms:['room_salon'], roomLabels:['Salon'] }, commercial:{ preliminary:false, versionName:'S final' }, totals:{ grand:200 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712820900000 });
          const recommendedKitchen = FC.quoteSnapshotStore.getRecommendedStatusForProject(projectId, 'zaakceptowany', { roomIds:['room_kuchnia_gora'] });
          const recommendedSalon = FC.quoteSnapshotStore.getRecommendedStatusForProject(projectId, 'zaakceptowany', { roomIds:['room_salon'] });
          H.assert(String(recommendedKitchen || '') === 'wstepna_wycena', 'Scoped rekomendacja dla kuchni została zanieczyszczona ofertą z innego pokoju', { recommendedKitchen, all:FC.quoteSnapshotStore.listForProject(projectId) });
          H.assert(String(recommendedSalon || '') === 'wycena', 'Scoped rekomendacja dla salonu nie zachowała jego własnej oferty końcowej', { recommendedSalon, all:FC.quoteSnapshotStore.listForProject(projectId) });
        });
      }),

      H.makeTest('Wycena ↔ Pomieszczenia ↔ ROZRYS', 'Wycena filtruje elementy dokładnie po zapisanym wyborze pomieszczeń', 'Pilnuje, czy po wyborze pokoi w Wycena agregacja bierze tylko te pokoje, a nie dorzuca formatek z innych pomieszczeń aktywnego projektu.', ()=>{
        H.assert(FC.wycenaCore && typeof FC.wycenaCore.collectElementLines === 'function', 'Brak FC.wycenaCore.collectElementLines');
        H.assert(FC.rozrys && typeof FC.rozrys.aggregatePartsForProject === 'function', 'Brak FC.rozrys.aggregatePartsForProject');
        withInvestorProjectFixture({
          cutListFn(cabinet, roomId){
            if(String(roomId || '') === 'room_kuchnia_gora') return [{ name:'Bok kuchnia', material:'Dąb kuchnia', a:72, b:56, qty:2 }];
            if(String(roomId || '') === 'room_salon') return [{ name:'Bok salon', material:'Jesion salon', a:60, b:40, qty:3 }];
            return [];
          }
        }, ()=>{
          const agg = FC.rozrys.aggregatePartsForProject(['room_salon']);
          const lines = FC.wycenaCore.collectElementLines({ selectedRooms:['room_salon'], materialScope:{ includeFronts:false, includeCorpus:true } });
          H.assert(Array.isArray(agg.materials) && agg.materials.length === 1 && String(agg.materials[0] || '') === 'Jesion salon', 'ROZRYS nie ograniczył agregacji do wybranego pokoju', agg);
          H.assert(Array.isArray(lines) && lines.length === 1, 'Wycena nie ograniczyła listy elementów do wybranego pokoju', lines);
          H.assert(String(lines[0].name || '') === 'Bok salon' && String(lines[0].materialLabel || '') === 'Jesion salon' && Number(lines[0].qty) === 3, 'Wycena zwróciła elementy z niewłaściwego pokoju albo złą ilość', lines[0]);
        });
      }),

      H.makeTest('Wycena ↔ Pomieszczenia ↔ ROZRYS', 'Pusty wybór pokoi w Wycena wraca do wszystkich aktywnych pomieszczeń bieżącego projektu', 'Pilnuje, czy gdy zapisany wybór jest pusty, Wycena bierze komplet realnych pokoi aktywnego inwestora, a nie pusty stan albo domyślne typy bazowe.', ()=>{
        H.assert(FC.wycenaCore && typeof FC.wycenaCore.collectElementLines === 'function', 'Brak FC.wycenaCore.collectElementLines');
        withInvestorProjectFixture({
          cutListFn(cabinet, roomId){
            if(String(roomId || '') === 'room_kuchnia_gora') return [{ name:'Kuchnia bok', material:'Biały mat', a:72, b:56, qty:1 }];
            if(String(roomId || '') === 'room_salon') return [{ name:'Salon bok', material:'Dąb artisan', a:65, b:45, qty:2 }];
            return [];
          }
        }, ()=>{
          const normalized = FC.wycenaCore.normalizeQuoteSelection({ selectedRooms:[], materialScope:{ includeFronts:false, includeCorpus:true } });
          const lines = FC.wycenaCore.collectElementLines({ selectedRooms:[], materialScope:{ includeFronts:false, includeCorpus:true } });
          H.assert(Array.isArray(normalized.selectedRooms) && normalized.selectedRooms.includes('room_kuchnia_gora') && normalized.selectedRooms.includes('room_salon'), 'Wycena nie wróciła do wszystkich aktywnych pokoi projektu', normalized);
          H.assert(Array.isArray(lines) && lines.length === 2, 'Wycena nie zebrała elementów ze wszystkich aktywnych pokoi po pustym wyborze', lines);
          H.assert(lines.some((row)=> String(row.name || '') === 'Kuchnia bok') && lines.some((row)=> String(row.name || '') === 'Salon bok'), 'Po pustym wyborze brakuje elementów z któregoś pokoju', lines);
        });
      }),

      H.makeTest('Wycena ↔ PDF', 'PDF budowany z zapisanej końcowej oferty zachowuje handlowy charakter po konwersji z wstępnej', 'Pilnuje, czy po konwersji zaakceptowanej wyceny wstępnej na końcową PDF nadal bierze tę samą wersję oferty, pokazuje pomieszczenia i nie wraca do technicznych formatek.', ()=>{
        H.assert(FC.quoteSnapshotStore && typeof FC.quoteSnapshotStore.convertPreliminaryToFinal === 'function', 'Brak FC.quoteSnapshotStore.convertPreliminaryToFinal');
        H.assert(FC.quotePdf && typeof FC.quotePdf.buildPrintHtml === 'function', 'Brak FC.quotePdf.buildPrintHtml');
        const prev = FC.quoteSnapshotStore.readAll();
        try{
          FC.quoteSnapshotStore.writeAll([]);
          const prelim = FC.quoteSnapshotStore.save({
            id:'snap_pdf_cross_prelim',
            investor:{ id:'inv_pdf_cross', name:'Jan Test' },
            project:{ id:'proj_pdf_cross', investorId:'inv_pdf_cross', title:'Projekt PDF cross', status:'pomiar' },
            scope:{ selectedRooms:['room_kuchnia_gora'], roomLabels:['Kuchnia góra'], materialScopeMode:'corpus', materialScope:{ includeFronts:false, includeCorpus:true } },
            commercial:{ preliminary:true, versionName:'Wstępna oferta' },
            meta:{ selectedByClient:true, acceptedAt:1712820200000, acceptedStage:'pomiar' },
            lines:{
              elements:[{ name:'Bok', qty:2, width:720, height:560, materialLabel:'Biały mat' }],
              materials:[{ name:'Biały mat', qty:1, unit:'ark.' }],
              accessories:[{ name:'Zawias Blum', qty:4 }],
              agdServices:[{ name:'Piekarnik do zabudowy', qty:1 }],
              quoteRates:[{ name:'Montaż zabudowy', qty:1, unit:'x' }],
            },
            totals:{ grand:999, subtotal:999, discount:0, materials:0, accessories:0, services:0, quoteRates:0 },
            generatedAt:1712820200000,
          });
          FC.quoteSnapshotStore.convertPreliminaryToFinal('proj_pdf_cross', prelim.id);
          const selected = FC.quoteSnapshotStore.getSelectedForProject('proj_pdf_cross');
          const html = FC.quotePdf.buildPrintHtml(selected);
          H.assert(selected && selected.commercial && selected.commercial.preliminary === false, 'Konwersja nie zostawiła finalnej zapisanej oferty do PDF', selected);
          H.assert(/Wycena końcowa/.test(String(html || '')) && /Kuchnia góra/.test(String(html || '')), 'PDF po konwersji nie pokazuje końcowego typu oferty albo pomieszczeń', html);
          H.assert(/Biały mat/.test(String(html || '')) && /Zawias Blum/.test(String(html || '')) && /Montaż zabudowy/.test(String(html || '')) && /Piekarnik do zabudowy/.test(String(html || '')), 'PDF po konwersji zgubił handlowe sekcje materiałów / akcesoriów / usług / AGD', html);
          H.assert(!/Elementy w ofercie/.test(String(html || '')) && !/720 × 560 mm/.test(String(html || '')), 'PDF po konwersji wrócił do technicznej listy formatek', html);
        } finally {
          FC.quoteSnapshotStore.writeAll(prev);
        }
      }),

      H.makeTest('Wycena', 'Zaakceptowana zwykła oferta wygasza wszystkie wyceny wstępne niezależnie od kolejności', 'Pilnuje, czy po akceptacji końcowej wyceny wstępne nie zostają aktywne tylko dlatego, że są wyżej na liście niż zaakceptowana zwykła oferta.', ()=>{
        const preliminary = (snap)=> !!(snap && snap.meta && snap.meta.preliminary);
        const archive = (snap, list)=> !!(preliminary(snap) && list.some((row)=> !preliminary(row) && row && row.meta && row.meta.selectedByClient));
        const prev = FC.quoteSnapshotStore.readAll();
        try{
          FC.quoteSnapshotStore.writeAll([]);
          const olderFinal = FC.quoteSnapshotStore.save({ id:'snap_arch_sel_final', investor:{ id:'inv_arch_sel' }, project:{ id:'proj_arch_sel', investorId:'inv_arch_sel', title:'Projekt arch sel' }, totals:{ materials:150, accessories:0, services:0, quoteRates:0, subtotal:150, discount:0, grand:150 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712810000000 });
          const newerPrelim = FC.quoteSnapshotStore.save({ id:'snap_arch_sel_prelim', investor:{ id:'inv_arch_sel' }, project:{ id:'proj_arch_sel', investorId:'inv_arch_sel', title:'Projekt arch sel' }, commercial:{ preliminary:true }, totals:{ materials:100, accessories:0, services:0, quoteRates:0, subtotal:100, discount:0, grand:100 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712810100000 });
          FC.quoteSnapshotStore.markSelectedForProject('proj_arch_sel', olderFinal.id, { status:'zaakceptowany' });
          const list = FC.quoteSnapshotStore.listForProject('proj_arch_sel');
          H.assert(archive(newerPrelim, list) === true, 'Po zaakceptowaniu zwykłej oferty nowsza wycena wstępna nie została wygaszona', list);
        } finally {
          FC.quoteSnapshotStore.writeAll(prev);
        }
      }),

      H.makeTest('Wycena', 'Wycena po pomiarze nie wygasza nowszej wyceny wstępnej i oznacza starszą po pojawieniu się nowej zwykłej wyceny', 'Pilnuje, czy historia ofert nie chowa świeżo zapisanej wyceny wstępnej przez starszą zwykłą wycenę, a wygasza tylko starsze wersje wstępne po pojawieniu się nowej normalnej wyceny.', ()=>{
        const preliminary = (snap)=> !!(snap && snap.meta && snap.meta.preliminary);
        const archive = (snap, list)=> !!(preliminary(snap) && list.some((row)=> !preliminary(row) && Number(row && row.generatedAt || 0) > Number(snap && snap.generatedAt || 0)));
        const prev = FC.quoteSnapshotStore.readAll();
        try{
          FC.quoteSnapshotStore.writeAll([]);
          const olderFinal = FC.quoteSnapshotStore.save({ investor:{ id:'inv_arch' }, project:{ id:'proj_arch', investorId:'inv_arch', title:'Projekt arch' }, totals:{ materials:150, accessories:0, services:0, quoteRates:0, subtotal:150, discount:0, grand:150 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712810000000 });
          const newerPrelim = FC.quoteSnapshotStore.save({ investor:{ id:'inv_arch' }, project:{ id:'proj_arch', investorId:'inv_arch', title:'Projekt arch' }, commercial:{ preliminary:true }, totals:{ materials:100, accessories:0, services:0, quoteRates:0, subtotal:100, discount:0, grand:100 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712810100000 });
          let list = FC.quoteSnapshotStore.listForProject('proj_arch');
          H.assert(archive(newerPrelim, list) === false, 'Nowsza wycena wstępna została błędnie wygaszona przez starszą zwykłą wycenę', list);
          const newestFinal = FC.quoteSnapshotStore.save({ investor:{ id:'inv_arch' }, project:{ id:'proj_arch', investorId:'inv_arch', title:'Projekt arch' }, totals:{ materials:170, accessories:0, services:0, quoteRates:0, subtotal:170, discount:0, grand:170 }, lines:{ materials:[], accessories:[], agdServices:[], quoteRates:[] }, generatedAt:1712810200000 });
          list = FC.quoteSnapshotStore.listForProject('proj_arch');
          H.assert(archive(newerPrelim, list) === true, 'Starsza wycena wstępna nie została wygaszona po pojawieniu się nowszej zwykłej wyceny', list);
          H.assert(archive(newestFinal, list) === false && archive(olderFinal, list) === false, 'Zwykłe wyceny nie powinny być wygaszane przez ten mechanizm', list);
        } finally {
          FC.quoteSnapshotStore.writeAll(prev);
        }
      }),
      H.makeTest('Wycena', 'PDF wyceny buduje handlową ofertę bez technicznej listy formatek', 'Pilnuje, czy PDF dla klienta pokazuje tylko handlowe sekcje: materiały, akcesoria, usługi, AGD i cenę końcową, bez technicznej listy elementów / formatek.', ()=>{
        H.assert(FC.quotePdf && typeof FC.quotePdf.buildPrintHtml === 'function', 'Brak FC.quotePdf.buildPrintHtml');
        const html = FC.quotePdf.buildPrintHtml({
          investor:{ id:'inv_pdf', name:'Jan Test' },
          project:{ id:'proj_pdf', investorId:'inv_pdf', title:'Kuchnia testowa', status:'wycena ostateczna' },
          scope:{ roomLabels:['Kuchnia dół'], materialScopeMode:'corpus', materialScope:{ includeFronts:false, includeCorpus:true } },
          lines:{
            elements:[{ name:'Bok', qty:2, width:720, height:560, materialLabel:'Egger W1100 ST9 Biały Alpejski' }],
            materials:[{ name:'Egger W1100 ST9 Biały Alpejski', qty:2, unit:'ark.', unitPrice:35, total:70 }],
            accessories:[{ name:'Zawias Blum', qty:4, unitPrice:18, total:72 }],
            agdServices:[{ name:'Piekarnik do zabudowy', qty:1, unitPrice:120, total:120 }],
            quoteRates:[{ name:'Montaż zabudowy', qty:1, unit:'x', unitPrice:400, total:400, category:'Montaż' }],
          },
          commercial:{ versionName:'Wersja PDF A', discountPercent:10, offerValidity:'14 dni', leadTime:'4 tygodnie', deliveryTerms:'Montaż w cenie', customerNote:'Oferta testowa' },
          totals:{ materials:70, accessories:72, services:120, quoteRates:400, subtotal:662, discount:66.2, grand:595.8 },
          generatedAt:1712700000000,
        });
        H.assert(/Oferta dla klienta/.test(String(html || '')), 'PDF wyceny nie zawiera nagłówka dokumentu handlowego', html);
        H.assert(/Montaż zabudowy/.test(String(html || '')), 'PDF wyceny nie zawiera pozycji robocizny', html);
        H.assert(/Warunki oferty/.test(String(html || '')) && /14 dni/.test(String(html || '')) && /4 tygodnie/.test(String(html || '')), 'PDF wyceny nie zawiera pól handlowych', html);
        H.assert(/Wersja PDF A/.test(String(html || '')) && /Same korpusy/.test(String(html || '')), 'PDF wyceny nie zawiera nazwy wersji albo zakresu elementów', html);
        H.assert(/595\.80 PLN/.test(String(html || '')), 'PDF wyceny nie zawiera końcowej sumy po rabacie', html);
        H.assert(/Materiały \/ kolory/.test(String(html || '')) && /Egger W1100 ST9 Biały Alpejski/.test(String(html || '')), 'PDF wyceny nie zawiera listy materiałów / kolorów', html);
        H.assert(/Zawias Blum/.test(String(html || '')) && /4 szt\./.test(String(html || '')), 'PDF wyceny nie zawiera akcesoriów z ilościami', html);
        H.assert(/Piekarnik do zabudowy/.test(String(html || '')), 'PDF wyceny nie zawiera listy montowanych sprzętów AGD', html);
        H.assert(!/Elementy w ofercie/.test(String(html || '')) && !/720 × 560 mm/.test(String(html || '')) && !/Bok/.test(String(html || '')), 'PDF wyceny nadal pokazuje techniczną listę formatek / elementów', html);
      }),
    ]);
  }

  FC.wycenaDevTests = { runAll };
})(typeof window !== 'undefined' ? window : globalThis);
